const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const User = require('../models/User');
const Content = require('../models/Content');
const Message = require('../models/Message');
const Todo = require('../models/Todo');
const Notification = require('../models/Notification');
const Log = require('../models/Log');
require('dotenv').config();

const seedData = async () => {
  try {
    // 连接数据库
    await mongoose.connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/hm-admin');
    console.log('数据库连接成功');

    // 清空现有数据
    await Promise.all([
      User.deleteMany({}),
      Content.deleteMany({}),
      Message.deleteMany({}),
      Todo.deleteMany({}),
      Notification.deleteMany({}),
      Log.deleteMany({})
    ]);
    console.log('清空现有数据完成');

    // 创建管理员用户
    const adminUser = new User({
      username: 'admin',
      email: 'admin@hm.com',
      password: '123456',
      role: 'admin',
      status: 'active',
      bio: '系统管理员'
    });
    await adminUser.save();
    console.log('管理员用户创建成功');

    // 创建普通用户
    const users = [];
    for (let i = 1; i <= 10; i++) {
      const user = new User({
        username: `user${i}`,
        email: `user${i}@hm.com`,
        password: '123456',
        role: i <= 2 ? 'moderator' : 'user',
        status: 'active',
        bio: `这是用户${i}的个人简介`
      });
      await user.save();
      users.push(user);
    }
    console.log('普通用户创建成功');

    // 创建内容
    const contentTypes = ['article', 'qa', 'code', 'package'];
    for (let i = 1; i <= 20; i++) {
      const content = new Content({
        title: `示例内容标题 ${i}`,
        content: `这是示例内容 ${i} 的详细内容，包含了丰富的信息和技术细节。`,
        summary: `这是内容 ${i} 的摘要`,
        type: contentTypes[i % 4],
        status: i % 3 === 0 ? 'draft' : 'published',
        author: users[i % users.length]._id,
        tags: [`标签${i}`, `技术${i % 3}`],
        views: Math.floor(Math.random() * 1000),
        likes: Math.floor(Math.random() * 100)
      });
      await content.save();
    }
    console.log('示例内容创建成功');

    // 创建留言
    for (let i = 1; i <= 15; i++) {
      const message = new Message({
        user: i % 2 === 0 ? users[i % users.length]._id : null,
        guestName: i % 2 === 0 ? null : `访客${i}`,
        guestEmail: i % 2 === 0 ? null : `guest${i}@example.com`,
        content: `这是留言 ${i} 的内容，感谢你们的优秀工作！`,
        rating: Math.floor(Math.random() * 5) + 1,
        type: ['feedback', 'suggestion', 'complaint', 'question'][i % 4]
      });
      await message.save();
    }
    console.log('示例留言创建成功');

    // 创建待办事项
    const priorities = ['low', 'medium', 'high', 'urgent'];
    const statuses = ['pending', 'in_progress', 'completed'];
    for (let i = 1; i <= 12; i++) {
      const todo = new Todo({
        title: `待办事项 ${i}`,
        description: `这是待办事项 ${i} 的详细描述`,
        status: statuses[i % 3],
        priority: priorities[i % 4],
        creator: adminUser._id,
        assignee: users[i % users.length]._id,
        dueDate: new Date(Date.now() + (i * 24 * 60 * 60 * 1000))
      });
      await todo.save();
    }
    console.log('示例待办事项创建成功');

    // 创建通知
    const notificationTypes = ['system', 'announcement', 'update', 'warning'];
    for (let i = 1; i <= 8; i++) {
      const notification = new Notification({
        title: `系统通知 ${i}`,
        content: `这是系统通知 ${i} 的内容，请注意查看。`,
        type: notificationTypes[i % 4],
        status: i % 2 === 0 ? 'sent' : 'draft',
        creator: adminUser._id,
        priority: i % 3 === 0 ? 'high' : 'medium'
      });
      await notification.save();
    }
    console.log('示例通知创建成功');

    // 创建日志
    const logLevels = ['info', 'warn', 'error', 'debug'];
    for (let i = 1; i <= 50; i++) {
      const log = new Log({
        level: logLevels[i % 4],
        message: `这是日志消息 ${i}`,
        source: `system-${i % 5}`,
        user: i % 3 === 0 ? users[i % users.length]._id : null,
        timestamp: new Date(Date.now() - (i * 60 * 60 * 1000))
      });
      await log.save();
    }
    console.log('示例日志创建成功');

    console.log('数据初始化完成！');
    console.log('管理员账号: admin / 123456');
    
    process.exit(0);
  } catch (error) {
    console.error('数据初始化失败:', error);
    process.exit(1);
  }
};

seedData();
