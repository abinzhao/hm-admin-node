const mongoose = require('mongoose');

const replySchema = new mongoose.Schema({
  content: {
    type: String,
    required: [true, '回复内容不能为空'],
    trim: true
  },
  author: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
});

const messageSchema = new mongoose.Schema({
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  },
  // 匿名用户信息
  guestName: {
    type: String,
    trim: true
  },
  guestEmail: {
    type: String,
    trim: true,
    lowercase: true
  },
  content: {
    type: String,
    required: [true, '留言内容不能为空'],
    trim: true,
    maxlength: [1000, '留言内容不能超过1000个字符']
  },
  contact: {
    type: String,
    trim: true
  },
  rating: {
    type: Number,
    min: 1,
    max: 5
  },
  type: {
    type: String,
    enum: ['feedback', 'suggestion', 'complaint', 'question'],
    default: 'feedback'
  },
  status: {
    type: String,
    enum: ['pending', 'replied', 'closed'],
    default: 'pending'
  },
  priority: {
    type: String,
    enum: ['low', 'medium', 'high'],
    default: 'medium'
  },
  reply: replySchema,
  tags: [{
    type: String,
    trim: true
  }],
  ip: {
    type: String
  },
  userAgent: {
    type: String
  },
  isRead: {
    type: Boolean,
    default: false
  }
}, {
  timestamps: true,
  toJSON: { virtuals: true },
  toObject: { virtuals: true }
});

// 索引
messageSchema.index({ createdAt: -1 });
messageSchema.index({ status: 1 });
messageSchema.index({ type: 1 });
messageSchema.index({ user: 1 });
messageSchema.index({ isRead: 1 });

// 虚拟字段
messageSchema.virtual('isReplied').get(function() {
  return !!this.reply;
});

messageSchema.virtual('displayName').get(function() {
  if (this.user && this.user.username) {
    return this.user.username;
  }
  return this.guestName || '匿名用户';
});

// 实例方法：添加回复
messageSchema.methods.addReply = function(content, authorId) {
  this.reply = {
    content,
    author: authorId,
    createdAt: new Date()
  };
  this.status = 'replied';
  return this.save();
};

// 实例方法：标记为已读
messageSchema.methods.markAsRead = function() {
  this.isRead = true;
  return this.save();
};

// 静态方法：获取未读消息数量
messageSchema.statics.getUnreadCount = function() {
  return this.countDocuments({ isRead: false });
};

// 静态方法：按状态统计
messageSchema.statics.getStatsByStatus = function() {
  return this.aggregate([
    {
      $group: {
        _id: '$status',
        count: { $sum: 1 }
      }
    }
  ]);
};

module.exports = mongoose.model('Message', messageSchema);
