const mongoose = require('mongoose');

const todoSchema = new mongoose.Schema({
  title: {
    type: String,
    required: [true, '标题不能为空'],
    trim: true,
    maxlength: [100, '标题不能超过100个字符']
  },
  description: {
    type: String,
    trim: true,
    maxlength: [500, '描述不能超过500个字符']
  },
  status: {
    type: String,
    enum: ['pending', 'in_progress', 'completed'],
    default: 'pending'
  },
  priority: {
    type: String,
    enum: ['low', 'medium', 'high', 'urgent'],
    default: 'medium'
  },
  assignee: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  },
  creator: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  dueDate: {
    type: Date
  },
  completedAt: {
    type: Date
  },
  tags: [{
    type: String,
    trim: true
  }],
  category: {
    type: String,
    trim: true
  },
  progress: {
    type: Number,
    min: 0,
    max: 100,
    default: 0
  },
  estimatedHours: {
    type: Number,
    min: 0
  },
  actualHours: {
    type: Number,
    min: 0
  },
  attachments: [{
    filename: String,
    originalName: String,
    mimetype: String,
    size: Number,
    url: String
  }],
  comments: [{
    content: {
      type: String,
      required: true
    },
    author: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true
    },
    createdAt: {
      type: Date,
      default: Date.now
    }
  }]
}, {
  timestamps: true,
  toJSON: { virtuals: true },
  toObject: { virtuals: true }
});

// 索引
todoSchema.index({ status: 1 });
todoSchema.index({ priority: 1 });
todoSchema.index({ assignee: 1 });
todoSchema.index({ creator: 1 });
todoSchema.index({ dueDate: 1 });
todoSchema.index({ createdAt: -1 });

// 虚拟字段
todoSchema.virtual('isOverdue').get(function() {
  return this.dueDate && this.dueDate < new Date() && this.status !== 'completed';
});

todoSchema.virtual('isCompleted').get(function() {
  return this.status === 'completed';
});

// 中间件：完成时设置完成时间
todoSchema.pre('save', function(next) {
  if (this.isModified('status')) {
    if (this.status === 'completed' && !this.completedAt) {
      this.completedAt = new Date();
      this.progress = 100;
    } else if (this.status !== 'completed') {
      this.completedAt = undefined;
    }
  }
  next();
});

// 实例方法：添加评论
todoSchema.methods.addComment = function(content, authorId) {
  this.comments.push({
    content,
    author: authorId,
    createdAt: new Date()
  });
  return this.save();
};

// 实例方法：更新进度
todoSchema.methods.updateProgress = function(progress) {
  this.progress = Math.max(0, Math.min(100, progress));
  
  // 自动更新状态
  if (this.progress === 0) {
    this.status = 'pending';
  } else if (this.progress === 100) {
    this.status = 'completed';
  } else {
    this.status = 'in_progress';
  }
  
  return this.save();
};

// 静态方法：获取逾期任务
todoSchema.statics.getOverdueTodos = function() {
  return this.find({
    dueDate: { $lt: new Date() },
    status: { $ne: 'completed' }
  }).populate('assignee creator', 'username email');
};

// 静态方法：按状态统计
todoSchema.statics.getStatsByStatus = function() {
  return this.aggregate([
    {
      $group: {
        _id: '$status',
        count: { $sum: 1 }
      }
    }
  ]);
};

// 静态方法：按优先级统计
todoSchema.statics.getStatsByPriority = function() {
  return this.aggregate([
    {
      $group: {
        _id: '$priority',
        count: { $sum: 1 }
      }
    }
  ]);
};

module.exports = mongoose.model('Todo', todoSchema);
