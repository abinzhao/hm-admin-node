const mongoose = require('mongoose');

const contentSchema = new mongoose.Schema({
  title: {
    type: String,
    required: [true, '标题不能为空'],
    trim: true,
    maxlength: [100, '标题不能超过100个字符']
  },
  content: {
    type: String,
    required: [true, '内容不能为空']
  },
  summary: {
    type: String,
    maxlength: [300, '摘要不能超过300个字符']
  },
  type: {
    type: String,
    enum: ['article', 'qa', 'code', 'package'],
    required: [true, '内容类型不能为空']
  },
  status: {
    type: String,
    enum: ['draft', 'published', 'archived'],
    default: 'draft'
  },
  author: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  tags: [{
    type: String,
    trim: true
  }],
  category: {
    type: String,
    trim: true
  },
  views: {
    type: Number,
    default: 0
  },
  likes: {
    type: Number,
    default: 0
  },
  comments: {
    type: Number,
    default: 0
  },
  featured: {
    type: Boolean,
    default: false
  },
  allowComments: {
    type: Boolean,
    default: true
  },
  publishedAt: {
    type: Date
  },
  attachments: [{
    filename: String,
    originalName: String,
    mimetype: String,
    size: Number,
    url: String
  }],
  metadata: {
    readTime: Number, // 预计阅读时间（分钟）
    difficulty: {
      type: String,
      enum: ['beginner', 'intermediate', 'advanced']
    },
    language: String, // 编程语言（针对代码类型）
    version: String   // 版本信息（针对软件包类型）
  }
}, {
  timestamps: true,
  toJSON: { virtuals: true },
  toObject: { virtuals: true }
});

// 索引
contentSchema.index({ title: 'text', content: 'text', summary: 'text' });
contentSchema.index({ type: 1, status: 1 });
contentSchema.index({ author: 1 });
contentSchema.index({ createdAt: -1 });
contentSchema.index({ views: -1 });
contentSchema.index({ likes: -1 });
contentSchema.index({ tags: 1 });

// 虚拟字段
contentSchema.virtual('isPublished').get(function() {
  return this.status === 'published';
});

// 中间件：发布时设置发布时间
contentSchema.pre('save', function(next) {
  if (this.isModified('status') && this.status === 'published' && !this.publishedAt) {
    this.publishedAt = new Date();
  }
  next();
});

// 实例方法：增加浏览量
contentSchema.methods.incrementViews = function() {
  this.views += 1;
  return this.save();
};

// 实例方法：切换点赞
contentSchema.methods.toggleLike = function(increment = true) {
  this.likes += increment ? 1 : -1;
  if (this.likes < 0) this.likes = 0;
  return this.save();
};

// 静态方法：获取热门内容
contentSchema.statics.getPopularContent = function(limit = 10) {
  return this.find({ status: 'published' })
    .sort({ views: -1, likes: -1 })
    .limit(limit)
    .populate('author', 'username avatar');
};

// 静态方法：按类型统计
contentSchema.statics.getStatsByType = function() {
  return this.aggregate([
    {
      $group: {
        _id: '$type',
        count: { $sum: 1 },
        totalViews: { $sum: '$views' },
        totalLikes: { $sum: '$likes' }
      }
    }
  ]);
};

module.exports = mongoose.model('Content', contentSchema);
