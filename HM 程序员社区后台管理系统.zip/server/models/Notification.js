const mongoose = require('mongoose');

const notificationSchema = new mongoose.Schema({
  title: {
    type: String,
    required: [true, '通知标题不能为空'],
    trim: true,
    maxlength: [100, '标题不能超过100个字符']
  },
  content: {
    type: String,
    required: [true, '通知内容不能为空'],
    trim: true
  },
  type: {
    type: String,
    enum: ['system', 'announcement', 'update', 'warning'],
    required: [true, '通知类型不能为空']
  },
  status: {
    type: String,
    enum: ['draft', 'sent', 'scheduled'],
    default: 'draft'
  },
  priority: {
    type: String,
    enum: ['low', 'medium', 'high'],
    default: 'medium'
  },
  creator: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  targetUsers: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  }],
  targetRoles: [{
    type: String,
    enum: ['admin', 'moderator', 'user']
  }],
  scheduledAt: {
    type: Date
  },
  sentAt: {
    type: Date
  },
  readBy: [{
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User'
    },
    readAt: {
      type: Date,
      default: Date.now
    }
  }],
  sendEmail: {
    type: Boolean,
    default: false
  },
  sendSMS: {
    type: Boolean,
    default: false
  },
  sendPush: {
    type: Boolean,
    default: true
  },
  metadata: {
    totalRecipients: {
      type: Number,
      default: 0
    },
    totalRead: {
      type: Number,
      default: 0
    },
    clickCount: {
      type: Number,
      default: 0
    }
  }
}, {
  timestamps: true,
  toJSON: { virtuals: true },
  toObject: { virtuals: true }
});

// 索引
notificationSchema.index({ type: 1, status: 1 });
notificationSchema.index({ creator: 1 });
notificationSchema.index({ scheduledAt: 1 });
notificationSchema.index({ createdAt: -1 });
notificationSchema.index({ 'readBy.user': 1 });

// 虚拟字段
notificationSchema.virtual('isSent').get(function() {
  return this.status === 'sent';
});

notificationSchema.virtual('readRate').get(function() {
  if (this.metadata.totalRecipients === 0) return 0;
  return (this.metadata.totalRead / this.metadata.totalRecipients * 100).toFixed(2);
});

// 实例方法：发送通知
notificationSchema.methods.send = async function() {
  this.status = 'sent';
  this.sentAt = new Date();
  
  // 计算目标用户数量
  let targetCount = 0;
  if (this.targetUsers.length > 0) {
    targetCount = this.targetUsers.length;
  } else {
    // 如果没有指定用户，发送给所有用户或指定角色的用户
    const User = mongoose.model('User');
    const query = this.targetRoles.length > 0 
      ? { role: { $in: this.targetRoles } }
      : {};
    targetCount = await User.countDocuments(query);
  }
  
  this.metadata.totalRecipients = targetCount;
  return this.save();
};

// 实例方法：标记为已读
notificationSchema.methods.markAsRead = function(userId) {
  const existingRead = this.readBy.find(r => r.user.toString() === userId.toString());
  if (!existingRead) {
    this.readBy.push({ user: userId, readAt: new Date() });
    this.metadata.totalRead += 1;
    return this.save();
  }
  return Promise.resolve(this);
};

// 实例方法：增加点击次数
notificationSchema.methods.incrementClick = function() {
  this.metadata.clickCount += 1;
  return this.save();
};

// 静态方法：获取用户未读通知
notificationSchema.statics.getUnreadForUser = function(userId) {
  return this.find({
    status: 'sent',
    $or: [
      { targetUsers: userId },
      { targetUsers: { $size: 0 } }
    ],
    'readBy.user': { $ne: userId }
  }).sort({ createdAt: -1 });
};

// 静态方法：按类型统计
notificationSchema.statics.getStatsByType = function() {
  return this.aggregate([
    {
      $group: {
        _id: '$type',
        count: { $sum: 1 },
        sent: {
          $sum: {
            $cond: [{ $eq: ['$status', 'sent'] }, 1, 0]
          }
        }
      }
    }
  ]);
};

module.exports = mongoose.model('Notification', notificationSchema);
