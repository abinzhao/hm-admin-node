const mongoose = require('mongoose');

const logSchema = new mongoose.Schema({
  level: {
    type: String,
    enum: ['info', 'warn', 'error', 'debug'],
    required: true
  },
  message: {
    type: String,
    required: [true, '日志消息不能为空']
  },
  source: {
    type: String,
    trim: true
  },
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  },
  ip: {
    type: String
  },
  userAgent: {
    type: String
  },
  method: {
    type: String
  },
  url: {
    type: String
  },
  statusCode: {
    type: Number
  },
  responseTime: {
    type: Number
  },
  metadata: {
    type: mongoose.Schema.Types.Mixed
  },
  timestamp: {
    type: Date,
    default: Date.now
  }
}, {
  timestamps: false,
  capped: { size: 100000000, max: 1000000 } // 限制集合大小
});

// 索引
logSchema.index({ timestamp: -1 });
logSchema.index({ level: 1, timestamp: -1 });
logSchema.index({ source: 1, timestamp: -1 });
logSchema.index({ user: 1, timestamp: -1 });

// 静态方法：清理旧日志
logSchema.statics.cleanOldLogs = function(days = 30) {
  const cutoffDate = new Date();
  cutoffDate.setDate(cutoffDate.getDate() - days);
  
  return this.deleteMany({
    timestamp: { $lt: cutoffDate }
  });
};

// 静态方法：按级别统计
logSchema.statics.getStatsByLevel = function(startDate, endDate) {
  const match = {};
  if (startDate || endDate) {
    match.timestamp = {};
    if (startDate) match.timestamp.$gte = new Date(startDate);
    if (endDate) match.timestamp.$lte = new Date(endDate);
  }

  return this.aggregate([
    { $match: match },
    {
      $group: {
        _id: '$level',
        count: { $sum: 1 }
      }
    }
  ]);
};

// 静态方法：按时间统计
logSchema.statics.getStatsByTime = function(startDate, endDate, interval = 'hour') {
  const match = {};
  if (startDate || endDate) {
    match.timestamp = {};
    if (startDate) match.timestamp.$gte = new Date(startDate);
    if (endDate) match.timestamp.$lte = new Date(endDate);
  }

  let dateFormat;
  switch (interval) {
    case 'hour':
      dateFormat = '%Y-%m-%d %H:00:00';
      break;
    case 'day':
      dateFormat = '%Y-%m-%d';
      break;
    case 'month':
      dateFormat = '%Y-%m';
      break;
    default:
      dateFormat = '%Y-%m-%d %H:00:00';
  }

  return this.aggregate([
    { $match: match },
    {
      $group: {
        _id: {
          time: { $dateToString: { format: dateFormat, date: '$timestamp' } },
          level: '$level'
        },
        count: { $sum: 1 }
      }
    },
    {
      $group: {
        _id: '$_id.time',
        levels: {
          $push: {
            level: '$_id.level',
            count: '$count'
          }
        },
        total: { $sum: '$count' }
      }
    },
    { $sort: { _id: 1 } }
  ]);
};

module.exports = mongoose.model('Log', logSchema);
