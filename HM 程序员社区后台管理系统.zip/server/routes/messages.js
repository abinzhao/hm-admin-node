const express = require('express');
const Message = require('../models/Message');
const { auth, moderatorAuth } = require('../middleware/auth');
const router = express.Router();

// 获取留言列表
router.get('/', auth, moderatorAuth, async (req, res) => {
  try {
    const { page = 1, limit = 10, keyword, status } = req.query;
    const query = {};

    if (keyword) {
      query.$or = [
        { content: { $regex: keyword, $options: 'i' } },
        { guestName: { $regex: keyword, $options: 'i' } }
      ];
    }

    if (status === 'replied') {
      query.reply = { $exists: true };
    } else if (status === 'pending') {
      query.reply = { $exists: false };
    }

    const messages = await Message.find(query)
      .populate('user', 'username email avatar')
      .populate('reply.author', 'username')
      .sort({ createdAt: -1 })
      .limit(limit * 1)
      .skip((page - 1) * limit);

    const total = await Message.countDocuments(query);

    res.json({
      success: true,
      messages,
      total,
      page: parseInt(page),
      pages: Math.ceil(total / limit)
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: '获取留言列表失败'
    });
  }
});

// 回复留言
router.post('/:id/reply', auth, moderatorAuth, async (req, res) => {
  try {
    const { reply } = req.body;
    const message = await Message.findById(req.params.id);

    if (!message) {
      return res.status(404).json({
        success: false,
        message: '留言不存在'
      });
    }

    await message.addReply(reply, req.user._id);
    await message.populate('reply.author', 'username');

    res.json({
      success: true,
      message
    });
  } catch (error) {
    res.status(400).json({
      success: false,
      message: error.message
    });
  }
});

// 删除留言
router.delete('/:id', auth, moderatorAuth, async (req, res) => {
  try {
    const message = await Message.findByIdAndDelete(req.params.id);

    if (!message) {
      return res.status(404).json({
        success: false,
        message: '留言不存在'
      });
    }

    res.json({
      success: true,
      message: '留言删除成功'
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: '删除留言失败'
    });
  }
});

module.exports = router;
