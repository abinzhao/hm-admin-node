const express = require('express');
const Content = require('../models/Content');
const { auth, moderatorAuth } = require('../middleware/auth');
const router = express.Router();

// 获取内容列表
router.get('/', auth, async (req, res) => {
  try {
    const { page = 1, limit = 10, keyword, type, status } = req.query;
    const query = {};

    if (keyword) {
      query.$text = { $search: keyword };
    }

    if (type) query.type = type;
    if (status) query.status = status;

    const content = await Content.find(query)
      .populate('author', 'username avatar')
      .sort({ createdAt: -1 })
      .limit(limit * 1)
      .skip((page - 1) * limit);

    const total = await Content.countDocuments(query);

    res.json({
      success: true,
      content,
      total,
      page: parseInt(page),
      pages: Math.ceil(total / limit)
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: '获取内容列表失败'
    });
  }
});

// 创建内容
router.post('/', auth, moderatorAuth, async (req, res) => {
  try {
    const content = new Content({
      ...req.body,
      author: req.user._id
    });
    await content.save();

    const populatedContent = await Content.findById(content._id)
      .populate('author', 'username avatar');

    res.status(201).json({
      success: true,
      content: populatedContent
    });
  } catch (error) {
    res.status(400).json({
      success: false,
      message: error.message
    });
  }
});

// 更新内容
router.put('/:id', auth, moderatorAuth, async (req, res) => {
  try {
    const content = await Content.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true, runValidators: true }
    ).populate('author', 'username avatar');

    if (!content) {
      return res.status(404).json({
        success: false,
        message: '内容不存在'
      });
    }

    res.json({
      success: true,
      content
    });
  } catch (error) {
    res.status(400).json({
      success: false,
      message: error.message
    });
  }
});

// 删除内容
router.delete('/:id', auth, moderatorAuth, async (req, res) => {
  try {
    const content = await Content.findByIdAndDelete(req.params.id);

    if (!content) {
      return res.status(404).json({
        success: false,
        message: '内容不存在'
      });
    }

    res.json({
      success: true,
      message: '内容删除成功'
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: '删除内容失败'
    });
  }
});

module.exports = router;
