const express = require('express');
const Log = require('../models/Log');
const User = require('../models/User');
const Content = require('../models/Content');
const Message = require('../models/Message');
const { auth, adminAuth } = require('../middleware/auth');
const router = express.Router();

// 获取日志列表
router.get('/', auth, adminAuth, async (req, res) => {
  try {
    const { page = 1, limit = 10, level, source, startDate, endDate } = req.query;
    const query = {};

    if (level) query.level = level;
    if (source) query.source = { $regex: source, $options: 'i' };
    
    if (startDate || endDate) {
      query.timestamp = {};
      if (startDate) query.timestamp.$gte = new Date(startDate);
      if (endDate) query.timestamp.$lte = new Date(endDate);
    }

    const logs = await Log.find(query)
      .populate('user', 'username')
      .sort({ timestamp: -1 })
      .limit(limit * 1)
      .skip((page - 1) * limit);

    const total = await Log.countDocuments(query);

    res.json({
      success: true,
      logs,
      total,
      page: parseInt(page),
      pages: Math.ceil(total / limit)
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: '获取日志列表失败'
    });
  }
});

// 获取系统统计
router.get('/stats', auth, adminAuth, async (req, res) => {
  try {
    const [
      totalUsers,
      totalContent,
      totalMessages,
      todayVisits
    ] = await Promise.all([
      User.countDocuments(),
      Content.countDocuments(),
      Message.countDocuments(),
      Log.countDocuments({
        timestamp: {
          $gte: new Date(new Date().setHours(0, 0, 0, 0))
        }
      })
    ]);

    res.json({
      success: true,
      stats: {
        totalUsers,
        totalContent,
        totalMessages,
        todayVisits
      }
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: '获取系统统计失败'
    });
  }
});

module.exports = router;
