const express = require('express');
const Notification = require('../models/Notification');
const { auth, adminAuth } = require('../middleware/auth');
const router = express.Router();

// 获取通知列表
router.get('/', auth, adminAuth, async (req, res) => {
  try {
    const { page = 1, limit = 10, keyword, type, status } = req.query;
    const query = {};

    if (keyword) {
      query.$or = [
        { title: { $regex: keyword, $options: 'i' } },
        { content: { $regex: keyword, $options: 'i' } }
      ];
    }

    if (type) query.type = type;
    if (status) query.status = status;

    const notifications = await Notification.find(query)
      .populate('creator', 'username avatar')
      .sort({ createdAt: -1 })
      .limit(limit * 1)
      .skip((page - 1) * limit);

    const total = await Notification.countDocuments(query);

    res.json({
      success: true,
      notifications,
      total,
      page: parseInt(page),
      pages: Math.ceil(total / limit)
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: '获取通知列表失败'
    });
  }
});

// 创建通知
router.post('/', auth, adminAuth, async (req, res) => {
  try {
    const notification = new Notification({
      ...req.body,
      creator: req.user._id
    });
    await notification.save();

    const populatedNotification = await Notification.findById(notification._id)
      .populate('creator', 'username avatar');

    res.status(201).json({
      success: true,
      notification: populatedNotification
    });
  } catch (error) {
    res.status(400).json({
      success: false,
      message: error.message
    });
  }
});

// 发送通知
router.post('/:id/send', auth, adminAuth, async (req, res) => {
  try {
    const notification = await Notification.findById(req.params.id);

    if (!notification) {
      return res.status(404).json({
        success: false,
        message: '通知不存在'
      });
    }

    await notification.send();

    res.json({
      success: true,
      notification
    });
  } catch (error) {
    res.status(400).json({
      success: false,
      message: error.message
    });
  }
});

// 删除通知
router.delete('/:id', auth, adminAuth, async (req, res) => {
  try {
    const notification = await Notification.findByIdAndDelete(req.params.id);

    if (!notification) {
      return res.status(404).json({
        success: false,
        message: '通知不存在'
      });
    }

    res.json({
      success: true,
      message: '通知删除成功'
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: '删除通知失败'
    });
  }
});

module.exports = router;
