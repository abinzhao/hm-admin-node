const express = require('express');
const Todo = require('../models/Todo');
const { auth } = require('../middleware/auth');
const router = express.Router();

// 获取待办事项列表
router.get('/', auth, async (req, res) => {
  try {
    const { page = 1, limit = 10, keyword, status, priority } = req.query;
    const query = {};

    if (keyword) {
      query.$or = [
        { title: { $regex: keyword, $options: 'i' } },
        { description: { $regex: keyword, $options: 'i' } }
      ];
    }

    if (status) query.status = status;
    if (priority) query.priority = priority;

    const todos = await Todo.find(query)
      .populate('assignee', 'username avatar')
      .populate('creator', 'username avatar')
      .sort({ createdAt: -1 })
      .limit(limit * 1)
      .skip((page - 1) * limit);

    const total = await Todo.countDocuments(query);

    res.json({
      success: true,
      todos,
      total,
      page: parseInt(page),
      pages: Math.ceil(total / limit)
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: '获取待办事项失败'
    });
  }
});

// 创建待办事项
router.post('/', auth, async (req, res) => {
  try {
    const todo = new Todo({
      ...req.body,
      creator: req.user._id
    });
    await todo.save();

    const populatedTodo = await Todo.findById(todo._id)
      .populate('assignee', 'username avatar')
      .populate('creator', 'username avatar');

    res.status(201).json({
      success: true,
      todo: populatedTodo
    });
  } catch (error) {
    res.status(400).json({
      success: false,
      message: error.message
    });
  }
});

// 更新待办事项
router.put('/:id', auth, async (req, res) => {
  try {
    const todo = await Todo.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true, runValidators: true }
    ).populate('assignee', 'username avatar')
     .populate('creator', 'username avatar');

    if (!todo) {
      return res.status(404).json({
        success: false,
        message: '待办事项不存在'
      });
    }

    res.json({
      success: true,
      todo
    });
  } catch (error) {
    res.status(400).json({
      success: false,
      message: error.message
    });
  }
});

// 删除待办事项
router.delete('/:id', auth, async (req, res) => {
  try {
    const todo = await Todo.findByIdAndDelete(req.params.id);

    if (!todo) {
      return res.status(404).json({
        success: false,
        message: '待办事项不存在'
      });
    }

    res.json({
      success: true,
      message: '待办事项删除成功'
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: '删除待办事项失败'
    });
  }
});

module.exports = router;
