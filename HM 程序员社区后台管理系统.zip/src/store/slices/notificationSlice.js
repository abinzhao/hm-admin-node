import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import api from '../../utils/api';

// 获取通知列表
export const fetchNotifications = createAsyncThunk(
  'notifications/fetchNotifications',
  async (params = {}, { rejectWithValue }) => {
    try {
      const response = await api.get('/notifications', { params });
      return response.data;
    } catch (error) {
      return rejectWithValue(error.response?.data?.message || '获取通知列表失败');
    }
  }
);

// 创建通知
export const createNotification = createAsyncThunk(
  'notifications/createNotification',
  async (notificationData, { rejectWithValue }) => {
    try {
      const response = await api.post('/notifications', notificationData);
      return response.data;
    } catch (error) {
      return rejectWithValue(error.response?.data?.message || '创建通知失败');
    }
  }
);

// 发送通知
export const sendNotification = createAsyncThunk(
  'notifications/sendNotification',
  async (id, { rejectWithValue }) => {
    try {
      const response = await api.post(`/notifications/${id}/send`);
      return response.data;
    } catch (error) {
      return rejectWithValue(error.response?.data?.message || '发送通知失败');
    }
  }
);

// 删除通知
export const deleteNotification = createAsyncThunk(
  'notifications/deleteNotification',
  async (id, { rejectWithValue }) => {
    try {
      await api.delete(`/notifications/${id}`);
      return id;
    } catch (error) {
      return rejectWithValue(error.response?.data?.message || '删除通知失败');
    }
  }
);

const notificationSlice = createSlice({
  name: 'notifications',
  initialState: {
    list: [],
    total: 0,
    loading: false,
    error: null,
    currentPage: 1,
    pageSize: 10
  },
  reducers: {
    setCurrentPage: (state, action) => {
      state.currentPage = action.payload;
    },
    setPageSize: (state, action) => {
      state.pageSize = action.payload;
    },
    clearError: (state) => {
      state.error = null;
    }
  },
  extraReducers: (builder) => {
    builder
      .addCase(fetchNotifications.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchNotifications.fulfilled, (state, action) => {
        state.loading = false;
        state.list = action.payload.notifications;
        state.total = action.payload.total;
      })
      .addCase(fetchNotifications.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      })
      .addCase(createNotification.fulfilled, (state, action) => {
        state.list.unshift(action.payload.notification);
        state.total += 1;
      })
      .addCase(sendNotification.fulfilled, (state, action) => {
        const index = state.list.findIndex(notif => notif._id === action.payload.notification._id);
        if (index !== -1) {
          state.list[index] = action.payload.notification;
        }
      })
      .addCase(deleteNotification.fulfilled, (state, action) => {
        state.list = state.list.filter(notif => notif._id !== action.payload);
        state.total -= 1;
      });
  }
});

export const { setCurrentPage, setPageSize, clearError } = notificationSlice.actions;
export default notificationSlice.reducer;
