import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import api from '../../utils/api';

// 获取日志列表
export const fetchLogs = createAsyncThunk(
  'logs/fetchLogs',
  async (params = {}, { rejectWithValue }) => {
    try {
      const response = await api.get('/logs', { params });
      return response.data;
    } catch (error) {
      return rejectWithValue(error.response?.data?.message || '获取日志列表失败');
    }
  }
);

// 获取系统统计
export const fetchSystemStats = createAsyncThunk(
  'logs/fetchSystemStats',
  async (_, { rejectWithValue }) => {
    try {
      const response = await api.get('/logs/stats');
      return response.data;
    } catch (error) {
      return rejectWithValue(error.response?.data?.message || '获取系统统计失败');
    }
  }
);

const logSlice = createSlice({
  name: 'logs',
  initialState: {
    list: [],
    total: 0,
    loading: false,
    error: null,
    currentPage: 1,
    pageSize: 10,
    stats: {
      totalUsers: 0,
      totalContent: 0,
      totalMessages: 0,
      todayVisits: 0
    }
  },
  reducers: {
    setCurrentPage: (state, action) => {
      state.currentPage = action.payload;
    },
    setPageSize: (state, action) => {
      state.pageSize = action.payload;
    },
    clearError: (state) => {
      state.error = null;
    }
  },
  extraReducers: (builder) => {
    builder
      .addCase(fetchLogs.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchLogs.fulfilled, (state, action) => {
        state.loading = false;
        state.list = action.payload.logs;
        state.total = action.payload.total;
      })
      .addCase(fetchLogs.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      })
      .addCase(fetchSystemStats.fulfilled, (state, action) => {
        state.stats = action.payload.stats;
      });
  }
});

export const { setCurrentPage, setPageSize, clearError } = logSlice.actions;
export default logSlice.reducer;
