import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import api from '../../utils/api';

// 获取内容列表
export const fetchContent = createAsyncThunk(
  'content/fetchContent',
  async (params = {}, { rejectWithValue }) => {
    try {
      const response = await api.get('/content', { params });
      return response.data;
    } catch (error) {
      return rejectWithValue(error.response?.data?.message || '获取内容列表失败');
    }
  }
);

// 创建内容
export const createContent = createAsyncThunk(
  'content/createContent',
  async (contentData, { rejectWithValue }) => {
    try {
      const response = await api.post('/content', contentData);
      return response.data;
    } catch (error) {
      return rejectWithValue(error.response?.data?.message || '创建内容失败');
    }
  }
);

// 更新内容
export const updateContent = createAsyncThunk(
  'content/updateContent',
  async ({ id, contentData }, { rejectWithValue }) => {
    try {
      const response = await api.put(`/content/${id}`, contentData);
      return response.data;
    } catch (error) {
      return rejectWithValue(error.response?.data?.message || '更新内容失败');
    }
  }
);

// 删除内容
export const deleteContent = createAsyncThunk(
  'content/deleteContent',
  async (id, { rejectWithValue }) => {
    try {
      await api.delete(`/content/${id}`);
      return id;
    } catch (error) {
      return rejectWithValue(error.response?.data?.message || '删除内容失败');
    }
  }
);

const contentSlice = createSlice({
  name: 'content',
  initialState: {
    list: [],
    total: 0,
    loading: false,
    error: null,
    currentPage: 1,
    pageSize: 10,
    filters: {
      type: '',
      status: '',
      keyword: ''
    }
  },
  reducers: {
    setCurrentPage: (state, action) => {
      state.currentPage = action.payload;
    },
    setPageSize: (state, action) => {
      state.pageSize = action.payload;
    },
    setFilters: (state, action) => {
      state.filters = { ...state.filters, ...action.payload };
    },
    clearError: (state) => {
      state.error = null;
    }
  },
  extraReducers: (builder) => {
    builder
      .addCase(fetchContent.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchContent.fulfilled, (state, action) => {
        state.loading = false;
        state.list = action.payload.content;
        state.total = action.payload.total;
      })
      .addCase(fetchContent.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      })
      .addCase(createContent.fulfilled, (state, action) => {
        state.list.unshift(action.payload.content);
        state.total += 1;
      })
      .addCase(updateContent.fulfilled, (state, action) => {
        const index = state.list.findIndex(item => item._id === action.payload.content._id);
        if (index !== -1) {
          state.list[index] = action.payload.content;
        }
      })
      .addCase(deleteContent.fulfilled, (state, action) => {
        state.list = state.list.filter(item => item._id !== action.payload);
        state.total -= 1;
      });
  }
});

export const { setCurrentPage, setPageSize, setFilters, clearError } = contentSlice.actions;
export default contentSlice.reducer;
