import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import api from '../../utils/api';

// 获取待办事项列表
export const fetchTodos = createAsyncThunk(
  'todos/fetchTodos',
  async (params = {}, { rejectWithValue }) => {
    try {
      const response = await api.get('/todos', { params });
      return response.data;
    } catch (error) {
      return rejectWithValue(error.response?.data?.message || '获取待办事项失败');
    }
  }
);

// 创建待办事项
export const createTodo = createAsyncThunk(
  'todos/createTodo',
  async (todoData, { rejectWithValue }) => {
    try {
      const response = await api.post('/todos', todoData);
      return response.data;
    } catch (error) {
      return rejectWithValue(error.response?.data?.message || '创建待办事项失败');
    }
  }
);

// 更新待办事项
export const updateTodo = createAsyncThunk(
  'todos/updateTodo',
  async ({ id, todoData }, { rejectWithValue }) => {
    try {
      const response = await api.put(`/todos/${id}`, todoData);
      return response.data;
    } catch (error) {
      return rejectWithValue(error.response?.data?.message || '更新待办事项失败');
    }
  }
);

// 删除待办事项
export const deleteTodo = createAsyncThunk(
  'todos/deleteTodo',
  async (id, { rejectWithValue }) => {
    try {
      await api.delete(`/todos/${id}`);
      return id;
    } catch (error) {
      return rejectWithValue(error.response?.data?.message || '删除待办事项失败');
    }
  }
);

const todoSlice = createSlice({
  name: 'todos',
  initialState: {
    list: [],
    total: 0,
    loading: false,
    error: null,
    currentPage: 1,
    pageSize: 10
  },
  reducers: {
    setCurrentPage: (state, action) => {
      state.currentPage = action.payload;
    },
    setPageSize: (state, action) => {
      state.pageSize = action.payload;
    },
    clearError: (state) => {
      state.error = null;
    }
  },
  extraReducers: (builder) => {
    builder
      .addCase(fetchTodos.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchTodos.fulfilled, (state, action) => {
        state.loading = false;
        state.list = action.payload.todos;
        state.total = action.payload.total;
      })
      .addCase(fetchTodos.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      })
      .addCase(createTodo.fulfilled, (state, action) => {
        state.list.unshift(action.payload.todo);
        state.total += 1;
      })
      .addCase(updateTodo.fulfilled, (state, action) => {
        const index = state.list.findIndex(todo => todo._id === action.payload.todo._id);
        if (index !== -1) {
          state.list[index] = action.payload.todo;
        }
      })
      .addCase(deleteTodo.fulfilled, (state, action) => {
        state.list = state.list.filter(todo => todo._id !== action.payload);
        state.total -= 1;
      });
  }
});

export const { setCurrentPage, setPageSize, clearError } = todoSlice.actions;
export default todoSlice.reducer;
