import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import api from '../../utils/api';

// 获取留言列表
export const fetchMessages = createAsyncThunk(
  'messages/fetchMessages',
  async (params = {}, { rejectWithValue }) => {
    try {
      const response = await api.get('/messages', { params });
      return response.data;
    } catch (error) {
      return rejectWithValue(error.response?.data?.message || '获取留言列表失败');
    }
  }
);

// 回复留言
export const replyMessage = createAsyncThunk(
  'messages/replyMessage',
  async ({ id, reply }, { rejectWithValue }) => {
    try {
      const response = await api.post(`/messages/${id}/reply`, { reply });
      return response.data;
    } catch (error) {
      return rejectWithValue(error.response?.data?.message || '回复留言失败');
    }
  }
);

// 删除留言
export const deleteMessage = createAsyncThunk(
  'messages/deleteMessage',
  async (id, { rejectWithValue }) => {
    try {
      await api.delete(`/messages/${id}`);
      return id;
    } catch (error) {
      return rejectWithValue(error.response?.data?.message || '删除留言失败');
    }
  }
);

const messageSlice = createSlice({
  name: 'messages',
  initialState: {
    list: [],
    total: 0,
    loading: false,
    error: null,
    currentPage: 1,
    pageSize: 10
  },
  reducers: {
    setCurrentPage: (state, action) => {
      state.currentPage = action.payload;
    },
    setPageSize: (state, action) => {
      state.pageSize = action.payload;
    },
    clearError: (state) => {
      state.error = null;
    }
  },
  extraReducers: (builder) => {
    builder
      .addCase(fetchMessages.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchMessages.fulfilled, (state, action) => {
        state.loading = false;
        state.list = action.payload.messages;
        state.total = action.payload.total;
      })
      .addCase(fetchMessages.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      })
      .addCase(replyMessage.fulfilled, (state, action) => {
        const index = state.list.findIndex(msg => msg._id === action.payload.message._id);
        if (index !== -1) {
          state.list[index] = action.payload.message;
        }
      })
      .addCase(deleteMessage.fulfilled, (state, action) => {
        state.list = state.list.filter(msg => msg._id !== action.payload);
        state.total -= 1;
      });
  }
});

export const { setCurrentPage, setPageSize, clearError } = messageSlice.actions;
export default messageSlice.reducer;
