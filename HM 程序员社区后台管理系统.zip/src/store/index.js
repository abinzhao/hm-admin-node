import { configureStore } from '@reduxjs/toolkit';
import authSlice from './slices/authSlice';
import userSlice from './slices/userSlice';
import contentSlice from './slices/contentSlice';
import messageSlice from './slices/messageSlice';
import todoSlice from './slices/todoSlice';
import notificationSlice from './slices/notificationSlice';
import logSlice from './slices/logSlice';

export const store = configureStore({
  reducer: {
    auth: authSlice,
    users: userSlice,
    content: contentSlice,
    messages: messageSlice,
    todos: todoSlice,
    notifications: notificationSlice,
    logs: logSlice
  },
  middleware: (getDefaultMiddleware) =>
    getDefaultMiddleware({
      serializableCheck: {
        ignoredActions: ['persist/PERSIST']
      }
    })
});
