// 用户角色
export const USER_ROLES = {
  ADMIN: 'admin',
  MODERATOR: 'moderator',
  USER: 'user'
};

// 用户状态
export const USER_STATUS = {
  ACTIVE: 'active',
  INACTIVE: 'inactive',
  BANNED: 'banned'
};

// 内容类型
export const CONTENT_TYPES = {
  ARTICLE: 'article',
  QA: 'qa',
  CODE: 'code',
  PACKAGE: 'package'
};

// 内容状态
export const CONTENT_STATUS = {
  DRAFT: 'draft',
  PUBLISHED: 'published',
  ARCHIVED: 'archived'
};

// 待办事项状态
export const TODO_STATUS = {
  PENDING: 'pending',
  IN_PROGRESS: 'in_progress',
  COMPLETED: 'completed'
};

// 待办事项优先级
export const TODO_PRIORITY = {
  LOW: 'low',
  MEDIUM: 'medium',
  HIGH: 'high',
  URGENT: 'urgent'
};

// 通知类型
export const NOTIFICATION_TYPES = {
  SYSTEM: 'system',
  ANNOUNCEMENT: 'announcement',
  UPDATE: 'update',
  WARNING: 'warning'
};

// 通知状态
export const NOTIFICATION_STATUS = {
  DRAFT: 'draft',
  SENT: 'sent',
  SCHEDULED: 'scheduled'
};

// 日志级别
export const LOG_LEVELS = {
  INFO: 'info',
  WARN: 'warn',
  ERROR: 'error',
  DEBUG: 'debug'
};

// 分页配置
export const PAGINATION_CONFIG = {
  showSizeChanger: true,
  showQuickJumper: true,
  showTotal: (total, range) => `第 ${range[0]}-${range[1]} 条，共 ${total} 条`,
  pageSizeOptions: ['10', '20', '50', '100']
};
