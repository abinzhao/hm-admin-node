import React from 'react';
import { HashRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { useSelector } from 'react-redux';
import Login from './pages/Login';
import Layout from './components/Layout';
import Dashboard from './pages/Dashboard';
import UserManagement from './pages/UserManagement';
import ContentManagement from './pages/ContentManagement';
import MessageManagement from './pages/MessageManagement';
import TodoManagement from './pages/TodoManagement';
import NotificationManagement from './pages/NotificationManagement';
import LogMonitoring from './pages/LogMonitoring';

const App = () => {
  const { isAuthenticated } = useSelector(state => state.auth);

  return (
    <Router>
      <Routes>
        <Route path="/login" element={<Login />} />
        <Route
          path="/*"
          element={
            isAuthenticated ? (
              <Layout>
                <Routes>
                  <Route path="/" element={<Navigate to="/dashboard" replace />} />
                  <Route path="/dashboard" element={<Dashboard />} />
                  <Route path="/users" element={<UserManagement />} />
                  <Route path="/content" element={<ContentManagement />} />
                  <Route path="/messages" element={<MessageManagement />} />
                  <Route path="/todos" element={<TodoManagement />} />
                  <Route path="/notifications" element={<NotificationManagement />} />
                  <Route path="/logs" element={<LogMonitoring />} />
                </Routes>
              </Layout>
            ) : (
              <Navigate to="/login" replace />
            )
          }
        />
      </Routes>
    </Router>
  );
};

export default App;
