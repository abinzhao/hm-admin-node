import React, { useEffect, useState } from 'react';
import {
  Table, Button, Space, Tag, Modal, Form, Input, Select,
  message, Popconfirm, Card, Upload, Switch
} from 'antd';
import {
  PlusOutlined, EditOutlined, DeleteOutlined, SearchOutlined,
  UploadOutlined, EyeOutlined
} from '@ant-design/icons';
import { useDispatch, useSelector } from 'react-redux';
import ReactQuill from 'react-quill';
import Editor from '@monaco-editor/react';
import {
  fetchContent, createContent, updateContent, deleteContent,
  setCurrentPage, setPageSize, setFilters
} from '../../store/slices/contentSlice';
import { CONTENT_TYPES, CONTENT_STATUS, PAGINATION_CONFIG } from '../../utils/constants';
import { formatDate, truncateText } from '../../utils/helpers';
import 'react-quill/dist/quill.snow.css';

const { Option } = Select;
const { TextArea } = Input;

const ContentManagement = () => {
  const [form] = Form.useForm();
  const [searchForm] = Form.useForm();
  const dispatch = useDispatch();
  const { list, total, loading, currentPage, pageSize, filters } = useSelector(state => state.content);
  const [modalVisible, setModalVisible] = useState(false);
  const [previewVisible, setPreviewVisible] = useState(false);
  const [editingContent, setEditingContent] = useState(null);
  const [previewContent, setPreviewContent] = useState(null);
  const [contentType, setContentType] = useState(CONTENT_TYPES.ARTICLE);

  useEffect(() => {
    loadContent();
  }, [currentPage, pageSize, filters]);

  const loadContent = () => {
    dispatch(fetchContent({
      page: currentPage,
      limit: pageSize,
      ...filters
    }));
  };

  const handleSearch = (values) => {
    dispatch(setFilters(values));
    dispatch(setCurrentPage(1));
  };

  const handleReset = () => {
    searchForm.resetFields();
    dispatch(setFilters({}));
    dispatch(setCurrentPage(1));
  };

  const handleAdd = () => {
    setEditingContent(null);
    form.resetFields();
    setContentType(CONTENT_TYPES.ARTICLE);
    setModalVisible(true);
  };

  const handleEdit = (record) => {
    setEditingContent(record);
    setContentType(record.type);
    form.setFieldsValue(record);
    setModalVisible(true);
  };

  const handlePreview = (record) => {
    setPreviewContent(record);
    setPreviewVisible(true);
  };

  const handleDelete = async (id) => {
    try {
      await dispatch(deleteContent(id)).unwrap();
      message.success('删除成功');
      loadContent();
    } catch (error) {
      message.error(error || '删除失败');
    }
  };

  const handleSubmit = async (values) => {
    try {
      const contentData = {
        ...values,
        type: contentType
      };

      if (editingContent) {
        await dispatch(updateContent({ id: editingContent._id, contentData })).unwrap();
        message.success('更新成功');
      } else {
        await dispatch(createContent(contentData)).unwrap();
        message.success('创建成功');
      }
      setModalVisible(false);
      loadContent();
    } catch (error) {
      message.error(error || '操作失败');
    }
  };

  const uploadProps = {
    name: 'file',
    action: '/api/upload',
    headers: {
      authorization: `Bearer ${localStorage.getItem('token')}`
    },
    onChange(info) {
      if (info.file.status === 'done') {
        message.success(`${info.file.name} 文件上传成功`);
      } else if (info.file.status === 'error') {
        message.error(`${info.file.name} 文件上传失败`);
      }
    }
  };

  const quillModules = {
    toolbar: [
      [{ 'header': [1, 2, 3, false] }],
      ['bold', 'italic', 'underline', 'strike'],
      [{ 'list': 'ordered'}, { 'list': 'bullet' }],
      ['blockquote', 'code-block'],
      ['link', 'image'],
      ['clean']
    ]
  };

  const columns = [
    {
      title: '标题',
      dataIndex: 'title',
      key: 'title',
      width: 200,
      render: (title) => (
        <div style={{ wordBreak: 'break-word' }}>
          {truncateText(title, 50)}
        </div>
      )
    },
    {
      title: '类型',
      dataIndex: 'type',
      key: 'type',
      width: 100,
      render: (type) => {
        const colors = {
          article: 'blue',
          qa: 'green',
          code: 'orange',
          package: 'purple'
        };
        const labels = {
          article: '文章',
          qa: '问答',
          code: '代码',
          package: '软件包'
        };
        return <Tag color={colors[type]}>{labels[type]}</Tag>;
      }
    },
    {
      title: '作者',
      dataIndex: ['author', 'username'],
      key: 'author',
      width: 100
    },
    {
      title: '状态',
      dataIndex: 'status',
      key: 'status',
      width: 100,
      render: (status) => {
        const colors = {
          draft: 'orange',
          published: 'green',
          archived: 'red'
        };
        const labels = {
          draft: '草稿',
          published: '已发布',
          archived: '已归档'
        };
        return <Tag color={colors[status]}>{labels[status]}</Tag>;
      }
    },
    {
      title: '浏览量',
      dataIndex: 'views',
      key: 'views',
      width: 80,
      sorter: true
    },
    {
      title: '点赞数',
      dataIndex: 'likes',
      key: 'likes',
      width: 80,
      sorter: true
    },
    {
      title: '创建时间',
      dataIndex: 'createdAt',
      key: 'createdAt',
      width: 120,
      render: (date) => formatDate(date, 'MM-DD HH:mm'),
      sorter: true
    },
    {
      title: '操作',
      key: 'action',
      width: 180,
      fixed: 'right',
      render: (_, record) => (
        <Space size="small">
          <Button
            type="link"
            icon={<EyeOutlined />}
            onClick={() => handlePreview(record)}
            size="small"
          >
            预览
          </Button>
          <Button
            type="link"
            icon={<EditOutlined />}
            onClick={() => handleEdit(record)}
            size="small"
          >
            编辑
          </Button>
          <Popconfirm
            title="确定要删除这个内容吗？"
            onConfirm={() => handleDelete(record._id)}
            okText="确定"
            cancelText="取消"
          >
            <Button
              type="link"
              danger
              icon={<DeleteOutlined />}
              size="small"
            >
              删除
            </Button>
          </Popconfirm>
        </Space>
      )
    }
  ];

  const renderContentEditor = () => {
    if (contentType === CONTENT_TYPES.CODE) {
      return (
        <Form.Item
          name="content"
          label="代码内容"
          rules={[{ required: true, message: '请输入代码内容' }]}
        >
          <div className="editor-container">
            <Editor
              height="300px"
              defaultLanguage="javascript"
              theme="vs-dark"
              options={{
                minimap: { enabled: false },
                fontSize: 14,
                wordWrap: 'on'
              }}
            />
          </div>
        </Form.Item>
      );
    }

    return (
      <Form.Item
        name="content"
        label="内容"
        rules={[{ required: true, message: '请输入内容' }]}
      >
        <ReactQuill
          theme="snow"
          modules={quillModules}
          style={{ height: '300px', marginBottom: '50px' }}
        />
      </Form.Item>
    );
  };

  return (
    <div>
      <div className="page-header">
        <h1 className="page-title">内容管理</h1>
      </div>

      {/* 搜索表单 */}
      <Card className="search-form">
        <Form
          form={searchForm}
          layout="inline"
          onFinish={handleSearch}
        >
          <Form.Item name="keyword" label="关键词">
            <Input placeholder="标题/内容" allowClear />
          </Form.Item>
          <Form.Item name="type" label="类型">
            <Select placeholder="选择类型" allowClear style={{ width: 120 }}>
              <Option value={CONTENT_TYPES.ARTICLE}>文章</Option>
              <Option value={CONTENT_TYPES.QA}>问答</Option>
              <Option value={CONTENT_TYPES.CODE}>代码</Option>
              <Option value={CONTENT_TYPES.PACKAGE}>软件包</Option>
            </Select>
          </Form.Item>
          <Form.Item name="status" label="状态">
            <Select placeholder="选择状态" allowClear style={{ width: 120 }}>
              <Option value={CONTENT_STATUS.DRAFT}>草稿</Option>
              <Option value={CONTENT_STATUS.PUBLISHED}>已发布</Option>
              <Option value={CONTENT_STATUS.ARCHIVED}>已归档</Option>
            </Select>
          </Form.Item>
          <Form.Item>
            <Space>
              <Button type="primary" htmlType="submit" icon={<SearchOutlined />}>
                搜索
              </Button>
              <Button onClick={handleReset}>
                重置
              </Button>
            </Space>
          </Form.Item>
        </Form>
      </Card>

      {/* 操作按钮 */}
      <div className="table-actions">
        <Button
          type="primary"
          icon={<PlusOutlined />}
          onClick={handleAdd}
        >
          新增内容
        </Button>
      </div>

      {/* 内容表格 */}
      <Table
        columns={columns}
        dataSource={list}
        rowKey="_id"
        loading={loading}
        pagination={{
          ...PAGINATION_CONFIG,
          current: currentPage,
          pageSize: pageSize,
          total: total,
          onChange: (page, size) => {
            dispatch(setCurrentPage(page));
            if (size !== pageSize) {
              dispatch(setPageSize(size));
            }
          }
        }}
        scroll={{ x: 1200 }}
      />

      {/* 内容表单模态框 */}
      <Modal
        title={editingContent ? '编辑内容' : '新增内容'}
        open={modalVisible}
        onCancel={() => setModalVisible(false)}
        footer={null}
        width={800}
        style={{ top: 20 }}
      >
        <Form
          form={form}
          layout="vertical"
          onFinish={handleSubmit}
        >
          <Form.Item
            name="title"
            label="标题"
            rules={[
              { required: true, message: '请输入标题' },
              { max: 100, message: '标题不能超过100个字符' }
            ]}
          >
            <Input placeholder="请输入标题" />
          </Form.Item>

          <Form.Item label="内容类型">
            <Select
              value={contentType}
              onChange={setContentType}
              style={{ width: 200 }}
            >
              <Option value={CONTENT_TYPES.ARTICLE}>文章</Option>
              <Option value={CONTENT_TYPES.QA}>问答</Option>
              <Option value={CONTENT_TYPES.CODE}>代码</Option>
              <Option value={CONTENT_TYPES.PACKAGE}>软件包</Option>
            </Select>
          </Form.Item>

          {renderContentEditor()}

          <Form.Item name="tags" label="标签">
            <Select
              mode="tags"
              placeholder="请输入标签，按回车添加"
              style={{ width: '100%' }}
            />
          </Form.Item>

          <Form.Item name="summary" label="摘要">
            <TextArea
              rows={3}
              placeholder="请输入内容摘要"
              maxLength={300}
              showCount
            />
          </Form.Item>

          <Space>
            <Form.Item name="status" label="状态">
              <Select style={{ width: 120 }}>
                <Option value={CONTENT_STATUS.DRAFT}>草稿</Option>
                <Option value={CONTENT_STATUS.PUBLISHED}>已发布</Option>
                <Option value={CONTENT_STATUS.ARCHIVED}>已归档</Option>
              </Select>
            </Form.Item>

            <Form.Item name="featured" label="推荐" valuePropName="checked">
              <Switch />
            </Form.Item>

            <Form.Item name="allowComments" label="允许评论" valuePropName="checked">
              <Switch defaultChecked />
            </Form.Item>
          </Space>

          <Form.Item label="附件上传">
            <Upload {...uploadProps}>
              <Button icon={<UploadOutlined />}>上传文件</Button>
            </Upload>
          </Form.Item>

          <Form.Item>
            <Space>
              <Button type="primary" htmlType="submit">
                {editingContent ? '更新' : '创建'}
              </Button>
              <Button onClick={() => setModalVisible(false)}>
                取消
              </Button>
            </Space>
          </Form.Item>
        </Form>
      </Modal>

      {/* 内容预览模态框 */}
      <Modal
        title="内容预览"
        open={previewVisible}
        onCancel={() => setPreviewVisible(false)}
        footer={[
          <Button key="close" onClick={() => setPreviewVisible(false)}>
            关闭
          </Button>
        ]}
        width={800}
      >
        {previewContent && (
          <div>
            <h2>{previewContent.title}</h2>
            <div style={{ marginBottom: 16 }}>
              <Space>
                <Tag color="blue">{previewContent.type}</Tag>
                <span>作者：{previewContent.author?.username}</span>
                <span>创建时间：{formatDate(previewContent.createdAt)}</span>
              </Space>
            </div>
            <div
              dangerouslySetInnerHTML={{ __html: previewContent.content }}
              style={{
                border: '1px solid #f0f0f0',
                padding: '16px',
                borderRadius: '6px',
                maxHeight: '400px',
                overflow: 'auto'
              }}
            />
          </div>
        )}
      </Modal>
    </div>
  );
};

export default ContentManagement;
