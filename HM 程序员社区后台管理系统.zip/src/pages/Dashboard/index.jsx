import React, { useEffect } from 'react';
import { Row, Col, Card, Statistic, Table, Tag, Progress } from 'antd';
import {
  UserOutlined,
  FileTextOutlined,
  MessageOutlined,
  EyeOutlined,
  ArrowUpOutlined,
  ArrowDownOutlined
} from '@ant-design/icons';
import { useDispatch, useSelector } from 'react-redux';
import { fetchSystemStats } from '../../store/slices/logSlice';
import ReactECharts from 'echarts-for-react';
import { formatDate } from '../../utils/helpers';
import './index.css';

const Dashboard = () => {
  const dispatch = useDispatch();
  const { stats } = useSelector(state => state.logs);

  useEffect(() => {
    dispatch(fetchSystemStats());
  }, [dispatch]);

  // 模拟数据
  const recentActivities = [
    {
      key: '1',
      action: '用户注册',
      user: '张三',
      time: new Date(),
      status: 'success'
    },
    {
      key: '2',
      action: '发布文章',
      user: '李四',
      time: new Date(Date.now() - 3600000),
      status: 'success'
    },
    {
      key: '3',
      action: '系统登录',
      user: '王五',
      time: new Date(Date.now() - 7200000),
      status: 'info'
    }
  ];

  const topContent = [
    {
      key: '1',
      title: 'React 入门教程',
      views: 1234,
      likes: 89,
      type: 'article'
    },
    {
      key: '2',
      title: 'JavaScript 异步编程',
      views: 987,
      likes: 76,
      type: 'article'
    },
    {
      key: '3',
      title: 'Vue3 组合式API',
      views: 856,
      likes: 65,
      type: 'qa'
    }
  ];

  const activityColumns = [
    {
      title: '操作',
      dataIndex: 'action',
      key: 'action'
    },
    {
      title: '用户',
      dataIndex: 'user',
      key: 'user'
    },
    {
      title: '时间',
      dataIndex: 'time',
      key: 'time',
      render: (time) => formatDate(time, 'MM-DD HH:mm')
    },
    {
      title: '状态',
      dataIndex: 'status',
      key: 'status',
      render: (status) => (
        <Tag color={status === 'success' ? 'green' : 'blue'}>
          {status === 'success' ? '成功' : '信息'}
        </Tag>
      )
    }
  ];

  const contentColumns = [
    {
      title: '标题',
      dataIndex: 'title',
      key: 'title'
    },
    {
      title: '类型',
      dataIndex: 'type',
      key: 'type',
      render: (type) => (
        <Tag color={type === 'article' ? 'blue' : 'green'}>
          {type === 'article' ? '文章' : '问答'}
        </Tag>
      )
    },
    {
      title: '浏览量',
      dataIndex: 'views',
      key: 'views'
    },
    {
      title: '点赞数',
      dataIndex: 'likes',
      key: 'likes'
    }
  ];

  // 访问量趋势图配置
  const visitTrendOption = {
    title: {
      text: '访问量趋势',
      left: 'center',
      textStyle: {
        fontSize: 16,
        fontWeight: 'normal'
      }
    },
    tooltip: {
      trigger: 'axis'
    },
    xAxis: {
      type: 'category',
      data: ['周一', '周二', '周三', '周四', '周五', '周六', '周日']
    },
    yAxis: {
      type: 'value'
    },
    series: [
      {
        data: [820, 932, 901, 934, 1290, 1330, 1320],
        type: 'line',
        smooth: true,
        areaStyle: {
          color: {
            type: 'linear',
            x: 0,
            y: 0,
            x2: 0,
            y2: 1,
            colorStops: [
              { offset: 0, color: 'rgba(102, 126, 234, 0.8)' },
              { offset: 1, color: 'rgba(102, 126, 234, 0.1)' }
            ]
          }
        },
        lineStyle: {
          color: '#667eea'
        }
      }
    ],
    grid: {
      left: '3%',
      right: '4%',
      bottom: '3%',
      containLabel: true
    }
  };

  // 内容分布饼图配置
  const contentDistributionOption = {
    title: {
      text: '内容分布',
      left: 'center',
      textStyle: {
        fontSize: 16,
        fontWeight: 'normal'
      }
    },
    tooltip: {
      trigger: 'item'
    },
    series: [
      {
        type: 'pie',
        radius: '60%',
        data: [
          { value: 335, name: '文章' },
          { value: 310, name: '问答' },
          { value: 234, name: '代码' },
          { value: 135, name: '软件包' }
        ],
        emphasis: {
          itemStyle: {
            shadowBlur: 10,
            shadowOffsetX: 0,
            shadowColor: 'rgba(0, 0, 0, 0.5)'
          }
        }
      }
    ]
  };

  return (
    <div className="dashboard">
      <div className="page-header">
        <h1 className="page-title">仪表盘</h1>
      </div>

      {/* 统计卡片 */}
      <Row gutter={[24, 24]} className="stats-row">
        <Col xs={24} sm={12} lg={6}>
          <Card className="stat-card">
            <Statistic
              title="总用户数"
              value={stats.totalUsers || 1234}
              prefix={<UserOutlined />}
              valueStyle={{ color: '#3f8600' }}
              suffix={<ArrowUpOutlined style={{ fontSize: '12px' }} />}
            />
          </Card>
        </Col>
        <Col xs={24} sm={12} lg={6}>
          <Card className="stat-card">
            <Statistic
              title="总内容数"
              value={stats.totalContent || 567}
              prefix={<FileTextOutlined />}
              valueStyle={{ color: '#cf1322' }}
              suffix={<ArrowUpOutlined style={{ fontSize: '12px' }} />}
            />
          </Card>
        </Col>
        <Col xs={24} sm={12} lg={6}>
          <Card className="stat-card">
            <Statistic
              title="总留言数"
              value={stats.totalMessages || 89}
              prefix={<MessageOutlined />}
              valueStyle={{ color: '#1890ff' }}
              suffix={<ArrowDownOutlined style={{ fontSize: '12px' }} />}
            />
          </Card>
        </Col>
        <Col xs={24} sm={12} lg={6}>
          <Card className="stat-card">
            <Statistic
              title="今日访问"
              value={stats.todayVisits || 456}
              prefix={<EyeOutlined />}
              valueStyle={{ color: '#722ed1' }}
              suffix={<ArrowUpOutlined style={{ fontSize: '12px' }} />}
            />
          </Card>
        </Col>
      </Row>

      {/* 图表区域 */}
      <Row gutter={[24, 24]} className="charts-row">
        <Col xs={24} lg={16}>
          <Card>
            <ReactECharts option={visitTrendOption} style={{ height: '300px' }} />
          </Card>
        </Col>
        <Col xs={24} lg={8}>
          <Card>
            <ReactECharts option={contentDistributionOption} style={{ height: '300px' }} />
          </Card>
        </Col>
      </Row>

      {/* 数据表格区域 */}
      <Row gutter={[24, 24]} className="tables-row">
        <Col xs={24} lg={12}>
          <Card title="最近活动" extra={<a href="#more">更多</a>}>
            <Table
              columns={activityColumns}
              dataSource={recentActivities}
              pagination={false}
              size="small"
            />
          </Card>
        </Col>
        <Col xs={24} lg={12}>
          <Card title="热门内容" extra={<a href="#more">更多</a>}>
            <Table
              columns={contentColumns}
              dataSource={topContent}
              pagination={false}
              size="small"
            />
          </Card>
        </Col>
      </Row>

      {/* 系统状态 */}
      <Row gutter={[24, 24]} className="status-row">
        <Col xs={24} lg={8}>
          <Card title="服务器状态">
            <div className="status-item">
              <span>CPU 使用率</span>
              <Progress percent={30} status="active" />
            </div>
            <div className="status-item">
              <span>内存使用率</span>
              <Progress percent={50} status="active" />
            </div>
            <div className="status-item">
              <span>磁盘使用率</span>
              <Progress percent={70} status="active" />
            </div>
          </Card>
        </Col>
        <Col xs={24} lg={8}>
          <Card title="数据库状态">
            <div className="status-item">
              <span>连接数</span>
              <Progress percent={20} status="active" />
            </div>
            <div className="status-item">
              <span>查询性能</span>
              <Progress percent={85} status="active" />
            </div>
            <div className="status-item">
              <span>存储空间</span>
              <Progress percent={60} status="active" />
            </div>
          </Card>
        </Col>
        <Col xs={24} lg={8}>
          <Card title="网络状态">
            <div className="status-item">
              <span>带宽使用</span>
              <Progress percent={40} status="active" />
            </div>
            <div className="status-item">
              <span>响应时间</span>
              <Progress percent={90} status="active" />
            </div>
            <div className="status-item">
              <span>可用性</span>
              <Progress percent={99} status="active" />
            </div>
          </Card>
        </Col>
      </Row>
    </div>
  );
};

export default Dashboard;
