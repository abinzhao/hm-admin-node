import React, { useEffect, useState } from 'react';
import {
  Table, Button, Space, Tag, Modal, Form, Input, Select,
  message, Popconfirm, Card, DatePicker, Progress, Row, Col
} from 'antd';
import {
  PlusOutlined, EditOutlined, DeleteOutlined, SearchOutlined,
  CheckOutlined, ClockCircleOutlined
} from '@ant-design/icons';
import { useDispatch, useSelector } from 'react-redux';
import {
  fetchTodos, createTodo, updateTodo, deleteTodo,
  setCurrentPage, setPageSize
} from '../../store/slices/todoSlice';
import { TODO_STATUS, TODO_PRIORITY, PAGINATION_CONFIG } from '../../utils/constants';
import { formatDate } from '../../utils/helpers';
import dayjs from 'dayjs';

const { Option } = Select;
const { TextArea } = Input;

const TodoManagement = () => {
  const [form] = Form.useForm();
  const [searchForm] = Form.useForm();
  const dispatch = useDispatch();
  const { list, total, loading, currentPage, pageSize } = useSelector(state => state.todos);
  const [modalVisible, setModalVisible] = useState(false);
  const [editingTodo, setEditingTodo] = useState(null);
  const [searchParams, setSearchParams] = useState({});

  useEffect(() => {
    loadTodos();
  }, [currentPage, pageSize, searchParams]);

  const loadTodos = () => {
    dispatch(fetchTodos({
      page: currentPage,
      limit: pageSize,
      ...searchParams
    }));
  };

  const handleSearch = (values) => {
    setSearchParams(values);
    dispatch(setCurrentPage(1));
  };

  const handleReset = () => {
    searchForm.resetFields();
    setSearchParams({});
    dispatch(setCurrentPage(1));
  };

  const handleAdd = () => {
    setEditingTodo(null);
    form.resetFields();
    setModalVisible(true);
  };

  const handleEdit = (record) => {
    setEditingTodo(record);
    form.setFieldsValue({
      ...record,
      dueDate: record.dueDate ? dayjs(record.dueDate) : null
    });
    setModalVisible(true);
  };

  const handleDelete = async (id) => {
    try {
      await dispatch(deleteTodo(id)).unwrap();
      message.success('删除成功');
      loadTodos();
    } catch (error) {
      message.error(error || '删除失败');
    }
  };

  const handleSubmit = async (values) => {
    try {
      const todoData = {
        ...values,
        dueDate: values.dueDate ? values.dueDate.toISOString() : null
      };

      if (editingTodo) {
        await dispatch(updateTodo({ id: editingTodo._id, todoData })).unwrap();
        message.success('更新成功');
      } else {
        await dispatch(createTodo(todoData)).unwrap();
        message.success('创建成功');
      }
      setModalVisible(false);
      loadTodos();
    } catch (error) {
      message.error(error || '操作失败');
    }
  };

  const handleStatusChange = async (id, status) => {
    try {
      await dispatch(updateTodo({ id, todoData: { status } })).unwrap();
      message.success('状态更新成功');
      loadTodos();
    } catch (error) {
      message.error(error || '状态更新失败');
    }
  };

  const getStatusColor = (status) => {
    const colors = {
      pending: 'orange',
      in_progress: 'blue',
      completed: 'green'
    };
    return colors[status] || 'default';
  };

  const getStatusText = (status) => {
    const texts = {
      pending: '待处理',
      in_progress: '进行中',
      completed: '已完成'
    };
    return texts[status] || status;
  };

  const getPriorityColor = (priority) => {
    const colors = {
      low: 'green',
      medium: 'orange',
      high: 'red',
      urgent: 'purple'
    };
    return colors[priority] || 'default';
  };

  const getPriorityText = (priority) => {
    const texts = {
      low: '低',
      medium: '中',
      high: '高',
      urgent: '紧急'
    };
    return texts[priority] || priority;
  };

  const getProgressPercent = (status) => {
    const percents = {
      pending: 0,
      in_progress: 50,
      completed: 100
    };
    return percents[status] || 0;
  };

  const columns = [
    {
      title: '标题',
      dataIndex: 'title',
      key: 'title',
      width: 200,
      render: (title) => (
        <div style={{ wordBreak: 'break-word' }}>
          {title}
        </div>
      )
    },
    {
      title: '描述',
      dataIndex: 'description',
      key: 'description',
      render: (description) => (
        <div style={{ wordBreak: 'break-word', maxWidth: '200px' }}>
          {description || '-'}
        </div>
      )
    },
    {
      title: '优先级',
      dataIndex: 'priority',
      key: 'priority',
      width: 100,
      render: (priority) => (
        <Tag color={getPriorityColor(priority)}>
          {getPriorityText(priority)}
        </Tag>
      )
    },
    {
      title: '状态',
      dataIndex: 'status',
      key: 'status',
      width: 120,
      render: (status, record) => (
        <Space direction="vertical" size="small">
          <Tag color={getStatusColor(status)}>
            {getStatusText(status)}
          </Tag>
          <Progress
            percent={getProgressPercent(status)}
            size="small"
            showInfo={false}
          />
        </Space>
      )
    },
    {
      title: '截止日期',
      dataIndex: 'dueDate',
      key: 'dueDate',
      width: 120,
      render: (date) => {
        if (!date) return '-';
        const isOverdue = dayjs(date).isBefore(dayjs()) && date;
        return (
          <span style={{ color: isOverdue ? '#ff4d4f' : undefined }}>
            {formatDate(date, 'MM-DD HH:mm')}
            {isOverdue && <ClockCircleOutlined style={{ marginLeft: 4, color: '#ff4d4f' }} />}
          </span>
        );
      },
      sorter: true
    },
    {
      title: '负责人',
      dataIndex: ['assignee', 'username'],
      key: 'assignee',
      width: 100,
      render: (username) => username || '未分配'
    },
    {
      title: '创建时间',
      dataIndex: 'createdAt',
      key: 'createdAt',
      width: 120,
      render: (date) => formatDate(date, 'MM-DD HH:mm'),
      sorter: true
    },
    {
      title: '操作',
      key: 'action',
      width: 200,
      render: (_, record) => (
        <Space size="small">
          {record.status !== TODO_STATUS.COMPLETED && (
            <Button
              type="link"
              icon={<CheckOutlined />}
              onClick={() => handleStatusChange(record._id, TODO_STATUS.COMPLETED)}
              size="small"
            >
              完成
            </Button>
          )}
          <Button
            type="link"
            icon={<EditOutlined />}
            onClick={() => handleEdit(record)}
            size="small"
          >
            编辑
          </Button>
          <Popconfirm
            title="确定要删除这个待办事项吗？"
            onConfirm={() => handleDelete(record._id)}
            okText="确定"
            cancelText="取消"
          >
            <Button
              type="link"
              danger
              icon={<DeleteOutlined />}
              size="small"
            >
              删除
            </Button>
          </Popconfirm>
        </Space>
      )
    }
  ];

  // 统计数据
  const stats = {
    total: list.length,
    pending: list.filter(item => item.status === TODO_STATUS.PENDING).length,
    inProgress: list.filter(item => item.status === TODO_STATUS.IN_PROGRESS).length,
    completed: list.filter(item => item.status === TODO_STATUS.COMPLETED).length,
    overdue: list.filter(item => 
      item.dueDate && dayjs(item.dueDate).isBefore(dayjs()) && item.status !== TODO_STATUS.COMPLETED
    ).length
  };

  return (
    <div>
      <div className="page-header">
        <h1 className="page-title">待办事项管理</h1>
      </div>

      {/* 统计卡片 */}
      <Row gutter={[16, 16]} style={{ marginBottom: 24 }}>
        <Col xs={12} sm={6}>
          <Card>
            <div className="stat-card">
              <div className="stat-number">{stats.total}</div>
              <div className="stat-label">总数</div>
            </div>
          </Card>
        </Col>
        <Col xs={12} sm={6}>
          <Card>
            <div className="stat-card">
              <div className="stat-number" style={{ color: '#faad14' }}>{stats.pending}</div>
              <div className="stat-label">待处理</div>
            </div>
          </Card>
        </Col>
        <Col xs={12} sm={6}>
          <Card>
            <div className="stat-card">
              <div className="stat-number" style={{ color: '#1890ff' }}>{stats.inProgress}</div>
              <div className="stat-label">进行中</div>
            </div>
          </Card>
        </Col>
        <Col xs={12} sm={6}>
          <Card>
            <div className="stat-card">
              <div className="stat-number" style={{ color: '#52c41a' }}>{stats.completed}</div>
              <div className="stat-label">已完成</div>
            </div>
          </Card>
        </Col>
      </Row>

      {/* 搜索表单 */}
      <Card className="search-form">
        <Form
          form={searchForm}
          layout="inline"
          onFinish={handleSearch}
        >
          <Form.Item name="keyword" label="关键词">
            <Input placeholder="标题/描述" allowClear />
          </Form.Item>
          <Form.Item name="status" label="状态">
            <Select placeholder="选择状态" allowClear style={{ width: 120 }}>
              <Option value={TODO_STATUS.PENDING}>待处理</Option>
              <Option value={TODO_STATUS.IN_PROGRESS}>进行中</Option>
              <Option value={TODO_STATUS.COMPLETED}>已完成</Option>
            </Select>
          </Form.Item>
          <Form.Item name="priority" label="优先级">
            <Select placeholder="选择优先级" allowClear style={{ width: 120 }}>
              <Option value={TODO_PRIORITY.LOW}>低</Option>
              <Option value={TODO_PRIORITY.MEDIUM}>中</Option>
              <Option value={TODO_PRIORITY.HIGH}>高</Option>
              <Option value={TODO_PRIORITY.URGENT}>紧急</Option>
            </Select>
          </Form.Item>
          <Form.Item>
            <Space>
              <Button type="primary" htmlType="submit" icon={<SearchOutlined />}>
                搜索
              </Button>
              <Button onClick={handleReset}>
                重置
              </Button>
            </Space>
          </Form.Item>
        </Form>
      </Card>

      {/* 操作按钮 */}
      <div className="table-actions">
        <Button
          type="primary"
          icon={<PlusOutlined />}
          onClick={handleAdd}
        >
          新增待办事项
        </Button>
      </div>

      {/* 待办事项表格 */}
      <Table
        columns={columns}
        dataSource={list}
        rowKey="_id"
        loading={loading}
        pagination={{
          ...PAGINATION_CONFIG,
          current: currentPage,
          pageSize: pageSize,
          total: total,
          onChange: (page, size) => {
            dispatch(setCurrentPage(page));
            if (size !== pageSize) {
              dispatch(setPageSize(size));
            }
          }
        }}
        scroll={{ x: 1000 }}
      />

      {/* 待办事项表单模态框 */}
      <Modal
        title={editingTodo ? '编辑待办事项' : '新增待办事项'}
        open={modalVisible}
        onCancel={() => setModalVisible(false)}
        footer={null}
        width={600}
      >
        <Form
          form={form}
          layout="vertical"
          onFinish={handleSubmit}
        >
          <Form.Item
            name="title"
            label="标题"
            rules={[
              { required: true, message: '请输入标题' },
              { max: 100, message: '标题不能超过100个字符' }
            ]}
          >
            <Input placeholder="请输入待办事项标题" />
          </Form.Item>

          <Form.Item name="description" label="描述">
            <TextArea
              rows={3}
              placeholder="请输入详细描述"
              maxLength={500}
              showCount
            />
          </Form.Item>

          <Row gutter={16}>
            <Col span={12}>
              <Form.Item
                name="priority"
                label="优先级"
                rules={[{ required: true, message: '请选择优先级' }]}
              >
                <Select placeholder="请选择优先级">
                  <Option value={TODO_PRIORITY.LOW}>低</Option>
                  <Option value={TODO_PRIORITY.MEDIUM}>中</Option>
                  <Option value={TODO_PRIORITY.HIGH}>高</Option>
                  <Option value={TODO_PRIORITY.URGENT}>紧急</Option>
                </Select>
              </Form.Item>
            </Col>
            <Col span={12}>
              <Form.Item
                name="status"
                label="状态"
                rules={[{ required: true, message: '请选择状态' }]}
              >
                <Select placeholder="请选择状态">
                  <Option value={TODO_STATUS.PENDING}>待处理</Option>
                  <Option value={TODO_STATUS.IN_PROGRESS}>进行中</Option>
                  <Option value={TODO_STATUS.COMPLETED}>已完成</Option>
                </Select>
              </Form.Item>
            </Col>
          </Row>

          <Form.Item name="dueDate" label="截止日期">
            <DatePicker
              showTime
              placeholder="选择截止日期"
              style={{ width: '100%' }}
              format="YYYY-MM-DD HH:mm"
            />
          </Form.Item>

          <Form.Item name="tags" label="标签">
            <Select
              mode="tags"
              placeholder="请输入标签，按回车添加"
              style={{ width: '100%' }}
            />
          </Form.Item>

          <Form.Item>
            <Space>
              <Button type="primary" htmlType="submit">
                {editingTodo ? '更新' : '创建'}
              </Button>
              <Button onClick={() => setModalVisible(false)}>
                取消
              </Button>
            </Space>
          </Form.Item>
        </Form>
      </Modal>
    </div>
  );
};

export default TodoManagement;
