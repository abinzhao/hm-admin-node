import React, { useEffect, useState } from 'react';
import {
  Table, Button, Space, Tag, Modal, Form, Input,
  message, Popconfirm, Card, Avatar, Rate, Tooltip
} from 'antd';
import {
  MessageOutlined, DeleteOutlined, SearchOutlined,
  UserOutlined, ReplyArrowIcon
} from '@ant-design/icons';
import { useDispatch, useSelector } from 'react-redux';
import {
  fetchMessages, replyMessage, deleteMessage,
  setCurrentPage, setPageSize
} from '../../store/slices/messageSlice';
import { PAGINATION_CONFIG } from '../../utils/constants';
import { formatDate, truncateText } from '../../utils/helpers';

const { TextArea } = Input;

const MessageManagement = () => {
  const [searchForm] = Form.useForm();
  const [replyForm] = Form.useForm();
  const dispatch = useDispatch();
  const { list, total, loading, currentPage, pageSize } = useSelector(state => state.messages);
  const [replyVisible, setReplyVisible] = useState(false);
  const [replyingMessage, setReplyingMessage] = useState(null);
  const [searchParams, setSearchParams] = useState({});

  useEffect(() => {
    loadMessages();
  }, [currentPage, pageSize, searchParams]);

  const loadMessages = () => {
    dispatch(fetchMessages({
      page: currentPage,
      limit: pageSize,
      ...searchParams
    }));
  };

  const handleSearch = (values) => {
    setSearchParams(values);
    dispatch(setCurrentPage(1));
  };

  const handleReset = () => {
    searchForm.resetFields();
    setSearchParams({});
    dispatch(setCurrentPage(1));
  };

  const handleReply = (record) => {
    setReplyingMessage(record);
    replyForm.resetFields();
    setReplyVisible(true);
  };

  const handleSubmitReply = async (values) => {
    try {
      await dispatch(replyMessage({
        id: replyingMessage._id,
        reply: values.reply
      })).unwrap();
      message.success('回复成功');
      setReplyVisible(false);
      loadMessages();
    } catch (error) {
      message.error(error || '回复失败');
    }
  };

  const handleDelete = async (id) => {
    try {
      await dispatch(deleteMessage(id)).unwrap();
      message.success('删除成功');
      loadMessages();
    } catch (error) {
      message.error(error || '删除失败');
    }
  };

  const columns = [
    {
      title: '用户',
      dataIndex: 'user',
      key: 'user',
      width: 120,
      render: (user) => (
        <Space>
          <Avatar
            size={32}
            src={user?.avatar}
            icon={<UserOutlined />}
          >
            {!user?.avatar && user?.username?.charAt(0).toUpperCase()}
          </Avatar>
          <div>
            <div>{user?.username || '匿名用户'}</div>
            {user?.email && (
              <div style={{ fontSize: '12px', color: '#999' }}>
                {user.email}
              </div>
            )}
          </div>
        </Space>
      )
    },
    {
      title: '留言内容',
      dataIndex: 'content',
      key: 'content',
      render: (content) => (
        <Tooltip title={content}>
          <div style={{ wordBreak: 'break-word' }}>
            {truncateText(content, 100)}
          </div>
        </Tooltip>
      )
    },
    {
      title: '评分',
      dataIndex: 'rating',
      key: 'rating',
      width: 120,
      render: (rating) => rating ? (
        <Rate disabled defaultValue={rating} style={{ fontSize: '14px' }} />
      ) : '-'
    },
    {
      title: '联系方式',
      dataIndex: 'contact',
      key: 'contact',
      width: 120,
      render: (contact) => contact || '-'
    },
    {
      title: '状态',
      dataIndex: 'status',
      key: 'status',
      width: 100,
      render: (status, record) => {
        if (record.reply) {
          return <Tag color="green">已回复</Tag>;
        }
        return <Tag color="orange">待回复</Tag>;
      }
    },
    {
      title: '留言时间',
      dataIndex: 'createdAt',
      key: 'createdAt',
      width: 120,
      render: (date) => (
        <Tooltip title={formatDate(date)}>
          {formatDate(date, 'MM-DD HH:mm')}
        </Tooltip>
      ),
      sorter: true
    },
    {
      title: '操作',
      key: 'action',
      width: 150,
      render: (_, record) => (
        <Space size="small">
          <Button
            type="link"
            icon={<MessageOutlined />}
            onClick={() => handleReply(record)}
            size="small"
          >
            {record.reply ? '查看回复' : '回复'}
          </Button>
          <Popconfirm
            title="确定要删除这条留言吗？"
            onConfirm={() => handleDelete(record._id)}
            okText="确定"
            cancelText="取消"
          >
            <Button
              type="link"
              danger
              icon={<DeleteOutlined />}
              size="small"
            >
              删除
            </Button>
          </Popconfirm>
        </Space>
      )
    }
  ];

  const expandedRowRender = (record) => {
    if (!record.reply) return null;

    return (
      <div style={{ padding: '16px', background: '#f8f9fa', borderRadius: '6px' }}>
        <div style={{ marginBottom: '8px', fontWeight: 'bold', color: '#1890ff' }}>
          管理员回复：
        </div>
        <div style={{ marginBottom: '8px' }}>
          {record.reply.content}
        </div>
        <div style={{ fontSize: '12px', color: '#999' }}>
          回复时间：{formatDate(record.reply.createdAt)}
        </div>
      </div>
    );
  };

  return (
    <div>
      <div className="page-header">
        <h1 className="page-title">留言管理</h1>
      </div>

      {/* 搜索表单 */}
      <Card className="search-form">
        <Form
          form={searchForm}
          layout="inline"
          onFinish={handleSearch}
        >
          <Form.Item name="keyword" label="关键词">
            <Input placeholder="用户名/留言内容" allowClear />
          </Form.Item>
          <Form.Item name="status" label="状态">
            <Input.Select placeholder="选择状态" allowClear style={{ width: 120 }}>
              <Input.Select.Option value="replied">已回复</Input.Select.Option>
              <Input.Select.Option value="pending">待回复</Input.Select.Option>
            </Input.Select>
          </Form.Item>
          <Form.Item>
            <Space>
              <Button type="primary" htmlType="submit" icon={<SearchOutlined />}>
                搜索
              </Button>
              <Button onClick={handleReset}>
                重置
              </Button>
            </Space>
          </Form.Item>
        </Form>
      </Card>

      {/* 留言表格 */}
      <Table
        columns={columns}
        dataSource={list}
        rowKey="_id"
        loading={loading}
        expandable={{
          expandedRowRender,
          rowExpandable: (record) => !!record.reply
        }}
        pagination={{
          ...PAGINATION_CONFIG,
          current: currentPage,
          pageSize: pageSize,
          total: total,
          onChange: (page, size) => {
            dispatch(setCurrentPage(page));
            if (size !== pageSize) {
              dispatch(setPageSize(size));
            }
          }
        }}
        scroll={{ x: 800 }}
      />

      {/* 回复模态框 */}
      <Modal
        title={replyingMessage?.reply ? '查看回复' : '回复留言'}
        open={replyVisible}
        onCancel={() => setReplyVisible(false)}
        footer={null}
        width={600}
      >
        {replyingMessage && (
          <div>
            {/* 原留言内容 */}
            <div style={{ marginBottom: '24px', padding: '16px', background: '#f8f9fa', borderRadius: '6px' }}>
              <div style={{ marginBottom: '8px', fontWeight: 'bold' }}>
                原留言内容：
              </div>
              <div style={{ marginBottom: '8px' }}>
                {replyingMessage.content}
              </div>
              <div style={{ fontSize: '12px', color: '#999' }}>
                留言用户：{replyingMessage.user?.username || '匿名用户'} | 
                留言时间：{formatDate(replyingMessage.createdAt)}
              </div>
            </div>

            {/* 回复表单或已有回复 */}
            {replyingMessage.reply ? (
              <div style={{ padding: '16px', background: '#e6f7ff', borderRadius: '6px' }}>
                <div style={{ marginBottom: '8px', fontWeight: 'bold', color: '#1890ff' }}>
                  管理员回复：
                </div>
                <div style={{ marginBottom: '8px' }}>
                  {replyingMessage.reply.content}
                </div>
                <div style={{ fontSize: '12px', color: '#999' }}>
                  回复时间：{formatDate(replyingMessage.reply.createdAt)}
                </div>
              </div>
            ) : (
              <Form
                form={replyForm}
                layout="vertical"
                onFinish={handleSubmitReply}
              >
                <Form.Item
                  name="reply"
                  label="回复内容"
                  rules={[
                    { required: true, message: '请输入回复内容' },
                    { min: 10, message: '回复内容至少10个字符' }
                  ]}
                >
                  <TextArea
                    rows={4}
                    placeholder="请输入回复内容..."
                    maxLength={500}
                    showCount
                  />
                </Form.Item>

                <Form.Item>
                  <Space>
                    <Button type="primary" htmlType="submit">
                      发送回复
                    </Button>
                    <Button onClick={() => setReplyVisible(false)}>
                      取消
                    </Button>
                  </Space>
                </Form.Item>
              </Form>
            )}
          </div>
        )}
      </Modal>
    </div>
  );
};

export default MessageManagement;
