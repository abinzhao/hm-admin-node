import React, { useEffect, useState } from 'react';
import {
  Table, Card, Select, DatePicker, Space, Button, Tag,
  Row, Col, Statistic, Alert, Input
} from 'antd';
import {
  SearchOutlined, ReloadOutlined, DownloadOutlined,
  ExclamationCircleOutlined, InfoCircleOutlined,
  WarningOutlined, CloseCircleOutlined
} from '@ant-design/icons';
import { useDispatch, useSelector } from 'react-redux';
import ReactECharts from 'echarts-for-react';
import {
  fetchLogs, fetchSystemStats,
  setCurrentPage, setPageSize
} from '../../store/slices/logSlice';
import { LOG_LEVELS, PAGINATION_CONFIG } from '../../utils/constants';
import { formatDate } from '../../utils/helpers';
import dayjs from 'dayjs';

const { Option } = Select;
const { RangePicker } = DatePicker;

const LogMonitoring = () => {
  const dispatch = useDispatch();
  const { list, total, loading, currentPage, pageSize, stats } = useSelector(state => state.logs);
  const [filters, setFilters] = useState({});
  const [autoRefresh, setAutoRefresh] = useState(false);

  useEffect(() => {
    loadLogs();
    dispatch(fetchSystemStats());
  }, [currentPage, pageSize, filters]);

  useEffect(() => {
    let interval;
    if (autoRefresh) {
      interval = setInterval(() => {
        loadLogs();
        dispatch(fetchSystemStats());
      }, 30000); // 30秒刷新一次
    }
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [autoRefresh, filters]);

  const loadLogs = () => {
    dispatch(fetchLogs({
      page: currentPage,
      limit: pageSize,
      ...filters
    }));
  };

  const handleFilterChange = (key, value) => {
    setFilters(prev => ({
      ...prev,
      [key]: value
    }));
    dispatch(setCurrentPage(1));
  };

  const handleDateRangeChange = (dates) => {
    if (dates && dates.length === 2) {
      setFilters(prev => ({
        ...prev,
        startDate: dates[0].toISOString(),
        endDate: dates[1].toISOString()
      }));
    } else {
      setFilters(prev => {
        const newFilters = { ...prev };
        delete newFilters.startDate;
        delete newFilters.endDate;
        return newFilters;
      });
    }
    dispatch(setCurrentPage(1));
  };

  const handleExport = () => {
    // 导出日志功能
    const csvContent = list.map(log => 
      `${formatDate(log.timestamp)},${log.level},${log.message},${log.source || ''}`
    ).join('\n');
    
    const blob = new Blob([`时间,级别,消息,来源\n${csvContent}`], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `logs_${dayjs().format('YYYY-MM-DD')}.csv`;
    a.click();
    window.URL.revokeObjectURL(url);
  };

  const getLevelIcon = (level) => {
    const icons = {
      info: <InfoCircleOutlined style={{ color: '#1890ff' }} />,
      warn: <WarningOutlined style={{ color: '#faad14' }} />,
      error: <CloseCircleOutlined style={{ color: '#ff4d4f' }} />,
      debug: <ExclamationCircleOutlined style={{ color: '#722ed1' }} />
    };
    return icons[level] || icons.info;
  };

  const getLevelColor = (level) => {
    const colors = {
      info: 'blue',
      warn: 'orange',
      error: 'red',
      debug: 'purple'
    };
    return colors[level] || 'default';
  };

  const columns = [
    {
      title: '时间',
      dataIndex: 'timestamp',
      key: 'timestamp',
      width: 160,
      render: (timestamp) => formatDate(timestamp),
      sorter: true
    },
    {
      title: '级别',
      dataIndex: 'level',
      key: 'level',
      width: 100,
      render: (level) => (
        <Tag color={getLevelColor(level)} icon={getLevelIcon(level)}>
          {level.toUpperCase()}
        </Tag>
      )
    },
    {
      title: '来源',
      dataIndex: 'source',
      key: 'source',
      width: 120,
      render: (source) => source || '-'
    },
    {
      title: '消息',
      dataIndex: 'message',
      key: 'message',
      render: (message) => (
        <div style={{ wordBreak: 'break-word', maxWidth: '400px' }}>
          {message}
        </div>
      )
    },
    {
      title: 'IP地址',
      dataIndex: 'ip',
      key: 'ip',
      width: 120,
      render: (ip) => ip || '-'
    },
    {
      title: '用户',
      dataIndex: ['user', 'username'],
      key: 'user',
      width: 100,
      render: (username) => username || '-'
    }
  ];

  // 日志级别分布图配置
  const logLevelOption = {
    title: {
      text: '日志级别分布',
      left: 'center',
      textStyle: {
        fontSize: 16,
        fontWeight: 'normal'
      }
    },
    tooltip: {
      trigger: 'item'
    },
    series: [
      {
        type: 'pie',
        radius: '60%',
        data: [
          { value: 120, name: 'INFO', itemStyle: { color: '#1890ff' } },
          { value: 45, name: 'WARN', itemStyle: { color: '#faad14' } },
          { value: 15, name: 'ERROR', itemStyle: { color: '#ff4d4f' } },
          { value: 8, name: 'DEBUG', itemStyle: { color: '#722ed1' } }
        ],
        emphasis: {
          itemStyle: {
            shadowBlur: 10,
            shadowOffsetX: 0,
            shadowColor: 'rgba(0, 0, 0, 0.5)'
          }
        }
      }
    ]
  };

  // 日志趋势图配置
  const logTrendOption = {
    title: {
      text: '日志趋势',
      left: 'center',
      textStyle: {
        fontSize: 16,
        fontWeight: 'normal'
      }
    },
    tooltip: {
      trigger: 'axis'
    },
    legend: {
      data: ['INFO', 'WARN', 'ERROR'],
      bottom: 10
    },
    xAxis: {
      type: 'category',
      data: ['00:00', '04:00', '08:00', '12:00', '16:00', '20:00']
    },
    yAxis: {
      type: 'value'
    },
    series: [
      {
        name: 'INFO',
        type: 'line',
        data: [20, 15, 25, 30, 35, 28],
        itemStyle: { color: '#1890ff' }
      },
      {
        name: 'WARN',
        type: 'line',
        data: [5, 8, 12, 15, 10, 8],
        itemStyle: { color: '#faad14' }
      },
      {
        name: 'ERROR',
        type: 'line',
        data: [2, 3, 5, 4, 3, 2],
        itemStyle: { color: '#ff4d4f' }
      }
    ],
    grid: {
      left: '3%',
      right: '4%',
      bottom: '15%',
      containLabel: true
    }
  };

  return (
    <div>
      <div className="page-header">
        <h1 className="page-title">日志监控</h1>
      </div>

      {/* 系统状态警告 */}
      <Alert
        message="系统运行正常"
        description="所有服务运行正常，无严重错误日志。"
        type="success"
        showIcon
        style={{ marginBottom: 24 }}
      />

      {/* 统计卡片 */}
      <Row gutter={[24, 24]} style={{ marginBottom: 24 }}>
        <Col xs={12} sm={6}>
          <Card>
            <Statistic
              title="总用户数"
              value={stats.totalUsers || 1234}
              prefix={<InfoCircleOutlined />}
              valueStyle={{ color: '#3f8600' }}
            />
          </Card>
        </Col>
        <Col xs={12} sm={6}>
          <Card>
            <Statistic
              title="总内容数"
              value={stats.totalContent || 567}
              prefix={<WarningOutlined />}
              valueStyle={{ color: '#cf1322' }}
            />
          </Card>
        </Col>
        <Col xs={12} sm={6}>
          <Card>
            <Statistic
              title="总留言数"
              value={stats.totalMessages || 89}
              prefix={<ExclamationCircleOutlined />}
              valueStyle={{ color: '#1890ff' }}
            />
          </Card>
        </Col>
        <Col xs={12} sm={6}>
          <Card>
            <Statistic
              title="今日访问"
              value={stats.todayVisits || 456}
              prefix={<CloseCircleOutlined />}
              valueStyle={{ color: '#722ed1' }}
            />
          </Card>
        </Col>
      </Row>

      {/* 图表区域 */}
      <Row gutter={[24, 24]} style={{ marginBottom: 24 }}>
        <Col xs={24} lg={12}>
          <Card>
            <ReactECharts option={logLevelOption} style={{ height: '300px' }} />
          </Card>
        </Col>
        <Col xs={24} lg={12}>
          <Card>
            <ReactECharts option={logTrendOption} style={{ height: '300px' }} />
          </Card>
        </Col>
      </Row>

      {/* 筛选器 */}
      <Card style={{ marginBottom: 16 }}>
        <Space wrap>
          <Input
            placeholder="搜索日志消息"
            prefix={<SearchOutlined />}
            style={{ width: 200 }}
            onChange={(e) => handleFilterChange('keyword', e.target.value)}
            allowClear
          />
          
          <Select
            placeholder="选择日志级别"
            style={{ width: 120 }}
            onChange={(value) => handleFilterChange('level', value)}
            allowClear
          >
            <Option value={LOG_LEVELS.INFO}>INFO</Option>
            <Option value={LOG_LEVELS.WARN}>WARN</Option>
            <Option value={LOG_LEVELS.ERROR}>ERROR</Option>
            <Option value={LOG_LEVELS.DEBUG}>DEBUG</Option>
          </Select>

          <Select
            placeholder="选择来源"
            style={{ width: 120 }}
            onChange={(value) => handleFilterChange('source', value)}
            allowClear
          >
            <Option value="auth">认证</Option>
            <Option value="api">API</Option>
            <Option value="database">数据库</Option>
            <Option value="system">系统</Option>
          </Select>

          <RangePicker
            showTime
            format="YYYY-MM-DD HH:mm"
            onChange={handleDateRangeChange}
          />

          <Button
            type="primary"
            icon={<ReloadOutlined />}
            onClick={loadLogs}
          >
            刷新
          </Button>

          <Button
            icon={<DownloadOutlined />}
            onClick={handleExport}
          >
            导出
          </Button>

          <Button
            type={autoRefresh ? 'primary' : 'default'}
            onClick={() => setAutoRefresh(!autoRefresh)}
          >
            {autoRefresh ? '停止自动刷新' : '开启自动刷新'}
          </Button>
        </Space>
      </Card>

      {/* 日志表格 */}
      <Table
        columns={columns}
        dataSource={list}
        rowKey="_id"
        loading={loading}
        pagination={{
          ...PAGINATION_CONFIG,
          current: currentPage,
          pageSize: pageSize,
          total: total,
          onChange: (page, size) => {
            dispatch(setCurrentPage(page));
            if (size !== pageSize) {
              dispatch(setPageSize(size));
            }
          }
        }}
        scroll={{ x: 1000 }}
        size="small"
      />
    </div>
  );
};

export default LogMonitoring;
