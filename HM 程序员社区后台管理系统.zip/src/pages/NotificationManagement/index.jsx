import React, { useEffect, useState } from 'react';
import {
  Table, Button, Space, Tag, Modal, Form, Input, Select,
  message, Popconfirm, Card, DatePicker, Switch, Row, Col
} from 'antd';
import {
  PlusOutlined, EditOutlined, DeleteOutlined, SearchOutlined,
  SendOutlined, BellOutlined
} from '@ant-design/icons';
import { useDispatch, useSelector } from 'react-redux';
import ReactQuill from 'react-quill';
import {
  fetchNotifications, createNotification, sendNotification, deleteNotification,
  setCurrentPage, setPageSize
} from '../../store/slices/notificationSlice';
import { NOTIFICATION_TYPES, NOTIFICATION_STATUS, PAGINATION_CONFIG } from '../../utils/constants';
import { formatDate, truncateText } from '../../utils/helpers';
import dayjs from 'dayjs';
import 'react-quill/dist/quill.snow.css';

const { Option } = Select;
const { TextArea } = Input;

const NotificationManagement = () => {
  const [form] = Form.useForm();
  const [searchForm] = Form.useForm();
  const dispatch = useDispatch();
  const { list, total, loading, currentPage, pageSize } = useSelector(state => state.notifications);
  const [modalVisible, setModalVisible] = useState(false);
  const [editingNotification, setEditingNotification] = useState(null);
  const [searchParams, setSearchParams] = useState({});

  useEffect(() => {
    loadNotifications();
  }, [currentPage, pageSize, searchParams]);

  const loadNotifications = () => {
    dispatch(fetchNotifications({
      page: currentPage,
      limit: pageSize,
      ...searchParams
    }));
  };

  const handleSearch = (values) => {
    setSearchParams(values);
    dispatch(setCurrentPage(1));
  };

  const handleReset = () => {
    searchForm.resetFields();
    setSearchParams({});
    dispatch(setCurrentPage(1));
  };

  const handleAdd = () => {
    setEditingNotification(null);
    form.resetFields();
    setModalVisible(true);
  };

  const handleEdit = (record) => {
    setEditingNotification(record);
    form.setFieldsValue({
      ...record,
      scheduledAt: record.scheduledAt ? dayjs(record.scheduledAt) : null
    });
    setModalVisible(true);
  };

  const handleSend = async (id) => {
    try {
      await dispatch(sendNotification(id)).unwrap();
      message.success('通知发送成功');
      loadNotifications();
    } catch (error) {
      message.error(error || '发送失败');
    }
  };

  const handleDelete = async (id) => {
    try {
      await dispatch(deleteNotification(id)).unwrap();
      message.success('删除成功');
      loadNotifications();
    } catch (error) {
      message.error(error || '删除失败');
    }
  };

  const handleSubmit = async (values) => {
    try {
      const notificationData = {
        ...values,
        scheduledAt: values.scheduledAt ? values.scheduledAt.toISOString() : null
      };

      if (editingNotification) {
        // 更新通知暂不实现，因为已发送的通知不应该被修改
        message.warning('已发送的通知不能修改');
        return;
      } else {
        await dispatch(createNotification(notificationData)).unwrap();
        message.success('创建成功');
      }
      setModalVisible(false);
      loadNotifications();
    } catch (error) {
      message.error(error || '操作失败');
    }
  };

  const getTypeColor = (type) => {
    const colors = {
      system: 'blue',
      announcement: 'green',
      update: 'orange',
      warning: 'red'
    };
    return colors[type] || 'default';
  };

  const getTypeText = (type) => {
    const texts = {
      system: '系统通知',
      announcement: '公告',
      update: '更新通知',
      warning: '警告'
    };
    return texts[type] || type;
  };

  const getStatusColor = (status) => {
    const colors = {
      draft: 'orange',
      sent: 'green',
      scheduled: 'blue'
    };
    return colors[status] || 'default';
  };

  const getStatusText = (status) => {
    const texts = {
      draft: '草稿',
      sent: '已发送',
      scheduled: '已安排'
    };
    return texts[status] || status;
  };

  const quillModules = {
    toolbar: [
      [{ 'header': [1, 2, 3, false] }],
      ['bold', 'italic', 'underline'],
      [{ 'list': 'ordered'}, { 'list': 'bullet' }],
      ['link'],
      ['clean']
    ]
  };

  const columns = [
    {
      title: '标题',
      dataIndex: 'title',
      key: 'title',
      width: 200,
      render: (title) => (
        <div style={{ wordBreak: 'break-word' }}>
          {truncateText(title, 50)}
        </div>
      )
    },
    {
      title: '类型',
      dataIndex: 'type',
      key: 'type',
      width: 120,
      render: (type) => (
        <Tag color={getTypeColor(type)} icon={<BellOutlined />}>
          {getTypeText(type)}
        </Tag>
      )
    },
    {
      title: '内容',
      dataIndex: 'content',
      key: 'content',
      render: (content) => (
        <div style={{ wordBreak: 'break-word' }}>
          {truncateText(content?.replace(/<[^>]*>/g, ''), 80)}
        </div>
      )
    },
    {
      title: '目标用户',
      dataIndex: 'targetUsers',
      key: 'targetUsers',
      width: 120,
      render: (targetUsers) => {
        if (!targetUsers || targetUsers.length === 0) {
          return <Tag color="blue">全部用户</Tag>;
        }
        return <Tag color="green">{targetUsers.length} 个用户</Tag>;
      }
    },
    {
      title: '状态',
      dataIndex: 'status',
      key: 'status',
      width: 100,
      render: (status) => (
        <Tag color={getStatusColor(status)}>
          {getStatusText(status)}
        </Tag>
      )
    },
    {
      title: '计划发送时间',
      dataIndex: 'scheduledAt',
      key: 'scheduledAt',
      width: 140,
      render: (date) => date ? formatDate(date, 'MM-DD HH:mm') : '-'
    },
    {
      title: '创建时间',
      dataIndex: 'createdAt',
      key: 'createdAt',
      width: 140,
      render: (date) => formatDate(date, 'MM-DD HH:mm'),
      sorter: true
    },
    {
      title: '操作',
      key: 'action',
      width: 180,
      render: (_, record) => (
        <Space size="small">
          {record.status === NOTIFICATION_STATUS.DRAFT && (
            <Button
              type="link"
              icon={<SendOutlined />}
              onClick={() => handleSend(record._id)}
              size="small"
            >
              发送
            </Button>
          )}
          <Button
            type="link"
            icon={<EditOutlined />}
            onClick={() => handleEdit(record)}
            size="small"
            disabled={record.status === NOTIFICATION_STATUS.SENT}
          >
            编辑
          </Button>
          <Popconfirm
            title="确定要删除这个通知吗？"
            onConfirm={() => handleDelete(record._id)}
            okText="确定"
            cancelText="取消"
          >
            <Button
              type="link"
              danger
              icon={<DeleteOutlined />}
              size="small"
            >
              删除
            </Button>
          </Popconfirm>
        </Space>
      )
    }
  ];

  // 统计数据
  const stats = {
    total: list.length,
    draft: list.filter(item => item.status === NOTIFICATION_STATUS.DRAFT).length,
    sent: list.filter(item => item.status === NOTIFICATION_STATUS.SENT).length,
    scheduled: list.filter(item => item.status === NOTIFICATION_STATUS.SCHEDULED).length
  };

  return (
    <div>
      <div className="page-header">
        <h1 className="page-title">系统通知管理</h1>
      </div>

      {/* 统计卡片 */}
      <Row gutter={[16, 16]} style={{ marginBottom: 24 }}>
        <Col xs={12} sm={6}>
          <Card>
            <div className="stat-card">
              <div className="stat-number">{stats.total}</div>
              <div className="stat-label">总通知数</div>
            </div>
          </Card>
        </Col>
        <Col xs={12} sm={6}>
          <Card>
            <div className="stat-card">
              <div className="stat-number" style={{ color: '#faad14' }}>{stats.draft}</div>
              <div className="stat-label">草稿</div>
            </div>
          </Card>
        </Col>
        <Col xs={12} sm={6}>
          <Card>
            <div className="stat-card">
              <div className="stat-number" style={{ color: '#52c41a' }}>{stats.sent}</div>
              <div className="stat-label">已发送</div>
            </div>
          </Card>
        </Col>
        <Col xs={12} sm={6}>
          <Card>
            <div className="stat-card">
              <div className="stat-number" style={{ color: '#1890ff' }}>{stats.scheduled}</div>
              <div className="stat-label">已安排</div>
            </div>
          </Card>
        </Col>
      </Row>

      {/* 搜索表单 */}
      <Card className="search-form">
        <Form
          form={searchForm}
          layout="inline"
          onFinish={handleSearch}
        >
          <Form.Item name="keyword" label="关键词">
            <Input placeholder="标题/内容" allowClear />
          </Form.Item>
          <Form.Item name="type" label="类型">
            <Select placeholder="选择类型" allowClear style={{ width: 120 }}>
              <Option value={NOTIFICATION_TYPES.SYSTEM}>系统通知</Option>
              <Option value={NOTIFICATION_TYPES.ANNOUNCEMENT}>公告</Option>
              <Option value={NOTIFICATION_TYPES.UPDATE}>更新通知</Option>
              <Option value={NOTIFICATION_TYPES.WARNING}>警告</Option>
            </Select>
          </Form.Item>
          <Form.Item name="status" label="状态">
            <Select placeholder="选择状态" allowClear style={{ width: 120 }}>
              <Option value={NOTIFICATION_STATUS.DRAFT}>草稿</Option>
              <Option value={NOTIFICATION_STATUS.SENT}>已发送</Option>
              <Option value={NOTIFICATION_STATUS.SCHEDULED}>已安排</Option>
            </Select>
          </Form.Item>
          <Form.Item>
            <Space>
              <Button type="primary" htmlType="submit" icon={<SearchOutlined />}>
                搜索
              </Button>
              <Button onClick={handleReset}>
                重置
              </Button>
            </Space>
          </Form.Item>
        </Form>
      </Card>

      {/* 操作按钮 */}
      <div className="table-actions">
        <Button
          type="primary"
          icon={<PlusOutlined />}
          onClick={handleAdd}
        >
          新增通知
        </Button>
      </div>

      {/* 通知表格 */}
      <Table
        columns={columns}
        dataSource={list}
        rowKey="_id"
        loading={loading}
        pagination={{
          ...PAGINATION_CONFIG,
          current: currentPage,
          pageSize: pageSize,
          total: total,
          onChange: (page, size) => {
            dispatch(setCurrentPage(page));
            if (size !== pageSize) {
              dispatch(setPageSize(size));
            }
          }
        }}
        scroll={{ x: 1200 }}
      />

      {/* 通知表单模态框 */}
      <Modal
        title={editingNotification ? '编辑通知' : '新增通知'}
        open={modalVisible}
        onCancel={() => setModalVisible(false)}
        footer={null}
        width={800}
        style={{ top: 20 }}
      >
        <Form
          form={form}
          layout="vertical"
          onFinish={handleSubmit}
        >
          <Form.Item
            name="title"
            label="通知标题"
            rules={[
              { required: true, message: '请输入通知标题' },
              { max: 100, message: '标题不能超过100个字符' }
            ]}
          >
            <Input placeholder="请输入通知标题" />
          </Form.Item>

          <Row gutter={16}>
            <Col span={12}>
              <Form.Item
                name="type"
                label="通知类型"
                rules={[{ required: true, message: '请选择通知类型' }]}
              >
                <Select placeholder="请选择通知类型">
                  <Option value={NOTIFICATION_TYPES.SYSTEM}>系统通知</Option>
                  <Option value={NOTIFICATION_TYPES.ANNOUNCEMENT}>公告</Option>
                  <Option value={NOTIFICATION_TYPES.UPDATE}>更新通知</Option>
                  <Option value={NOTIFICATION_TYPES.WARNING}>警告</Option>
                </Select>
              </Form.Item>
            </Col>
            <Col span={12}>
              <Form.Item name="priority" label="优先级">
                <Select placeholder="选择优先级" defaultValue="medium">
                  <Option value="low">低</Option>
                  <Option value="medium">中</Option>
                  <Option value="high">高</Option>
                </Select>
              </Form.Item>
            </Col>
          </Row>

          <Form.Item
            name="content"
            label="通知内容"
            rules={[{ required: true, message: '请输入通知内容' }]}
          >
            <ReactQuill
              theme="snow"
              modules={quillModules}
              style={{ height: '200px', marginBottom: '50px' }}
            />
          </Form.Item>

          <Form.Item name="scheduledAt" label="计划发送时间">
            <DatePicker
              showTime
              placeholder="选择发送时间（留空立即发送）"
              style={{ width: '100%' }}
              format="YYYY-MM-DD HH:mm"
            />
          </Form.Item>

          <Row gutter={16}>
            <Col span={12}>
              <Form.Item name="sendEmail" label="发送邮件" valuePropName="checked">
                <Switch />
              </Form.Item>
            </Col>
            <Col span={12}>
              <Form.Item name="sendSMS" label="发送短信" valuePropName="checked">
                <Switch />
              </Form.Item>
            </Col>
          </Row>

          <Form.Item name="targetUsers" label="目标用户">
            <Select
              mode="multiple"
              placeholder="选择目标用户（留空发送给所有用户）"
              style={{ width: '100%' }}
              allowClear
            >
              {/* 这里应该从用户列表中获取选项 */}
              <Option value="all">所有用户</Option>
              <Option value="admin">管理员</Option>
              <Option value="moderator">版主</Option>
              <Option value="user">普通用户</Option>
            </Select>
          </Form.Item>

          <Form.Item>
            <Space>
              <Button type="primary" htmlType="submit">
                {editingNotification ? '更新' : '创建'}
              </Button>
              <Button onClick={() => setModalVisible(false)}>
                取消
              </Button>
            </Space>
          </Form.Item>
        </Form>
      </Modal>
    </div>
  );
};

export default NotificationManagement;
