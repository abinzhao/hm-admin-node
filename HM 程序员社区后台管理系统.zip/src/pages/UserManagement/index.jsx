import React, { useEffect, useState } from 'react';
import {
  Table, Button, Space, Tag, Modal, Form, Input, Select,
  message, Popconfirm, Card, Row, Col, Avatar, Tooltip
} from 'antd';
import {
  PlusOutlined, EditOutlined, DeleteOutlined, SearchOutlined,
  UserOutlined, MailOutlined, PhoneOutlined
} from '@ant-design/icons';
import { useDispatch, useSelector } from 'react-redux';
import {
  fetchUsers, createUser, updateUser, deleteUser,
  setCurrentPage, setPageSize
} from '../../store/slices/userSlice';
import { USER_ROLES, USER_STATUS, PAGINATION_CONFIG } from '../../utils/constants';
import { formatDate } from '../../utils/helpers';

const { Option } = Select;

const UserManagement = () => {
  const [form] = Form.useForm();
  const [searchForm] = Form.useForm();
  const dispatch = useDispatch();
  const { list, total, loading, currentPage, pageSize } = useSelector(state => state.users);
  const [modalVisible, setModalVisible] = useState(false);
  const [editingUser, setEditingUser] = useState(null);
  const [searchParams, setSearchParams] = useState({});

  useEffect(() => {
    loadUsers();
  }, [currentPage, pageSize, searchParams]);

  const loadUsers = () => {
    dispatch(fetchUsers({
      page: currentPage,
      limit: pageSize,
      ...searchParams
    }));
  };

  const handleSearch = (values) => {
    setSearchParams(values);
    dispatch(setCurrentPage(1));
  };

  const handleReset = () => {
    searchForm.resetFields();
    setSearchParams({});
    dispatch(setCurrentPage(1));
  };

  const handleAdd = () => {
    setEditingUser(null);
    form.resetFields();
    setModalVisible(true);
  };

  const handleEdit = (record) => {
    setEditingUser(record);
    form.setFieldsValue(record);
    setModalVisible(true);
  };

  const handleDelete = async (id) => {
    try {
      await dispatch(deleteUser(id)).unwrap();
      message.success('删除成功');
      loadUsers();
    } catch (error) {
      message.error(error || '删除失败');
    }
  };

  const handleSubmit = async (values) => {
    try {
      if (editingUser) {
        await dispatch(updateUser({ id: editingUser._id, userData: values })).unwrap();
        message.success('更新成功');
      } else {
        await dispatch(createUser(values)).unwrap();
        message.success('创建成功');
      }
      setModalVisible(false);
      loadUsers();
    } catch (error) {
      message.error(error || '操作失败');
    }
  };

  const columns = [
    {
      title: '头像',
      dataIndex: 'avatar',
      key: 'avatar',
      width: 80,
      render: (avatar, record) => (
        <Avatar
          size={40}
          src={avatar}
          icon={<UserOutlined />}
          style={{ backgroundColor: '#87d068' }}
        >
          {!avatar && record.username?.charAt(0).toUpperCase()}
        </Avatar>
      )
    },
    {
      title: '用户名',
      dataIndex: 'username',
      key: 'username',
      sorter: true
    },
    {
      title: '邮箱',
      dataIndex: 'email',
      key: 'email',
      render: (email) => (
        <Space>
          <MailOutlined />
          {email}
        </Space>
      )
    },
    {
      title: '手机号',
      dataIndex: 'phone',
      key: 'phone',
      render: (phone) => phone ? (
        <Space>
          <PhoneOutlined />
          {phone}
        </Space>
      ) : '-'
    },
    {
      title: '角色',
      dataIndex: 'role',
      key: 'role',
      render: (role) => {
        const colors = {
          admin: 'red',
          moderator: 'orange',
          user: 'blue'
        };
        const labels = {
          admin: '管理员',
          moderator: '版主',
          user: '用户'
        };
        return <Tag color={colors[role]}>{labels[role]}</Tag>;
      }
    },
    {
      title: '状态',
      dataIndex: 'status',
      key: 'status',
      render: (status) => {
        const colors = {
          active: 'green',
          inactive: 'orange',
          banned: 'red'
        };
        const labels = {
          active: '活跃',
          inactive: '非活跃',
          banned: '已封禁'
        };
        return <Tag color={colors[status]}>{labels[status]}</Tag>;
      }
    },
    {
      title: '注册时间',
      dataIndex: 'createdAt',
      key: 'createdAt',
      render: (date) => (
        <Tooltip title={formatDate(date)}>
          {formatDate(date, 'YYYY-MM-DD')}
        </Tooltip>
      ),
      sorter: true
    },
    {
      title: '操作',
      key: 'action',
      width: 150,
      render: (_, record) => (
        <Space size="small">
          <Button
            type="link"
            icon={<EditOutlined />}
            onClick={() => handleEdit(record)}
            size="small"
          >
            编辑
          </Button>
          <Popconfirm
            title="确定要删除这个用户吗？"
            onConfirm={() => handleDelete(record._id)}
            okText="确定"
            cancelText="取消"
          >
            <Button
              type="link"
              danger
              icon={<DeleteOutlined />}
              size="small"
            >
              删除
            </Button>
          </Popconfirm>
        </Space>
      )
    }
  ];

  return (
    <div>
      <div className="page-header">
        <h1 className="page-title">用户管理</h1>
      </div>

      {/* 搜索表单 */}
      <Card className="search-form">
        <Form
          form={searchForm}
          layout="inline"
          onFinish={handleSearch}
        >
          <Form.Item name="keyword" label="关键词">
            <Input placeholder="用户名/邮箱" allowClear />
          </Form.Item>
          <Form.Item name="role" label="角色">
            <Select placeholder="选择角色" allowClear style={{ width: 120 }}>
              <Option value={USER_ROLES.ADMIN}>管理员</Option>
              <Option value={USER_ROLES.MODERATOR}>版主</Option>
              <Option value={USER_ROLES.USER}>用户</Option>
            </Select>
          </Form.Item>
          <Form.Item name="status" label="状态">
            <Select placeholder="选择状态" allowClear style={{ width: 120 }}>
              <Option value={USER_STATUS.ACTIVE}>活跃</Option>
              <Option value={USER_STATUS.INACTIVE}>非活跃</Option>
              <Option value={USER_STATUS.BANNED}>已封禁</Option>
            </Select>
          </Form.Item>
          <Form.Item>
            <Space>
              <Button type="primary" htmlType="submit" icon={<SearchOutlined />}>
                搜索
              </Button>
              <Button onClick={handleReset}>
                重置
              </Button>
            </Space>
          </Form.Item>
        </Form>
      </Card>

      {/* 操作按钮 */}
      <div className="table-actions">
        <Button
          type="primary"
          icon={<PlusOutlined />}
          onClick={handleAdd}
        >
          新增用户
        </Button>
      </div>

      {/* 用户表格 */}
      <Table
        columns={columns}
        dataSource={list}
        rowKey="_id"
        loading={loading}
        pagination={{
          ...PAGINATION_CONFIG,
          current: currentPage,
          pageSize: pageSize,
          total: total,
          onChange: (page, size) => {
            dispatch(setCurrentPage(page));
            if (size !== pageSize) {
              dispatch(setPageSize(size));
            }
          }
        }}
        scroll={{ x: 800 }}
      />

      {/* 用户表单模态框 */}
      <Modal
        title={editingUser ? '编辑用户' : '新增用户'}
        open={modalVisible}
        onCancel={() => setModalVisible(false)}
        footer={null}
        width={600}
      >
        <Form
          form={form}
          layout="vertical"
          onFinish={handleSubmit}
        >
          <Row gutter={16}>
            <Col span={12}>
              <Form.Item
                name="username"
                label="用户名"
                rules={[
                  { required: true, message: '请输入用户名' },
                  { min: 3, max: 20, message: '用户名长度为3-20个字符' }
                ]}
              >
                <Input placeholder="请输入用户名" />
              </Form.Item>
            </Col>
            <Col span={12}>
              <Form.Item
                name="email"
                label="邮箱"
                rules={[
                  { required: true, message: '请输入邮箱' },
                  { type: 'email', message: '请输入有效的邮箱地址' }
                ]}
              >
                <Input placeholder="请输入邮箱" />
              </Form.Item>
            </Col>
          </Row>

          <Row gutter={16}>
            <Col span={12}>
              <Form.Item
                name="phone"
                label="手机号"
                rules={[
                  { pattern: /^1[3-9]\d{9}$/, message: '请输入有效的手机号' }
                ]}
              >
                <Input placeholder="请输入手机号" />
              </Form.Item>
            </Col>
            <Col span={12}>
              <Form.Item
                name="role"
                label="角色"
                rules={[{ required: true, message: '请选择角色' }]}
              >
                <Select placeholder="请选择角色">
                  <Option value={USER_ROLES.ADMIN}>管理员</Option>
                  <Option value={USER_ROLES.MODERATOR}>版主</Option>
                  <Option value={USER_ROLES.USER}>用户</Option>
                </Select>
              </Form.Item>
            </Col>
          </Row>

          <Row gutter={16}>
            <Col span={12}>
              <Form.Item
                name="status"
                label="状态"
                rules={[{ required: true, message: '请选择状态' }]}
              >
                <Select placeholder="请选择状态">
                  <Option value={USER_STATUS.ACTIVE}>活跃</Option>
                  <Option value={USER_STATUS.INACTIVE}>非活跃</Option>
                  <Option value={USER_STATUS.BANNED}>已封禁</Option>
                </Select>
              </Form.Item>
            </Col>
            {!editingUser && (
              <Col span={12}>
                <Form.Item
                  name="password"
                  label="密码"
                  rules={[
                    { required: true, message: '请输入密码' },
                    { min: 6, message: '密码至少6个字符' }
                  ]}
                >
                  <Input.Password placeholder="请输入密码" />
                </Form.Item>
              </Col>
            )}
          </Row>

          <Form.Item name="bio" label="个人简介">
            <Input.TextArea
              rows={3}
              placeholder="请输入个人简介"
              maxLength={200}
              showCount
            />
          </Form.Item>

          <Form.Item>
            <Space>
              <Button type="primary" htmlType="submit">
                {editingUser ? '更新' : '创建'}
              </Button>
              <Button onClick={() => setModalVisible(false)}>
                取消
              </Button>
            </Space>
          </Form.Item>
        </Form>
      </Modal>
    </div>
  );
};

export default UserManagement;
