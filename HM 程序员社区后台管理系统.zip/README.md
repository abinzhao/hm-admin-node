# HM 程序员社区后台管理系统

一个基于 React + Node.js 的现代化后台管理系统，专为程序员社区设计。

## 🚀 技术栈

### 前端
- **React 18** - 现代化前端框架
- **Ant Design 5** - 企业级UI组件库
- **Redux Toolkit** - 状态管理
- **React Router 6** - 路由管理
- **Axios** - HTTP请求库
- **React Quill** - 富文本编辑器
- **Monaco Editor** - 代码编辑器
- **ECharts** - 数据可视化

### 后端
- **Node.js** - 服务端运行环境
- **Express.js** - Web应用框架
- **MongoDB** - NoSQL数据库
- **Mongoose** - MongoDB对象建模
- **JWT** - 身份认证
- **bcryptjs** - 密码加密
- **Multer** - 文件上传

## 📋 功能特性

### 核心功能
- 🔐 **用户管理** - 完整的用户CRUD，角色权限控制
- 📝 **内容管理** - 支持文章、问答、代码、软件包等多种内容类型
- 💬 **留言管理** - 用户留言和管理员回复系统
- ✅ **待办事项** - 任务管理和进度跟踪
- 📢 **系统通知** - 多类型通知和定时发送
- 📊 **日志监控** - 系统日志记录和可视化分析

### 系统特性
- 🛡️ **安全性** - JWT认证、密码加密、API保护
- 📱 **响应式** - 适配桌面和移动设备
- 🎨 **现代化UI** - 精美的界面设计和交互体验
- ⚡ **高性能** - 优化的数据库查询和前端渲染
- 🔍 **搜索筛选** - 强大的数据筛选和搜索功能

## 🛠️ 本地开发

### 环境要求
- Node.js >= 16.0.0
- MongoDB >= 4.4.0
- npm >= 8.0.0

### 安装步骤

1. **安装依赖**
```bash
# 安装前端依赖
npm install

# 安装后端依赖
cd server
npm install
cd ..
```

2. **配置环境变量**
```bash
# 复制环境变量文件
cp server/.env.example server/.env

# 编辑环境变量（可选，默认配置已可用）
# vim server/.env
```

3. **启动 MongoDB**
```bash
# 使用 Docker 启动 MongoDB（推荐）
docker run -d --name mongodb -p 27017:27017 mongo:latest

# 或使用本地安装的 MongoDB
mongod --dbpath /path/to/your/db
```

4. **初始化数据**
```bash
# 运行数据初始化脚本
cd server
node scripts/seed.js
cd ..
```

5. **启动开发服务器**
```bash
# 同时启动前后端服务
npm run dev

# 或分别启动
npm run client  # 前端服务 (http://localhost:3000)
npm run server  # 后端服务 (http://localhost:5000)
```

### 默认账号
- **管理员**: admin / 123456
- **普通用户**: user1 / 123456

## 📁 项目结构

```
hm-admin-system/
├── src/                    # 前端源码
│   ├── components/         # 公共组件
│   ├── pages/             # 页面组件
│   ├── store/             # Redux状态管理
│   ├── utils/             # 工具函数
│   └── styles/            # 样式文件
├── server/                # 后端源码
│   ├── models/            # 数据模型
│   ├── routes/            # API路由
│   ├── middleware/        # 中间件
│   ├── utils/             # 工具函数
│   └── scripts/           # 脚本文件
├── public/                # 静态资源
└── package.json           # 项目配置
```

## 🔧 开发指南

### API接口
所有API接口都有统一的返回格式：
```json
{
  "success": true,
  "data": {},
  "message": "操作成功"
}
```

### 权限控制
- **admin**: 系统管理员，拥有所有权限
- **moderator**: 版主，可管理内容和用户
- **user**: 普通用户，基础功能权限

### 数据库设计
系统包含以下主要数据模型：
- User - 用户信息
- Content - 内容管理
- Message - 留言系统
- Todo - 待办事项
- Notification - 系统通知
- Log - 系统日志

## 🚀 部署指南

### 生产环境构建
```bash
# 构建前端
npm run build

# 启动生产服务器
cd server
npm start
```

### Docker 部署
```bash
# 构建镜像
docker build -t hm-admin .

# 运行容器
docker run -d -p 3000:3000 -p 5000:5000 hm-admin
```

## 📝 更新日志

### v1.0.0
- ✅ 完整的用户管理系统
- ✅ 多类型内容管理
- ✅ 留言和回复功能
- ✅ 待办事项管理
- ✅ 系统通知功能
- ✅ 日志监控和统计
- ✅ 响应式界面设计

## 🤝 贡献指南

1. Fork 项目
2. 创建功能分支 (`git checkout -b feature/AmazingFeature`)
3. 提交更改 (`git commit -m 'Add some AmazingFeature'`)
4. 推送到分支 (`git push origin feature/AmazingFeature`)
5. 打开 Pull Request

## 📄 许可证

本项目采用 MIT 许可证 - 查看 [LICENSE](LICENSE) 文件了解详情。

## 📞 联系我们

- 项目地址: [GitHub](https://github.com/your-username/hm-admin-system)
- 问题反馈: [Issues](https://github.com/your-username/hm-admin-system/issues)
- 邮箱: admin@hm.com

---

⭐ 如果这个项目对你有帮助，请给它一个星标！
