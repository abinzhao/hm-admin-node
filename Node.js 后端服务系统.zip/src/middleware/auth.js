const jwt = require('jsonwebtoken');
const { query } = require('../database/connection');
const logger = require('../utils/logger');

/**
 * JWT认证中间件
 */
async function authenticateToken(req, res, next) {
  try {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];
    
    if (!token) {
      return res.error('访问令牌缺失', 401);
    }
    
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    
    // 验证用户是否存在且状态正常
    const user = await query(
      'SELECT id, user_id, username, nickname, role, status FROM users WHERE id = ? AND status = ?',
      [decoded.userId, 'active']
    );
    
    if (user.length === 0) {
      return res.error('用户不存在或已被禁用', 401);
    }
    
    req.user = user[0];
    next();
  } catch (error) {
    logger.error('Token验证失败:', error);
    
    if (error.name === 'TokenExpiredError') {
      return res.error('访问令牌已过期', 401);
    }
    
    if (error.name === 'JsonWebTokenError') {
      return res.error('无效的访问令牌', 401);
    }
    
    return res.error('认证失败', 401);
  }
}

/**
 * 角色权限验证中间件
 */
function requireRole(...roles) {
  return (req, res, next) => {
    if (!req.user) {
      return res.error('用户未认证', 401);
    }
    
    if (!roles.includes(req.user.role)) {
      return res.error('权限不足', 403);
    }
    
    next();
  };
}

/**
 * 可选认证中间件（不强制要求登录）
 */
async function optionalAuth(req, res, next) {
  try {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];
    
    if (token) {
      const decoded = jwt.verify(token, process.env.JWT_SECRET);
      const user = await query(
        'SELECT id, user_id, username, nickname, role, status FROM users WHERE id = ? AND status = ?',
        [decoded.userId, 'active']
      );
      
      if (user.length > 0) {
        req.user = user[0];
      }
    }
    
    next();
  } catch (error) {
    // 可选认证失败时不返回错误，继续执行
    next();
  }
}

module.exports = {
  authenticateToken,
  requireRole,
  optionalAuth
};
