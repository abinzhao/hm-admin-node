/**
 * 统一响应格式中间件
 */
function responseFormatter(req, res, next) {
  // 成功响应
  res.success = function(data = null, message = '操作成功', code = 200) {
    return res.status(200).json({
      code,
      message,
      data,
      timestamp: new Date().toISOString()
    });
  };
  
  // 错误响应
  res.error = function(message = '操作失败', code = 500, data = null) {
    return res.status(code >= 400 && code < 600 ? code : 500).json({
      code,
      message,
      data,
      timestamp: new Date().toISOString()
    });
  };
  
  // 分页响应
  res.paginate = function(data, pagination, message = '获取成功') {
    return res.status(200).json({
      code: 200,
      message,
      data,
      pagination,
      timestamp: new Date().toISOString()
    });
  };
  
  next();
}

module.exports = responseFormatter;
