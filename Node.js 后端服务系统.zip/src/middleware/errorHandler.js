const logger = require('../utils/logger');

/**
 * 全局错误处理中间件
 */
function errorHandler(err, req, res, next) {
  logger.error('Unhandled Error:', {
    error: err.message,
    stack: err.stack,
    url: req.originalUrl,
    method: req.method,
    ip: req.ip,
    userAgent: req.get('User-Agent')
  });
  
  // 数据库错误
  if (err.code === 'ER_DUP_ENTRY') {
    return res.error('数据已存在', 409);
  }
  
  if (err.code === 'ER_NO_REFERENCED_ROW_2') {
    return res.error('关联数据不存在', 400);
  }
  
  // JWT错误
  if (err.name === 'JsonWebTokenError') {
    return res.error('无效的token', 401);
  }
  
  if (err.name === 'TokenExpiredError') {
    return res.error('token已过期', 401);
  }
  
  // 验证错误
  if (err.name === 'ValidationError') {
    return res.error(err.message, 400);
  }
  
  // 文件上传错误
  if (err.code === 'LIMIT_FILE_SIZE') {
    return res.error('文件大小超出限制', 413);
  }
  
  // 默认错误
  const statusCode = err.statusCode || 500;
  const message = process.env.NODE_ENV === 'production' 
    ? '服务器内部错误' 
    : err.message;
  
  res.error(message, statusCode);
}

module.exports = errorHandler;
