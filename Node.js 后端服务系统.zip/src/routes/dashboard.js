const express = require('express');
const { query } = require('../database/connection');
const { authenticateToken, optionalAuth } = require('../middleware/auth');
const logger = require('../utils/logger');

const router = express.Router();

/**
 * 获取首页统计数据
 */
router.get('/stats', optionalAuth, async (req, res) => {
  try {
    // 基础统计数据
    const basicStats = await query(`
      SELECT 
        (SELECT COUNT(*) FROM contents WHERE content_type = 'article' AND status = 'published') as articleCount,
        (SELECT COUNT(*) FROM contents WHERE content_type = 'snippet' AND status = 'published') as snippetCount,
        (SELECT COUNT(*) FROM apps WHERE status = 'active') as packageCount,
        (SELECT COUNT(*) FROM messages WHERE status = 'unread') as unreadMessages
    `);
    
    // 系统信息
    const systemInfo = {
      version: "v5.1.3",
      status: "运行正常",
      lastUpdate: "2025-05-28",
      uptime: Math.floor(process.uptime()),
      nodeVersion: process.version,
      platform: process.platform,
      memory: {
        used: Math.round(process.memoryUsage().heapUsed / 1024 / 1024),
        total: Math.round(process.memoryUsage().heapTotal / 1024 / 1024)
      }
    };
    
    // 如果用户已登录，获取个人统计
    let userStats = null;
    if (req.user) {
      const userStatsResult = await query(`
        SELECT 
          (SELECT COUNT(*) FROM contents WHERE user_id = ?) as myContents,
          (SELECT COUNT(*) FROM apps WHERE user_id = ?) as myApps,
          (SELECT COUNT(*) FROM todos WHERE user_id = ? AND status != 'completed') as pendingTodos,
          (SELECT COUNT(*) FROM messages WHERE user_id = ?) as myMessages
      `, [req.user.id, req.user.id, req.user.id, req.user.id]);
      
      userStats = userStatsResult[0];
    }
    
    res.success({
      ...basicStats[0],
      systemInfo,
      userStats
    });
    
  } catch (error) {
    logger.error('获取首页统计数据失败:', error);
    res.error('获取统计数据失败');
  }
});

/**
 * 获取内容趋势数据
 */
router.get('/trends/content', async (req, res) => {
  try {
    const days = parseInt(req.query.days) || 7;
    
    const trends = await query(`
      SELECT 
        DATE(create_time) as date,
        COUNT(*) as total,
        SUM(CASE WHEN content_type = 'article' THEN 1 ELSE 0 END) as articles,
        SUM(CASE WHEN content_type = 'question' THEN 1 ELSE 0 END) as questions,
        SUM(CASE WHEN content_type = 'snippet' THEN 1 ELSE 0 END) as snippets
      FROM contents 
      WHERE create_time >= DATE_SUB(CURDATE(), INTERVAL ? DAY)
        AND status = 'published'
      GROUP BY DATE(create_time)
      ORDER BY date ASC
    `, [days]);
    
    res.success(trends);
    
  } catch (error) {
    logger.error('获取内容趋势数据失败:', error);
    res.error('获取趋势数据失败');
  }
});

/**
 * 获取用户活跃度数据
 */
router.get('/trends/users', authenticateToken, async (req, res) => {
  try {
    const days = parseInt(req.query.days) || 7;
    
    const userTrends = await query(`
      SELECT 
        DATE(create_time) as date,
        COUNT(*) as new_users
      FROM users 
      WHERE create_time >= DATE_SUB(CURDATE(), INTERVAL ? DAY)
      GROUP BY DATE(create_time)
      ORDER BY date ASC
    `, [days]);
    
    const loginTrends = await query(`
      SELECT 
        DATE(last_login_time) as date,
        COUNT(DISTINCT id) as active_users
      FROM users 
      WHERE last_login_time >= DATE_SUB(CURDATE(), INTERVAL ? DAY)
      GROUP BY DATE(last_login_time)
      ORDER BY date ASC
    `, [days]);
    
    res.success({
      newUsers: userTrends,
      activeUsers: loginTrends
    });
    
  } catch (error) {
    logger.error('获取用户活跃度数据失败:', error);
    res.error('获取用户活跃度数据失败');
  }
});

/**
 * 获取热门内容
 */
router.get('/popular/content', async (req, res) => {
  try {
    const limit = parseInt(req.query.limit) || 10;
    const type = req.query.type || '';
    
    let whereClause = 'WHERE status = "published"';
    let queryParams = [];
    
    if (type) {
      whereClause += ' AND content_type = ?';
      queryParams.push(type);
    }
    
    queryParams.push(limit);
    
    const popularContent = await query(`
      SELECT c.id, c.title, c.content_type, c.view_count, c.like_count, c.create_time,
             u.username, u.nickname, u.avatar
      FROM contents c
      LEFT JOIN users u ON c.user_id = u.id
      ${whereClause}
      ORDER BY (c.view_count * 0.7 + c.like_count * 0.3) DESC
      LIMIT ?
    `, queryParams);
    
    res.success(popularContent);
    
  } catch (error) {
    logger.error('获取热门内容失败:', error);
    res.error('获取热门内容失败');
  }
});

/**
 * 获取热门应用
 */
router.get('/popular/apps', async (req, res) => {
  try {
    const limit = parseInt(req.query.limit) || 10;
    
    const popularApps = await query(`
      SELECT a.id, a.app_name, a.package_name, a.app_logo, a.downloads, a.create_time,
             u.username, u.nickname
      FROM apps a
      LEFT JOIN users u ON a.user_id = u.id
      WHERE a.status = 'active'
      ORDER BY a.downloads DESC
      LIMIT ?
    `, [limit]);
    
    res.success(popularApps);
    
  } catch (error) {
    logger.error('获取热门应用失败:', error);
    res.error('获取热门应用失败');
  }
});

/**
 * 获取最新活动
 */
router.get('/recent/activities', async (req, res) => {
  try {
    const limit = parseInt(req.query.limit) || 20;
    
    // 获取最新内容
    const recentContents = await query(`
      SELECT 'content' as type, c.id, c.title as name, c.content_type as subtype, 
             c.create_time, u.username, u.nickname, u.avatar
      FROM contents c
      LEFT JOIN users u ON c.user_id = u.id
      WHERE c.status = 'published'
      ORDER BY c.create_time DESC
      LIMIT ?
    `, [Math.floor(limit / 2)]);
    
    // 获取最新应用
    const recentApps = await query(`
      SELECT 'app' as type, a.id, a.app_name as name, a.app_type as subtype,
             a.create_time, u.username, u.nickname, u.avatar
      FROM apps a
      LEFT JOIN users u ON a.user_id = u.id
      WHERE a.status = 'active'
      ORDER BY a.create_time DESC
      LIMIT ?
    `, [Math.floor(limit / 2)]);
    
    // 合并并按时间排序
    const activities = [...recentContents, ...recentApps]
      .sort((a, b) => new Date(b.create_time) - new Date(a.create_time))
      .slice(0, limit);
    
    res.success(activities);
    
  } catch (error) {
    logger.error('获取最新活动失败:', error);
    res.error('获取最新活动失败');
  }
});

/**
 * 获取系统健康状态
 */
router.get('/health', async (req, res) => {
  try {
    // 数据库连接检查
    const dbCheck = await query('SELECT 1 as status');
    const dbStatus = dbCheck.length > 0 ? 'healthy' : 'error';
    
    // 系统资源使用情况
    const memoryUsage = process.memoryUsage();
    const cpuUsage = process.cpuUsage();
    
    const healthStatus = {
      status: 'healthy',
      timestamp: new Date().toISOString(),
      uptime: process.uptime(),
      database: {
        status: dbStatus,
        responseTime: Date.now() // 简化的响应时间
      },
      system: {
        memory: {
          used: Math.round(memoryUsage.heapUsed / 1024 / 1024),
          total: Math.round(memoryUsage.heapTotal / 1024 / 1024),
          usage: Math.round((memoryUsage.heapUsed / memoryUsage.heapTotal) * 100)
        },
        cpu: {
          user: cpuUsage.user,
          system: cpuUsage.system
        },
        nodeVersion: process.version,
        platform: process.platform
      }
    };
    
    res.success(healthStatus);
    
  } catch (error) {
    logger.error('获取系统健康状态失败:', error);
    res.error('获取系统状态失败');
  }
});

/**
 * 获取管理员仪表板数据（管理员权限）
 */
router.get('/admin/overview', authenticateToken, async (req, res) => {
  try {
    if (req.user.role !== 'admin') {
      return res.error('权限不足', 403);
    }
    
    // 用户统计
    const userStats = await query(`
      SELECT 
        COUNT(*) as total_users,
        SUM(CASE WHEN status = 'active' THEN 1 ELSE 0 END) as active_users,
        SUM(CASE WHEN DATE(create_time) = CURDATE() THEN 1 ELSE 0 END) as today_new_users,
        SUM(CASE WHEN DATE(create_time) >= DATE_SUB(CURDATE(), INTERVAL 7 DAY) THEN 1 ELSE 0 END) as week_new_users
      FROM users
    `);
    
    // 内容统计
    const contentStats = await query(`
      SELECT 
        COUNT(*) as total_contents,
        SUM(CASE WHEN status = 'published' THEN 1 ELSE 0 END) as published_contents,
        SUM(CASE WHEN DATE(create_time) = CURDATE() THEN 1 ELSE 0 END) as today_new_contents,
        SUM(view_count) as total_views
      FROM contents
    `);
    
    // 应用统计
    const appStats = await query(`
      SELECT 
        COUNT(*) as total_apps,
        SUM(CASE WHEN status = 'active' THEN 1 ELSE 0 END) as active_apps,
        SUM(downloads) as total_downloads
      FROM apps
    `);
    
    // 留言统计
    const messageStats = await query(`
      SELECT 
        COUNT(*) as total_messages,
        SUM(CASE WHEN status = 'unread' THEN 1 ELSE 0 END) as unread_messages,
        SUM(CASE WHEN DATE(create_time) = CURDATE() THEN 1 ELSE 0 END) as today_new_messages
      FROM messages
    `);
    
    res.success({
      users: userStats[0],
      contents: contentStats[0],
      apps: appStats[0],
      messages: messageStats[0]
    });
    
  } catch (error) {
    logger.error('获取管理员仪表板数据失败:', error);
    res.error('获取仪表板数据失败');
  }
});

module.exports = router;
