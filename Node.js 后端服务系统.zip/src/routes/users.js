const express = require('express');
const { query } = require('../database/connection');
const { authenticateToken, requireRole } = require('../middleware/auth');
const { validatePagination, validateId } = require('../middleware/validation');
const logger = require('../utils/logger');

const router = express.Router();

/**
 * 获取用户列表（管理员权限）
 */
router.get('/', authenticateToken, requireRole('admin'), validatePagination, async (req, res) => {
  try {
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 10;
    const offset = (page - 1) * limit;
    const search = req.query.search || '';
    const role = req.query.role || '';
    const status = req.query.status || '';
    
    // 构建查询条件
    let whereConditions = [];
    let queryParams = [];
    
    if (search) {
      whereConditions.push('(username LIKE ? OR nickname LIKE ? OR email LIKE ?)');
      queryParams.push(`%${search}%`, `%${search}%`, `%${search}%`);
    }
    
    if (role) {
      whereConditions.push('role = ?');
      queryParams.push(role);
    }
    
    if (status) {
      whereConditions.push('status = ?');
      queryParams.push(status);
    }
    
    const whereClause = whereConditions.length > 0 ? `WHERE ${whereConditions.join(' AND ')}` : '';
    
    // 获取总数
    const countResult = await query(`
      SELECT COUNT(*) as total FROM users ${whereClause}
    `, queryParams);
    
    const total = countResult[0].total;
    
    // 获取用户列表
    const users = await query(`
      SELECT id, user_id, username, nickname, role, phone, email, tags, 
             description, avatar, status, create_time, last_login_time
      FROM users ${whereClause}
      ORDER BY create_time DESC
      LIMIT ? OFFSET ?
    `, [...queryParams, limit, offset]);
    
    // 处理tags字段
    users.forEach(user => {
      user.tags = user.tags ? JSON.parse(user.tags) : [];
    });
    
    res.paginate(users, {
      page,
      limit,
      total,
      pages: Math.ceil(total / limit)
    });
    
  } catch (error) {
    logger.error('获取用户列表失败:', error);
    res.error('获取用户列表失败');
  }
});

/**
 * 获取用户详情
 */
router.get('/:id', authenticateToken, validateId, async (req, res) => {
  try {
    const userId = parseInt(req.params.id);
    
    // 检查权限：只能查看自己的信息或管理员可以查看所有用户
    if (req.user.role !== 'admin' && req.user.id !== userId) {
      return res.error('权限不足', 403);
    }
    
    const users = await query(`
      SELECT id, user_id, username, nickname, role, phone, email, tags, 
             description, avatar, status, create_time, last_login_time
      FROM users WHERE id = ?
    `, [userId]);
    
    if (users.length === 0) {
      return res.error('用户不存在', 404);
    }
    
    const user = users[0];
    user.tags = user.tags ? JSON.parse(user.tags) : [];
    
    res.success(user);
    
  } catch (error) {
    logger.error('获取用户详情失败:', error);
    res.error('获取用户详情失败');
  }
});

/**
 * 更新用户状态（管理员权限）
 */
router.put('/:id/status', authenticateToken, requireRole('admin'), validateId, async (req, res) => {
  try {
    const userId = parseInt(req.params.id);
    const { status } = req.body;
    
    if (!['active', 'inactive'].includes(status)) {
      return res.error('状态值无效', 400);
    }
    
    // 不能禁用自己
    if (req.user.id === userId && status === 'inactive') {
      return res.error('不能禁用自己的账户', 400);
    }
    
    const result = await query(
      'UPDATE users SET status = ? WHERE id = ?',
      [status, userId]
    );
    
    if (result.affectedRows === 0) {
      return res.error('用户不存在', 404);
    }
    
    logger.info('用户状态更新成功:', { userId, status, operator: req.user.id });
    
    res.success(null, '状态更新成功');
    
  } catch (error) {
    logger.error('更新用户状态失败:', error);
    res.error('更新用户状态失败');
  }
});

/**
 * 更新用户角色（管理员权限）
 */
router.put('/:id/role', authenticateToken, requireRole('admin'), validateId, async (req, res) => {
  try {
    const userId = parseInt(req.params.id);
    const { role } = req.body;
    
    if (!['admin', 'user'].includes(role)) {
      return res.error('角色值无效', 400);
    }
    
    // 不能修改自己的角色
    if (req.user.id === userId) {
      return res.error('不能修改自己的角色', 400);
    }
    
    const result = await query(
      'UPDATE users SET role = ? WHERE id = ?',
      [role, userId]
    );
    
    if (result.affectedRows === 0) {
      return res.error('用户不存在', 404);
    }
    
    logger.info('用户角色更新成功:', { userId, role, operator: req.user.id });
    
    res.success(null, '角色更新成功');
    
  } catch (error) {
    logger.error('更新用户角色失败:', error);
    res.error('更新用户角色失败');
  }
});

/**
 * 删除用户（管理员权限）
 */
router.delete('/:id', authenticateToken, requireRole('admin'), validateId, async (req, res) => {
  try {
    const userId = parseInt(req.params.id);
    
    // 不能删除自己
    if (req.user.id === userId) {
      return res.error('不能删除自己的账户', 400);
    }
    
    const result = await query('DELETE FROM users WHERE id = ?', [userId]);
    
    if (result.affectedRows === 0) {
      return res.error('用户不存在', 404);
    }
    
    logger.info('用户删除成功:', { userId, operator: req.user.id });
    
    res.success(null, '用户删除成功');
    
  } catch (error) {
    logger.error('删除用户失败:', error);
    res.error('删除用户失败');
  }
});

/**
 * 获取用户统计信息（管理员权限）
 */
router.get('/stats/overview', authenticateToken, requireRole('admin'), async (req, res) => {
  try {
    const stats = await query(`
      SELECT 
        COUNT(*) as total_users,
        SUM(CASE WHEN status = 'active' THEN 1 ELSE 0 END) as active_users,
        SUM(CASE WHEN status = 'inactive' THEN 1 ELSE 0 END) as inactive_users,
        SUM(CASE WHEN role = 'admin' THEN 1 ELSE 0 END) as admin_users,
        SUM(CASE WHEN role = 'user' THEN 1 ELSE 0 END) as normal_users,
        SUM(CASE WHEN DATE(create_time) = CURDATE() THEN 1 ELSE 0 END) as today_new_users,
        SUM(CASE WHEN DATE(create_time) >= DATE_SUB(CURDATE(), INTERVAL 7 DAY) THEN 1 ELSE 0 END) as week_new_users
      FROM users
    `);
    
    res.success(stats[0]);
    
  } catch (error) {
    logger.error('获取用户统计失败:', error);
    res.error('获取用户统计失败');
  }
});

module.exports = router;
