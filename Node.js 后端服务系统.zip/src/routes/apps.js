const express = require('express');
const { query } = require('../database/connection');
const { authenticateToken, optionalAuth } = require('../middleware/auth');
const { validateAppCreation, validatePagination, validateId } = require('../middleware/validation');
const logger = require('../utils/logger');

const router = express.Router();

/**
 * 获取应用列表
 */
router.get('/', optionalAuth, validatePagination, async (req, res) => {
  try {
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 10;
    const offset = (page - 1) * limit;
    const search = req.query.search || '';
    const appType = req.query.app_type || '';
    const userId = req.query.user_id || '';
    
    // 构建查询条件
    let whereConditions = ['a.status = ?'];
    let queryParams = ['active'];
    
    if (search) {
      whereConditions.push('(a.app_name LIKE ? OR a.package_name LIKE ? OR a.description LIKE ?)');
      queryParams.push(`%${search}%`, `%${search}%`, `%${search}%`);
    }
    
    if (appType) {
      whereConditions.push('a.app_type = ?');
      queryParams.push(appType);
    }
    
    if (userId) {
      whereConditions.push('a.user_id = ?');
      queryParams.push(userId);
    }
    
    const whereClause = `WHERE ${whereConditions.join(' AND ')}`;
    
    // 获取总数
    const countResult = await query(`
      SELECT COUNT(*) as total 
      FROM apps a 
      LEFT JOIN users u ON a.user_id = u.id 
      ${whereClause}
    `, queryParams);
    
    const total = countResult[0].total;
    
    // 获取应用列表
    const apps = await query(`
      SELECT a.*, u.username, u.nickname, u.avatar
      FROM apps a
      LEFT JOIN users u ON a.user_id = u.id
      ${whereClause}
      ORDER BY a.create_time DESC
      LIMIT ? OFFSET ?
    `, [...queryParams, limit, offset]);
    
    // 处理JSON字段
    apps.forEach(app => {
      app.app_screenshot = app.app_screenshot ? JSON.parse(app.app_screenshot) : [];
    });
    
    res.paginate(apps, {
      page,
      limit,
      total,
      pages: Math.ceil(total / limit)
    });
    
  } catch (error) {
    logger.error('获取应用列表失败:', error);
    res.error('获取应用列表失败');
  }
});

/**
 * 获取应用详情
 */
router.get('/:id', optionalAuth, validateId, async (req, res) => {
  try {
    const appId = parseInt(req.params.id);
    
    const apps = await query(`
      SELECT a.*, u.username, u.nickname, u.avatar
      FROM apps a
      LEFT JOIN users u ON a.user_id = u.id
      WHERE a.id = ? AND a.status = ?
    `, [appId, 'active']);
    
    if (apps.length === 0) {
      return res.error('应用不存在', 404);
    }
    
    const app = apps[0];
    app.app_screenshot = app.app_screenshot ? JSON.parse(app.app_screenshot) : [];
    
    res.success(app);
    
  } catch (error) {
    logger.error('获取应用详情失败:', error);
    res.error('获取应用详情失败');
  }
});

/**
 * 创建应用
 */
router.post('/', authenticateToken, validateAppCreation, async (req, res) => {
  try {
    const {
      package_name, app_name, description, app_logo, app_dev_type,
      update_info, app_version, app_size, app_url, app_type, app_screenshot
    } = req.body;
    
    // 检查包名是否已存在
    const existingApp = await query(
      'SELECT id FROM apps WHERE package_name = ?',
      [package_name]
    );
    
    if (existingApp.length > 0) {
      return res.error('包名已存在', 409);
    }
    
    const result = await query(`
      INSERT INTO apps (
        user_id, package_name, app_name, description, app_logo, app_dev_type,
        update_info, app_version, app_size, app_url, app_type, app_screenshot
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `, [
      req.user.id, package_name, app_name, description, app_logo, app_dev_type,
      update_info, app_version, app_size, app_url, app_type,
      JSON.stringify(app_screenshot || [])
    ]);
    
    logger.info('应用创建成功:', { appId: result.insertId, userId: req.user.id });
    
    res.success({
      id: result.insertId,
      package_name,
      app_name
    }, '应用创建成功');
    
  } catch (error) {
    logger.error('创建应用失败:', error);
    res.error('创建应用失败');
  }
});

/**
 * 更新应用
 */
router.put('/:id', authenticateToken, validateId, async (req, res) => {
  try {
    const appId = parseInt(req.params.id);
    const {
      package_name, app_name, description, app_logo, app_dev_type,
      update_info, app_version, app_size, app_url, app_type, app_screenshot, status
    } = req.body;
    
    // 检查应用是否存在且属于当前用户
    const existingApp = await query(
      'SELECT user_id FROM apps WHERE id = ?',
      [appId]
    );
    
    if (existingApp.length === 0) {
      return res.error('应用不存在', 404);
    }
    
    if (existingApp[0].user_id !== req.user.id && req.user.role !== 'admin') {
      return res.error('权限不足', 403);
    }
    
    // 如果更新包名，检查是否与其他应用冲突
    if (package_name) {
      const conflictApp = await query(
        'SELECT id FROM apps WHERE package_name = ? AND id != ?',
        [package_name, appId]
      );
      
      if (conflictApp.length > 0) {
        return res.error('包名已被其他应用使用', 409);
      }
    }
    
    const updateFields = [];
    const updateValues = [];
    
    if (package_name !== undefined) {
      updateFields.push('package_name = ?');
      updateValues.push(package_name);
    }
    
    if (app_name !== undefined) {
      updateFields.push('app_name = ?');
      updateValues.push(app_name);
    }
    
    if (description !== undefined) {
      updateFields.push('description = ?');
      updateValues.push(description);
    }
    
    if (app_logo !== undefined) {
      updateFields.push('app_logo = ?');
      updateValues.push(app_logo);
    }
    
    if (app_dev_type !== undefined) {
      updateFields.push('app_dev_type = ?');
      updateValues.push(app_dev_type);
    }
    
    if (update_info !== undefined) {
      updateFields.push('update_info = ?');
      updateValues.push(update_info);
    }
    
    if (app_version !== undefined) {
      updateFields.push('app_version = ?');
      updateValues.push(app_version);
    }
    
    if (app_size !== undefined) {
      updateFields.push('app_size = ?');
      updateValues.push(app_size);
    }
    
    if (app_url !== undefined) {
      updateFields.push('app_url = ?');
      updateValues.push(app_url);
    }
    
    if (app_type !== undefined) {
      updateFields.push('app_type = ?');
      updateValues.push(app_type);
    }
    
    if (app_screenshot !== undefined) {
      updateFields.push('app_screenshot = ?');
      updateValues.push(JSON.stringify(app_screenshot));
    }
    
    if (status !== undefined) {
      updateFields.push('status = ?');
      updateValues.push(status);
    }
    
    if (updateFields.length === 0) {
      return res.error('没有要更新的字段', 400);
    }
    
    updateValues.push(appId);
    
    await query(`
      UPDATE apps SET ${updateFields.join(', ')} WHERE id = ?
    `, updateValues);
    
    logger.info('应用更新成功:', { appId, userId: req.user.id });
    
    res.success(null, '应用更新成功');
    
  } catch (error) {
    logger.error('更新应用失败:', error);
    res.error('更新应用失败');
  }
});

/**
 * 删除应用
 */
router.delete('/:id', authenticateToken, validateId, async (req, res) => {
  try {
    const appId = parseInt(req.params.id);
    
    // 检查应用是否存在且属于当前用户
    const existingApp = await query(
      'SELECT user_id FROM apps WHERE id = ?',
      [appId]
    );
    
    if (existingApp.length === 0) {
      return res.error('应用不存在', 404);
    }
    
    if (existingApp[0].user_id !== req.user.id && req.user.role !== 'admin') {
      return res.error('权限不足', 403);
    }
    
    await query('DELETE FROM apps WHERE id = ?', [appId]);
    
    logger.info('应用删除成功:', { appId, userId: req.user.id });
    
    res.success(null, '应用删除成功');
    
  } catch (error) {
    logger.error('删除应用失败:', error);
    res.error('删除应用失败');
  }
});

/**
 * 增加下载量
 */
router.post('/:id/download', validateId, async (req, res) => {
  try {
    const appId = parseInt(req.params.id);
    
    const result = await query(
      'UPDATE apps SET downloads = downloads + 1 WHERE id = ? AND status = ?',
      [appId, 'active']
    );
    
    if (result.affectedRows === 0) {
      return res.error('应用不存在', 404);
    }
    
    res.success(null, '下载量更新成功');
    
  } catch (error) {
    logger.error('更新下载量失败:', error);
    res.error('更新下载量失败');
  }
});

/**
 * 获取我的应用列表
 */
router.get('/my/list', authenticateToken, validatePagination, async (req, res) => {
  try {
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 10;
    const offset = (page - 1) * limit;
    const search = req.query.search || '';
    const appType = req.query.app_type || '';
    const status = req.query.status || '';
    
    // 构建查询条件
    let whereConditions = ['user_id = ?'];
    let queryParams = [req.user.id];
    
    if (search) {
      whereConditions.push('(app_name LIKE ? OR package_name LIKE ?)');
      queryParams.push(`%${search}%`, `%${search}%`);
    }
    
    if (appType) {
      whereConditions.push('app_type = ?');
      queryParams.push(appType);
    }
    
    if (status) {
      whereConditions.push('status = ?');
      queryParams.push(status);
    }
    
    const whereClause = `WHERE ${whereConditions.join(' AND ')}`;
    
    // 获取总数
    const countResult = await query(`
      SELECT COUNT(*) as total FROM apps ${whereClause}
    `, queryParams);
    
    const total = countResult[0].total;
    
    // 获取应用列表
    const apps = await query(`
      SELECT * FROM apps ${whereClause}
      ORDER BY create_time DESC
      LIMIT ? OFFSET ?
    `, [...queryParams, limit, offset]);
    
    // 处理JSON字段
    apps.forEach(app => {
      app.app_screenshot = app.app_screenshot ? JSON.parse(app.app_screenshot) : [];
    });
    
    res.paginate(apps, {
      page,
      limit,
      total,
      pages: Math.ceil(total / limit)
    });
    
  } catch (error) {
    logger.error('获取我的应用列表失败:', error);
    res.error('获取我的应用列表失败');
  }
});

/**
 * 获取应用统计信息
 */
router.get('/stats/overview', async (req, res) => {
  try {
    const stats = await query(`
      SELECT 
        COUNT(*) as total_apps,
        SUM(CASE WHEN status = 'active' THEN 1 ELSE 0 END) as active_apps,
        SUM(CASE WHEN status = 'inactive' THEN 1 ELSE 0 END) as inactive_apps,
        SUM(downloads) as total_downloads,
        COUNT(DISTINCT app_type) as app_types_count,
        COUNT(DISTINCT user_id) as developers_count
      FROM apps
    `);
    
    res.success(stats[0]);
    
  } catch (error) {
    logger.error('获取应用统计失败:', error);
    res.error('获取应用统计失败');
  }
});

module.exports = router;
