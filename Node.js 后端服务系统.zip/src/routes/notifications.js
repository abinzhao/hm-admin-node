const express = require('express');
const { query } = require('../database/connection');
const { authenticateToken, requireRole, optionalAuth } = require('../middleware/auth');
const { validatePagination, validateId } = require('../middleware/validation');
const logger = require('../utils/logger');

const router = express.Router();

/**
 * 获取系统通知列表
 */
router.get('/', optionalAuth, validatePagination, async (req, res) => {
  try {
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 10;
    const offset = (page - 1) * limit;
    const search = req.query.search || '';
    const type = req.query.type || '';
    
    // 构建查询条件
    let whereConditions = ['status = ?'];
    let queryParams = ['active'];
    
    if (search) {
      whereConditions.push('(title LIKE ? OR content LIKE ?)');
      queryParams.push(`%${search}%`, `%${search}%`);
    }
    
    if (type) {
      whereConditions.push('type = ?');
      queryParams.push(type);
    }
    
    const whereClause = `WHERE ${whereConditions.join(' AND ')}`;
    
    // 获取总数
    const countResult = await query(`
      SELECT COUNT(*) as total FROM notifications ${whereClause}
    `, queryParams);
    
    const total = countResult[0].total;
    
    // 获取通知列表
    const notifications = await query(`
      SELECT * FROM notifications ${whereClause}
      ORDER BY create_time DESC
      LIMIT ? OFFSET ?
    `, [...queryParams, limit, offset]);
    
    res.paginate(notifications, {
      page,
      limit,
      total,
      pages: Math.ceil(total / limit)
    });
    
  } catch (error) {
    logger.error('获取系统通知列表失败:', error);
    res.error('获取系统通知列表失败');
  }
});

/**
 * 获取通知详情
 */
router.get('/:id', optionalAuth, validateId, async (req, res) => {
  try {
    const notificationId = parseInt(req.params.id);
    
    const notifications = await query(
      'SELECT * FROM notifications WHERE id = ? AND status = ?',
      [notificationId, 'active']
    );
    
    if (notifications.length === 0) {
      return res.error('通知不存在', 404);
    }
    
    res.success(notifications[0]);
    
  } catch (error) {
    logger.error('获取通知详情失败:', error);
    res.error('获取通知详情失败');
  }
});

/**
 * 创建系统通知（管理员权限）
 */
router.post('/', authenticateToken, requireRole('admin'), async (req, res) => {
  try {
    const { title, content, type, publisher } = req.body;
    
    if (!title || title.trim().length === 0) {
      return res.error('通知标题不能为空', 400);
    }
    
    if (!content || content.trim().length === 0) {
      return res.error('通知内容不能为空', 400);
    }
    
    if (title.length > 255) {
      return res.error('通知标题不能超过255个字符', 400);
    }
    
    const validTypes = ['system', 'maintenance', 'feature', 'security'];
    if (type && !validTypes.includes(type)) {
      return res.error('通知类型无效', 400);
    }
    
    const result = await query(`
      INSERT INTO notifications (title, content, type, publisher)
      VALUES (?, ?, ?, ?)
    `, [
      title.trim(),
      content.trim(),
      type || 'system',
      publisher || '系统管理员'
    ]);
    
    logger.info('系统通知创建成功:', { notificationId: result.insertId, userId: req.user.id });
    
    res.success({
      id: result.insertId,
      title: title.trim(),
      type: type || 'system'
    }, '通知创建成功');
    
  } catch (error) {
    logger.error('创建系统通知失败:', error);
    res.error('创建通知失败');
  }
});

/**
 * 更新系统通知（管理员权限）
 */
router.put('/:id', authenticateToken, requireRole('admin'), validateId, async (req, res) => {
  try {
    const notificationId = parseInt(req.params.id);
    const { title, content, type, publisher, status } = req.body;
    
    // 检查通知是否存在
    const existingNotification = await query(
      'SELECT id FROM notifications WHERE id = ?',
      [notificationId]
    );
    
    if (existingNotification.length === 0) {
      return res.error('通知不存在', 404);
    }
    
    const updateFields = [];
    const updateValues = [];
    
    if (title !== undefined) {
      if (title.trim().length === 0) {
        return res.error('通知标题不能为空', 400);
      }
      if (title.length > 255) {
        return res.error('通知标题不能超过255个字符', 400);
      }
      updateFields.push('title = ?');
      updateValues.push(title.trim());
    }
    
    if (content !== undefined) {
      if (content.trim().length === 0) {
        return res.error('通知内容不能为空', 400);
      }
      updateFields.push('content = ?');
      updateValues.push(content.trim());
    }
    
    if (type !== undefined) {
      const validTypes = ['system', 'maintenance', 'feature', 'security'];
      if (!validTypes.includes(type)) {
        return res.error('通知类型无效', 400);
      }
      updateFields.push('type = ?');
      updateValues.push(type);
    }
    
    if (publisher !== undefined) {
      updateFields.push('publisher = ?');
      updateValues.push(publisher);
    }
    
    if (status !== undefined) {
      if (!['active', 'inactive'].includes(status)) {
        return res.error('状态值无效', 400);
      }
      updateFields.push('status = ?');
      updateValues.push(status);
    }
    
    if (updateFields.length === 0) {
      return res.error('没有要更新的字段', 400);
    }
    
    updateValues.push(notificationId);
    
    await query(`
      UPDATE notifications SET ${updateFields.join(', ')} WHERE id = ?
    `, updateValues);
    
    logger.info('系统通知更新成功:', { notificationId, userId: req.user.id });
    
    res.success(null, '通知更新成功');
    
  } catch (error) {
    logger.error('更新系统通知失败:', error);
    res.error('更新通知失败');
  }
});

/**
 * 删除系统通知（管理员权限）
 */
router.delete('/:id', authenticateToken, requireRole('admin'), validateId, async (req, res) => {
  try {
    const notificationId = parseInt(req.params.id);
    
    const result = await query('DELETE FROM notifications WHERE id = ?', [notificationId]);
    
    if (result.affectedRows === 0) {
      return res.error('通知不存在', 404);
    }
    
    logger.info('系统通知删除成功:', { notificationId, userId: req.user.id });
    
    res.success(null, '通知删除成功');
    
  } catch (error) {
    logger.error('删除系统通知失败:', error);
    res.error('删除通知失败');
  }
});

/**
 * 获取最新通知
 */
router.get('/latest/list', async (req, res) => {
  try {
    const limit = parseInt(req.query.limit) || 5;
    
    const notifications = await query(`
      SELECT id, title, content, type, publisher, create_time
      FROM notifications 
      WHERE status = 'active'
      ORDER BY create_time DESC
      LIMIT ?
    `, [limit]);
    
    res.success(notifications);
    
  } catch (error) {
    logger.error('获取最新通知失败:', error);
    res.error('获取最新通知失败');
  }
});

/**
 * 批量更新通知状态（管理员权限）
 */
router.put('/batch/status', authenticateToken, requireRole('admin'), async (req, res) => {
  try {
    const { ids, status } = req.body;
    
    if (!Array.isArray(ids) || ids.length === 0) {
      return res.error('通知ID列表不能为空', 400);
    }
    
    if (!['active', 'inactive'].includes(status)) {
      return res.error('状态值无效', 400);
    }
    
    const placeholders = ids.map(() => '?').join(',');
    const result = await query(`
      UPDATE notifications SET status = ? 
      WHERE id IN (${placeholders})
    `, [status, ...ids]);
    
    logger.info('批量更新通知状态成功:', { 
      ids, 
      status, 
      affectedRows: result.affectedRows, 
      userId: req.user.id 
    });
    
    res.success({
      updated: result.affectedRows
    }, `成功更新 ${result.affectedRows} 个通知状态`);
    
  } catch (error) {
    logger.error('批量更新通知状态失败:', error);
    res.error('批量操作失败');
  }
});

/**
 * 获取通知统计信息（管理员权限）
 */
router.get('/stats/overview', authenticateToken, requireRole('admin'), async (req, res) => {
  try {
    const stats = await query(`
      SELECT 
        COUNT(*) as total_notifications,
        SUM(CASE WHEN status = 'active' THEN 1 ELSE 0 END) as active_count,
        SUM(CASE WHEN status = 'inactive' THEN 1 ELSE 0 END) as inactive_count,
        SUM(CASE WHEN type = 'system' THEN 1 ELSE 0 END) as system_count,
        SUM(CASE WHEN type = 'maintenance' THEN 1 ELSE 0 END) as maintenance_count,
        SUM(CASE WHEN type = 'feature' THEN 1 ELSE 0 END) as feature_count,
        SUM(CASE WHEN type = 'security' THEN 1 ELSE 0 END) as security_count,
        SUM(CASE WHEN DATE(create_time) = CURDATE() THEN 1 ELSE 0 END) as today_count
      FROM notifications
    `);
    
    res.success(stats[0]);
    
  } catch (error) {
    logger.error('获取通知统计失败:', error);
    res.error('获取通知统计失败');
  }
});

module.exports = router;
