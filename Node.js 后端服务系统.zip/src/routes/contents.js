const express = require('express');
const { query } = require('../database/connection');
const { authenticateToken, optionalAuth } = require('../middleware/auth');
const { validateContentCreation, validatePagination, validateId } = require('../middleware/validation');
const logger = require('../utils/logger');

const router = express.Router();

/**
 * 获取内容列表
 */
router.get('/', optionalAuth, validatePagination, async (req, res) => {
  try {
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 10;
    const offset = (page - 1) * limit;
    const search = req.query.search || '';
    const contentType = req.query.content_type || '';
    const userId = req.query.user_id || '';
    const tags = req.query.tags || '';
    
    // 构建查询条件
    let whereConditions = ['c.status = ?'];
    let queryParams = ['published'];
    
    if (search) {
      whereConditions.push('(c.title LIKE ? OR c.description LIKE ? OR c.content LIKE ?)');
      queryParams.push(`%${search}%`, `%${search}%`, `%${search}%`);
    }
    
    if (contentType) {
      whereConditions.push('c.content_type = ?');
      queryParams.push(contentType);
    }
    
    if (userId) {
      whereConditions.push('c.user_id = ?');
      queryParams.push(userId);
    }
    
    if (tags) {
      whereConditions.push('JSON_CONTAINS(c.tags, ?)');
      queryParams.push(`"${tags}"`);
    }
    
    const whereClause = `WHERE ${whereConditions.join(' AND ')}`;
    
    // 获取总数
    const countResult = await query(`
      SELECT COUNT(*) as total 
      FROM contents c 
      LEFT JOIN users u ON c.user_id = u.id 
      ${whereClause}
    `, queryParams);
    
    const total = countResult[0].total;
    
    // 获取内容列表
    const contents = await query(`
      SELECT c.*, u.username, u.nickname, u.avatar
      FROM contents c
      LEFT JOIN users u ON c.user_id = u.id
      ${whereClause}
      ORDER BY c.create_time DESC
      LIMIT ? OFFSET ?
    `, [...queryParams, limit, offset]);
    
    // 处理JSON字段
    contents.forEach(content => {
      content.tags = content.tags ? JSON.parse(content.tags) : [];
      content.cover_image = content.cover_image ? JSON.parse(content.cover_image) : [];
    });
    
    res.paginate(contents, {
      page,
      limit,
      total,
      pages: Math.ceil(total / limit)
    });
    
  } catch (error) {
    logger.error('获取内容列表失败:', error);
    res.error('获取内容列表失败');
  }
});

/**
 * 获取内容详情
 */
router.get('/:id', optionalAuth, validateId, async (req, res) => {
  try {
    const contentId = parseInt(req.params.id);
    
    const contents = await query(`
      SELECT c.*, u.username, u.nickname, u.avatar
      FROM contents c
      LEFT JOIN users u ON c.user_id = u.id
      WHERE c.id = ? AND c.status = ?
    `, [contentId, 'published']);
    
    if (contents.length === 0) {
      return res.error('内容不存在', 404);
    }
    
    const content = contents[0];
    content.tags = content.tags ? JSON.parse(content.tags) : [];
    content.cover_image = content.cover_image ? JSON.parse(content.cover_image) : [];
    
    // 增加浏览量
    await query('UPDATE contents SET view_count = view_count + 1 WHERE id = ?', [contentId]);
    content.view_count += 1;
    
    res.success(content);
    
  } catch (error) {
    logger.error('获取内容详情失败:', error);
    res.error('获取内容详情失败');
  }
});

/**
 * 创建内容
 */
router.post('/', authenticateToken, validateContentCreation, async (req, res) => {
  try {
    const { title, description, content_type, tags, cover_image, content, status } = req.body;
    
    const result = await query(`
      INSERT INTO contents (user_id, title, description, content_type, tags, cover_image, content, status)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `, [
      req.user.id,
      title,
      description,
      content_type,
      JSON.stringify(tags || []),
      JSON.stringify(cover_image || []),
      content,
      status || 'published'
    ]);
    
    logger.info('内容创建成功:', { contentId: result.insertId, userId: req.user.id });
    
    res.success({
      id: result.insertId,
      title,
      content_type
    }, '内容创建成功');
    
  } catch (error) {
    logger.error('创建内容失败:', error);
    res.error('创建内容失败');
  }
});

/**
 * 更新内容
 */
router.put('/:id', authenticateToken, validateId, async (req, res) => {
  try {
    const contentId = parseInt(req.params.id);
    const { title, description, content_type, tags, cover_image, content, status } = req.body;
    
    // 检查内容是否存在且属于当前用户
    const existingContent = await query(
      'SELECT user_id FROM contents WHERE id = ?',
      [contentId]
    );
    
    if (existingContent.length === 0) {
      return res.error('内容不存在', 404);
    }
    
    if (existingContent[0].user_id !== req.user.id && req.user.role !== 'admin') {
      return res.error('权限不足', 403);
    }
    
    const updateFields = [];
    const updateValues = [];
    
    if (title !== undefined) {
      updateFields.push('title = ?');
      updateValues.push(title);
    }
    
    if (description !== undefined) {
      updateFields.push('description = ?');
      updateValues.push(description);
    }
    
    if (content_type !== undefined) {
      updateFields.push('content_type = ?');
      updateValues.push(content_type);
    }
    
    if (tags !== undefined) {
      updateFields.push('tags = ?');
      updateValues.push(JSON.stringify(tags));
    }
    
    if (cover_image !== undefined) {
      updateFields.push('cover_image = ?');
      updateValues.push(JSON.stringify(cover_image));
    }
    
    if (content !== undefined) {
      updateFields.push('content = ?');
      updateValues.push(content);
    }
    
    if (status !== undefined) {
      updateFields.push('status = ?');
      updateValues.push(status);
    }
    
    if (updateFields.length === 0) {
      return res.error('没有要更新的字段', 400);
    }
    
    updateValues.push(contentId);
    
    await query(`
      UPDATE contents SET ${updateFields.join(', ')} WHERE id = ?
    `, updateValues);
    
    logger.info('内容更新成功:', { contentId, userId: req.user.id });
    
    res.success(null, '内容更新成功');
    
  } catch (error) {
    logger.error('更新内容失败:', error);
    res.error('更新内容失败');
  }
});

/**
 * 删除内容
 */
router.delete('/:id', authenticateToken, validateId, async (req, res) => {
  try {
    const contentId = parseInt(req.params.id);
    
    // 检查内容是否存在且属于当前用户
    const existingContent = await query(
      'SELECT user_id FROM contents WHERE id = ?',
      [contentId]
    );
    
    if (existingContent.length === 0) {
      return res.error('内容不存在', 404);
    }
    
    if (existingContent[0].user_id !== req.user.id && req.user.role !== 'admin') {
      return res.error('权限不足', 403);
    }
    
    await query('DELETE FROM contents WHERE id = ?', [contentId]);
    
    logger.info('内容删除成功:', { contentId, userId: req.user.id });
    
    res.success(null, '内容删除成功');
    
  } catch (error) {
    logger.error('删除内容失败:', error);
    res.error('删除内容失败');
  }
});

/**
 * 获取我的内容列表
 */
router.get('/my/list', authenticateToken, validatePagination, async (req, res) => {
  try {
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 10;
    const offset = (page - 1) * limit;
    const search = req.query.search || '';
    const contentType = req.query.content_type || '';
    const status = req.query.status || '';
    
    // 构建查询条件
    let whereConditions = ['user_id = ?'];
    let queryParams = [req.user.id];
    
    if (search) {
      whereConditions.push('(title LIKE ? OR description LIKE ?)');
      queryParams.push(`%${search}%`, `%${search}%`);
    }
    
    if (contentType) {
      whereConditions.push('content_type = ?');
      queryParams.push(contentType);
    }
    
    if (status) {
      whereConditions.push('status = ?');
      queryParams.push(status);
    }
    
    const whereClause = `WHERE ${whereConditions.join(' AND ')}`;
    
    // 获取总数
    const countResult = await query(`
      SELECT COUNT(*) as total FROM contents ${whereClause}
    `, queryParams);
    
    const total = countResult[0].total;
    
    // 获取内容列表
    const contents = await query(`
      SELECT * FROM contents ${whereClause}
      ORDER BY create_time DESC
      LIMIT ? OFFSET ?
    `, [...queryParams, limit, offset]);
    
    // 处理JSON字段
    contents.forEach(content => {
      content.tags = content.tags ? JSON.parse(content.tags) : [];
      content.cover_image = content.cover_image ? JSON.parse(content.cover_image) : [];
    });
    
    res.paginate(contents, {
      page,
      limit,
      total,
      pages: Math.ceil(total / limit)
    });
    
  } catch (error) {
    logger.error('获取我的内容列表失败:', error);
    res.error('获取我的内容列表失败');
  }
});

/**
 * 获取内容统计信息
 */
router.get('/stats/overview', async (req, res) => {
  try {
    const stats = await query(`
      SELECT 
        COUNT(*) as total_contents,
        SUM(CASE WHEN content_type = 'article' THEN 1 ELSE 0 END) as article_count,
        SUM(CASE WHEN content_type = 'question' THEN 1 ELSE 0 END) as question_count,
        SUM(CASE WHEN content_type = 'snippet' THEN 1 ELSE 0 END) as snippet_count,
        SUM(CASE WHEN status = 'published' THEN 1 ELSE 0 END) as published_count,
        SUM(CASE WHEN status = 'draft' THEN 1 ELSE 0 END) as draft_count,
        SUM(view_count) as total_views,
        SUM(like_count) as total_likes
      FROM contents
    `);
    
    res.success(stats[0]);
    
  } catch (error) {
    logger.error('获取内容统计失败:', error);
    res.error('获取内容统计失败');
  }
});

module.exports = router;
