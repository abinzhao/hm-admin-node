const { connectDatabase, initializeTables } = require('./connection');
const logger = require('../utils/logger');

async function migrate() {
  try {
    logger.info('开始数据库迁移...');
    
    // 连接数据库
    await connectDatabase();
    logger.info('数据库连接成功');
    
    // 初始化表结构
    await initializeTables();
    logger.info('数据库迁移完成');
    
    process.exit(0);
  } catch (error) {
    logger.error('数据库迁移失败:', error);
    process.exit(1);
  }
}

// 如果直接运行此文件，执行迁移
if (require.main === module) {
  migrate();
}

module.exports = migrate;
