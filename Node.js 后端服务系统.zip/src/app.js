const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const compression = require('compression');
const rateLimit = require('express-rate-limit');
const fileUpload = require('express-fileupload');
require('dotenv').config();

const logger = require('./utils/logger');
const { connectDatabase, initializeTables } = require('./database/connection');
const { checkPort } = require('./utils/portChecker');
const tcpServer = require('./services/tcpServer');
const errorHandler = require('./middleware/errorHandler');
const responseFormatter = require('./middleware/responseFormatter');

// 路由导入
const authRoutes = require('./routes/auth');
const userRoutes = require('./routes/users');
const contentRoutes = require('./routes/contents');
const appRoutes = require('./routes/apps');
const todoRoutes = require('./routes/todos');
const messageRoutes = require('./routes/messages');
const notificationRoutes = require('./routes/notifications');
const dashboardRoutes = require('./routes/dashboard');
const uploadRoutes = require('./routes/upload');

const app = express();
const PORT = process.env.PORT || 3000;
const TCP_PORT = process.env.TCP_PORT || 8888;

// 安全中间件
app.use(helmet());
app.use(cors({
  origin: process.env.NODE_ENV === 'production' ? ['https://yourdomain.com'] : true,
  credentials: true
}));

// 请求限制
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15分钟
  max: 100, // 限制每个IP 15分钟内最多100个请求
  message: {
    code: 429,
    message: '请求过于频繁，请稍后再试'
  }
});
app.use('/api/', limiter);

// 基础中间件
app.use(compression());
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));
app.use(fileUpload({
  limits: { fileSize: parseInt(process.env.MAX_FILE_SIZE) || 10 * 1024 * 1024 },
  abortOnLimit: true
}));

// 响应格式化中间件
app.use(responseFormatter);

// 静态文件服务
app.use('/uploads', express.static('uploads'));

// 健康检查
app.get('/health', (req, res) => {
  res.success({
    status: 'OK',
    timestamp: new Date().toISOString(),
    uptime: process.uptime()
  });
});

// API路由
app.use('/api/auth', authRoutes);
app.use('/api/users', userRoutes);
app.use('/api/contents', contentRoutes);
app.use('/api/apps', appRoutes);
app.use('/api/todos', todoRoutes);
app.use('/api/messages', messageRoutes);
app.use('/api/notifications', notificationRoutes);
app.use('/api/dashboard', dashboardRoutes);
app.use('/api/upload', uploadRoutes);

// 404处理
app.use('*', (req, res) => {
  res.error('接口不存在', 404);
});

// 错误处理中间件
app.use(errorHandler);

// 优雅关闭处理
process.on('SIGTERM', gracefulShutdown);
process.on('SIGINT', gracefulShutdown);

function gracefulShutdown(signal) {
  logger.info(`收到 ${signal} 信号，开始优雅关闭...`);
  
  // 关闭HTTP服务器
  server.close(() => {
    logger.info('HTTP服务器已关闭');
    
    // 关闭TCP服务器
    tcpServer.close(() => {
      logger.info('TCP服务器已关闭');
      process.exit(0);
    });
  });
  
  // 强制退出超时
  setTimeout(() => {
    logger.error('强制退出');
    process.exit(1);
  }, 10000);
}

// 启动服务器
async function startServer() {
  try {
    // 检查端口占用
    const isPortAvailable = await checkPort(PORT);
    if (!isPortAvailable) {
      throw new Error(`端口 ${PORT} 已被占用`);
    }
    
    const isTcpPortAvailable = await checkPort(TCP_PORT);
    if (!isTcpPortAvailable) {
      throw new Error(`TCP端口 ${TCP_PORT} 已被占用`);
    }
    
    // 连接数据库
    await connectDatabase();
    logger.info('数据库连接成功');
    
    // 初始化数据表
    await initializeTables();
    logger.info('数据表初始化完成');
    
    // 启动HTTP服务器
    const server = app.listen(PORT, () => {
      logger.info(`HTTP服务器启动成功，端口: ${PORT}`);
      logger.info(`环境: ${process.env.NODE_ENV}`);
    });
    
    // 启动TCP服务器
    tcpServer.start(TCP_PORT);
    logger.info(`TCP服务器启动成功，端口: ${TCP_PORT}`);
    
    return server;
    
  } catch (error) {
    logger.error('服务器启动失败:', error);
    process.exit(1);
  }
}

// 启动应用
const server = startServer();

module.exports = app;
