const mysql = require('mysql2/promise');
const logger = require('../utils/logger');

let pool = null;

// 创建数据库连接池
async function connectDatabase() {
  try {
    pool = mysql.createPool({
      host: process.env.DB_HOST || 'localhost',
      port: process.env.DB_PORT || 3306,
      user: process.env.DB_USER || 'root',
      password: process.env.DB_PASSWORD || '',
      database: process.env.DB_NAME || 'nodejs_system',
      waitForConnections: true,
      connectionLimit: 10,
      queueLimit: 0,
      acquireTimeout: 60000,
      timeout: 60000,
      reconnect: true,
      charset: 'utf8mb4'
    });
    
    // 测试连接
    const connection = await pool.getConnection();
    await connection.ping();
    connection.release();
    
    logger.info('数据库连接池创建成功');
    return pool;
  } catch (error) {
    logger.error('数据库连接失败:', error);
    throw error;
  }
}

// 获取数据库连接
function getConnection() {
  if (!pool) {
    throw new Error('数据库连接池未初始化');
  }
  return pool;
}

// 执行查询
async function query(sql, params = []) {
  try {
    const connection = getConnection();
    const [rows] = await connection.execute(sql, params);
    return rows;
  } catch (error) {
    logger.error('数据库查询错误:', { sql, params, error: error.message });
    throw error;
  }
}

// 执行事务
async function transaction(callback) {
  const connection = await pool.getConnection();
  await connection.beginTransaction();
  
  try {
    const result = await callback(connection);
    await connection.commit();
    return result;
  } catch (error) {
    await connection.rollback();
    throw error;
  } finally {
    connection.release();
  }
}

// 初始化数据表
async function initializeTables() {
  const tables = [
    // 用户表
    `CREATE TABLE IF NOT EXISTS users (
      id INT AUTO_INCREMENT PRIMARY KEY,
      user_id VARCHAR(50) UNIQUE NOT NULL,
      username VARCHAR(50) UNIQUE NOT NULL,
      nickname VARCHAR(100),
      password VARCHAR(255) NOT NULL,
      role ENUM('admin', 'user') DEFAULT 'user',
      phone VARCHAR(20),
      email VARCHAR(100),
      tags JSON,
      description TEXT,
      open_id VARCHAR(100),
      avatar TEXT,
      status ENUM('active', 'inactive') DEFAULT 'active',
      last_login_time DATETIME,
      create_time DATETIME DEFAULT CURRENT_TIMESTAMP,
      update_time DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      INDEX idx_user_id (user_id),
      INDEX idx_username (username),
      INDEX idx_email (email)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
    
    // 内容表
    `CREATE TABLE IF NOT EXISTS contents (
      id INT AUTO_INCREMENT PRIMARY KEY,
      user_id INT NOT NULL,
      title VARCHAR(255) NOT NULL,
      description TEXT,
      content_type ENUM('article', 'question', 'snippet') NOT NULL,
      tags JSON,
      cover_image JSON,
      content LONGTEXT,
      status ENUM('draft', 'published', 'archived') DEFAULT 'published',
      view_count INT DEFAULT 0,
      like_count INT DEFAULT 0,
      create_time DATETIME DEFAULT CURRENT_TIMESTAMP,
      update_time DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
      INDEX idx_user_id (user_id),
      INDEX idx_content_type (content_type),
      INDEX idx_status (status),
      FULLTEXT idx_title_content (title, content)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
    
    // 应用包表
    `CREATE TABLE IF NOT EXISTS apps (
      id INT AUTO_INCREMENT PRIMARY KEY,
      user_id INT NOT NULL,
      package_name VARCHAR(255) NOT NULL,
      app_name VARCHAR(100) NOT NULL,
      description TEXT,
      app_logo TEXT,
      app_dev_type VARCHAR(50),
      update_info TEXT,
      app_version VARCHAR(20),
      app_size VARCHAR(20),
      downloads INT DEFAULT 0,
      app_url TEXT,
      app_type VARCHAR(50),
      app_screenshot JSON,
      status ENUM('active', 'inactive') DEFAULT 'active',
      create_time DATETIME DEFAULT CURRENT_TIMESTAMP,
      update_time DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
      INDEX idx_user_id (user_id),
      INDEX idx_package_name (package_name),
      INDEX idx_app_type (app_type)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
    
    // 待办事项表
    `CREATE TABLE IF NOT EXISTS todos (
      id INT AUTO_INCREMENT PRIMARY KEY,
      user_id INT NOT NULL,
      title VARCHAR(255) NOT NULL,
      description TEXT,
      status ENUM('pending', 'processing', 'completed', 'cancelled') DEFAULT 'pending',
      priority ENUM('low', 'medium', 'high', 'urgent') DEFAULT 'medium',
      due_date DATE,
      completed_time DATETIME,
      create_time DATETIME DEFAULT CURRENT_TIMESTAMP,
      update_time DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
      INDEX idx_user_id (user_id),
      INDEX idx_status (status),
      INDEX idx_priority (priority),
      INDEX idx_due_date (due_date)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
    
    // 留言表
    `CREATE TABLE IF NOT EXISTS messages (
      id INT AUTO_INCREMENT PRIMARY KEY,
      user_id INT NOT NULL,
      content TEXT NOT NULL,
      content_type ENUM('message', 'feedback', 'suggestion') DEFAULT 'message',
      status ENUM('unread', 'read', 'replied') DEFAULT 'unread',
      reply_content TEXT,
      reply_time DATETIME,
      create_time DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
      INDEX idx_user_id (user_id),
      INDEX idx_status (status),
      INDEX idx_content_type (content_type)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
    
    // 系统通知表
    `CREATE TABLE IF NOT EXISTS notifications (
      id INT AUTO_INCREMENT PRIMARY KEY,
      title VARCHAR(255) NOT NULL,
      content TEXT NOT NULL,
      publisher VARCHAR(100) DEFAULT '系统管理员',
      type ENUM('system', 'maintenance', 'feature', 'security') DEFAULT 'system',
      status ENUM('active', 'inactive') DEFAULT 'active',
      create_time DATETIME DEFAULT CURRENT_TIMESTAMP,
      update_time DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      INDEX idx_type (type),
      INDEX idx_status (status)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`
  ];
  
  try {
    for (const table of tables) {
      await query(table);
    }
    
    // 插入默认管理员用户
    await insertDefaultAdmin();
    
    // 插入示例数据
    await insertSampleData();
    
    logger.info('数据表初始化完成');
  } catch (error) {
    logger.error('数据表初始化失败:', error);
    throw error;
  }
}

// 插入默认管理员用户
async function insertDefaultAdmin() {
  const bcrypt = require('bcryptjs');
  
  try {
    const existingAdmin = await query('SELECT id FROM users WHERE username = ?', ['admin']);
    if (existingAdmin.length === 0) {
      const hashedPassword = await bcrypt.hash('admin123', 10);
      await query(`
        INSERT INTO users (user_id, username, nickname, password, role, email, tags, description, avatar)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `, [
        'user_001',
        'admin',
        '系统管理员',
        hashedPassword,
        'admin',
        'admin@163.com',
        JSON.stringify(['社区贡献者', '技术专家', '管理员']),
        '这是一个测试用户',
        'https://q9.itc.cn/q_70/images03/20241013/d770472d4906402c866b9c71a0c9927c.jpeg'
      ]);
      logger.info('默认管理员用户创建成功');
    }
  } catch (error) {
    logger.error('创建默认管理员失败:', error);
  }
}

// 插入示例数据
async function insertSampleData() {
  try {
    // 检查是否已有数据
    const contentCount = await query('SELECT COUNT(*) as count FROM contents');
    if (contentCount[0].count === 0) {
      // 插入示例内容
      const sampleContents = [
        {
          user_id: 1,
          title: '文章1文章1文章1文章1文章1文章1文章1文章1文章1文章1',
          description: '内容1内容1内容1内容1内容1内容1内容1',
          content_type: 'article',
          tags: JSON.stringify(['前端', 'ArkUI']),
          cover_image: JSON.stringify([{ url: 'https://q9.itc.cn/q_70/images03/20241013/d770472d4906402c866b9c71a0c9927c.jpeg' }]),
          content: '这是文章内容这是文章内容这是文章内容这是文章内容这是文章内容这是文章内容'
        },
        {
          user_id: 1,
          title: '问题1问题1问题1问题1问题1问题1问题1问题1问题1问题1',
          description: '问题描述问题描述问题描述问题描述问题描述',
          content_type: 'question',
          tags: JSON.stringify(['前端', 'ArkUI']),
          cover_image: JSON.stringify([{ url: 'https://q9.itc.cn/q_70/images03/20241013/d770472d4906402c866b9c71a0c9927c.jpeg' }]),
          content: '这是问题内容这是问题内容这是问题内容这是问题内容这是问题内容这是问题内容'
        }
      ];
      
      for (const content of sampleContents) {
        await query(`
          INSERT INTO contents (user_id, title, description, content_type, tags, cover_image, content)
          VALUES (?, ?, ?, ?, ?, ?, ?)
        `, [content.user_id, content.title, content.description, content.content_type, content.tags, content.cover_image, content.content]);
      }
      
      // 插入示例应用
      await query(`
        INSERT INTO apps (user_id, package_name, app_name, description, app_logo, app_dev_type, update_info, app_version, app_size, downloads, app_url, app_type, app_screenshot)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `, [
        1,
        'package.hmApp.weChat.weChat.weChat',
        '微信',
        '这是一个微信应用的包这是一个微信应用的包这是一个微信应用的包这是一个微信应用的包这是一个微信应用的包',
        'https://q9.itc.cn/q_70/images03/20241013/d770472d4906402c866b9c71a0c9927c.jpeg',
        '原始应用',
        '修复了一些bug，优化了性能',
        '1.0.0',
        '150MB',
        10000,
        'https://example.com/wechat.hap',
        '社交',
        JSON.stringify([
          'https://q9.itc.cn/q_70/images03/20241013/d770472d4906402c866b9c71a0c9927c.jpeg',
          'https://q9.itc.cn/q_70/images03/20241013/d770472d4906402c866b9c71a0c9927c.jpeg',
          'https://q9.itc.cn/q_70/images03/20241013/d770472d4906402c866b9c71a0c9927c.jpeg'
        ])
      ]);
      
      // 插入示例待办事项
      const sampleTodos = [
        {
          user_id: 1,
          title: '完成项目设计',
          description: '完成React待办事项应用的设计稿',
          status: 'pending',
          priority: 'high',
          due_date: '2025-06-01'
        },
        {
          user_id: 1,
          title: '编写API文档',
          description: '为后端API编写详细的接口文档',
          status: 'processing',
          priority: 'medium',
          due_date: '2025-06-05'
        }
      ];
      
      for (const todo of sampleTodos) {
        await query(`
          INSERT INTO todos (user_id, title, description, status, priority, due_date)
          VALUES (?, ?, ?, ?, ?, ?)
        `, [todo.user_id, todo.title, todo.description, todo.status, todo.priority, todo.due_date]);
      }
      
      // 插入示例留言
      await query(`
        INSERT INTO messages (user_id, content, content_type)
        VALUES (?, ?, ?)
      `, [1, '太牛逼了', 'message']);
      
      // 插入示例通知
      const sampleNotifications = [
        {
          title: '系统维护通知',
          content: '计划于2025-06-01 00:00至03:00进行系统升级,\n请提前做好备份,避免数据丢失,感谢您的理解与支持。',
          type: 'maintenance'
        },
        {
          title: '新功能上线',
          content: '## 系统升级\n- 修复bug\n- 优化首页数据大屏',
          type: 'feature'
        }
      ];
      
      for (const notification of sampleNotifications) {
        await query(`
          INSERT INTO notifications (title, content, type)
          VALUES (?, ?, ?)
        `, [notification.title, notification.content, notification.type]);
      }
      
      logger.info('示例数据插入完成');
    }
  } catch (error) {
    logger.error('插入示例数据失败:', error);
  }
}

module.exports = {
  connectDatabase,
  getConnection,
  query,
  transaction,
  initializeTables
};
