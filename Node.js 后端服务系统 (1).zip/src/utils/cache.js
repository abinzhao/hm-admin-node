const NodeCache = require('node-cache');
const logger = require('./logger');

class CacheManager {
  constructor() {
    // 默认缓存实例
    this.defaultCache = new NodeCache({
      stdTTL: parseInt(process.env.CACHE_TTL) || 3600, // 默认1小时
      checkperiod: 600, // 每10分钟检查过期
      useClones: false
    });
    
    // 短期缓存（5分钟）
    this.shortCache = new NodeCache({
      stdTTL: 300,
      checkperiod: 60,
      useClones: false
    });
    
    // 长期缓存（24小时）
    this.longCache = new NodeCache({
      stdTTL: 86400,
      checkperiod: 3600,
      useClones: false
    });
    
    this.setupEventListeners();
  }
  
  setupEventListeners() {
    // 监听缓存事件
    this.defaultCache.on('set', (key, value) => {
      logger.debug(`缓存设置: ${key}`);
    });
    
    this.defaultCache.on('del', (key, value) => {
      logger.debug(`缓存删除: ${key}`);
    });
    
    this.defaultCache.on('expired', (key, value) => {
      logger.debug(`缓存过期: ${key}`);
    });
  }
  
  // 获取缓存
  get(key, cacheType = 'default') {
    try {
      const cache = this.getCache(cacheType);
      return cache.get(key);
    } catch (error) {
      logger.error('获取缓存失败:', { key, error: error.message });
      return undefined;
    }
  }
  
  // 设置缓存
  set(key, value, ttl = null, cacheType = 'default') {
    try {
      const cache = this.getCache(cacheType);
      return cache.set(key, value, ttl);
    } catch (error) {
      logger.error('设置缓存失败:', { key, error: error.message });
      return false;
    }
  }
  
  // 删除缓存
  del(key, cacheType = 'default') {
    try {
      const cache = this.getCache(cacheType);
      return cache.del(key);
    } catch (error) {
      logger.error('删除缓存失败:', { key, error: error.message });
      return 0;
    }
  }
  
  // 检查缓存是否存在
  has(key, cacheType = 'default') {
    try {
      const cache = this.getCache(cacheType);
      return cache.has(key);
    } catch (error) {
      logger.error('检查缓存失败:', { key, error: error.message });
      return false;
    }
  }
  
  // 获取所有键
  keys(cacheType = 'default') {
    try {
      const cache = this.getCache(cacheType);
      return cache.keys();
    } catch (error) {
      logger.error('获取缓存键失败:', { error: error.message });
      return [];
    }
  }
  
  // 清空缓存
  flush(cacheType = 'default') {
    try {
      const cache = this.getCache(cacheType);
      cache.flushAll();
      logger.info(`缓存清空: ${cacheType}`);
      return true;
    } catch (error) {
      logger.error('清空缓存失败:', { cacheType, error: error.message });
      return false;
    }
  }
  
  // 获取缓存统计
  getStats(cacheType = 'default') {
    try {
      const cache = this.getCache(cacheType);
      return cache.getStats();
    } catch (error) {
      logger.error('获取缓存统计失败:', { cacheType, error: error.message });
      return null;
    }
  }
  
  // 获取指定类型的缓存实例
  getCache(cacheType) {
    switch (cacheType) {
      case 'short':
        return this.shortCache;
      case 'long':
        return this.longCache;
      case 'default':
      default:
        return this.defaultCache;
    }
  }
  
  // 缓存装饰器
  cached(key, fn, ttl = null, cacheType = 'default') {
    return async (...args) => {
      const cacheKey = typeof key === 'function' ? key(...args) : key;
      
      // 尝试从缓存获取
      let result = this.get(cacheKey, cacheType);
      if (result !== undefined) {
        logger.debug(`缓存命中: ${cacheKey}`);
        return result;
      }
      
      // 执行函数并缓存结果
      try {
        result = await fn(...args);
        this.set(cacheKey, result, ttl, cacheType);
        logger.debug(`缓存设置: ${cacheKey}`);
        return result;
      } catch (error) {
        logger.error('缓存装饰器执行失败:', { key: cacheKey, error: error.message });
        throw error;
      }
    };
  }
  
  // 批量操作
  mget(keys, cacheType = 'default') {
    try {
      const cache = this.getCache(cacheType);
      return cache.mget(keys);
    } catch (error) {
      logger.error('批量获取缓存失败:', { keys, error: error.message });
      return {};
    }
  }
  
  mset(keyValuePairs, ttl = null, cacheType = 'default') {
    try {
      const cache = this.getCache(cacheType);
      return cache.mset(keyValuePairs, ttl);
    } catch (error) {
      logger.error('批量设置缓存失败:', { error: error.message });
      return false;
    }
  }
  
  // 获取所有缓存统计
  getAllStats() {
    return {
      default: this.getStats('default'),
      short: this.getStats('short'),
      long: this.getStats('long')
    };
  }
  
  // 清空所有缓存
  flushAll() {
    this.flush('default');
    this.flush('short');
    this.flush('long');
    logger.info('所有缓存已清空');
  }
}

module.exports = new CacheManager();
