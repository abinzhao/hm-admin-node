const net = require('net');

/**
 * 检查端口是否可用
 * @param {number} port 端口号
 * @returns {Promise<boolean>} 端口是否可用
 */
function checkPort(port) {
  return new Promise((resolve) => {
    const server = net.createServer();
    
    server.listen(port, () => {
      server.once('close', () => {
        resolve(true);
      });
      server.close();
    });
    
    server.on('error', () => {
      resolve(false);
    });
  });
}

module.exports = {
  checkPort
};
