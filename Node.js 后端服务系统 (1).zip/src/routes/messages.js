const express = require('express');
const { query } = require('../database/connection');
const { authenticateToken, requireRole } = require('../middleware/auth');
const { validatePagination, validateId } = require('../middleware/validation');
const logger = require('../utils/logger');

const router = express.Router();

/**
 * 获取留言列表（管理员权限）
 */
router.get('/', authenticateToken, requireRole('admin'), validatePagination, async (req, res) => {
  try {
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 10;
    const offset = (page - 1) * limit;
    const search = req.query.search || '';
    const contentType = req.query.content_type || '';
    const status = req.query.status || '';
    
    // 构建查询条件
    let whereConditions = [];
    let queryParams = [];
    
    if (search) {
      whereConditions.push('(m.content LIKE ? OR u.username LIKE ? OR u.nickname LIKE ?)');
      queryParams.push(`%${search}%`, `%${search}%`, `%${search}%`);
    }
    
    if (contentType) {
      whereConditions.push('m.content_type = ?');
      queryParams.push(contentType);
    }
    
    if (status) {
      whereConditions.push('m.status = ?');
      queryParams.push(status);
    }
    
    const whereClause = whereConditions.length > 0 ? `WHERE ${whereConditions.join(' AND ')}` : '';
    
    // 获取总数
    const countResult = await query(`
      SELECT COUNT(*) as total 
      FROM messages m 
      LEFT JOIN users u ON m.user_id = u.id 
      ${whereClause}
    `, queryParams);
    
    const total = countResult[0].total;
    
    // 获取留言列表
    const messages = await query(`
      SELECT m.*, u.username, u.nickname, u.avatar
      FROM messages m
      LEFT JOIN users u ON m.user_id = u.id
      ${whereClause}
      ORDER BY m.create_time DESC
      LIMIT ? OFFSET ?
    `, [...queryParams, limit, offset]);
    
    res.paginate(messages, {
      page,
      limit,
      total,
      pages: Math.ceil(total / limit)
    });
    
  } catch (error) {
    logger.error('获取留言列表失败:', error);
    res.error('获取留言列表失败');
  }
});

/**
 * 获取留言详情
 */
router.get('/:id', authenticateToken, validateId, async (req, res) => {
  try {
    const messageId = parseInt(req.params.id);
    
    const messages = await query(`
      SELECT m.*, u.username, u.nickname, u.avatar
      FROM messages m
      LEFT JOIN users u ON m.user_id = u.id
      WHERE m.id = ?
    `, [messageId]);
    
    if (messages.length === 0) {
      return res.error('留言不存在', 404);
    }
    
    const message = messages[0];
    
    // 检查权限：只能查看自己的留言或管理员可以查看所有留言
    if (req.user.role !== 'admin' && message.user_id !== req.user.id) {
      return res.error('权限不足', 403);
    }
    
    res.success(message);
    
  } catch (error) {
    logger.error('获取留言详情失败:', error);
    res.error('获取留言详情失败');
  }
});

/**
 * 创建留言
 */
router.post('/', authenticateToken, async (req, res) => {
  try {
    const { content, content_type } = req.body;
    
    if (!content || content.trim().length === 0) {
      return res.error('留言内容不能为空', 400);
    }
    
    if (content.length > 1000) {
      return res.error('留言内容不能超过1000个字符', 400);
    }
    
    const validContentTypes = ['message', 'feedback', 'suggestion'];
    if (content_type && !validContentTypes.includes(content_type)) {
      return res.error('留言类型无效', 400);
    }
    
    const result = await query(`
      INSERT INTO messages (user_id, content, content_type)
      VALUES (?, ?, ?)
    `, [req.user.id, content.trim(), content_type || 'message']);
    
    logger.info('留言创建成功:', { messageId: result.insertId, userId: req.user.id });
    
    res.success({
      id: result.insertId,
      content: content.trim(),
      content_type: content_type || 'message'
    }, '留言提交成功');
    
  } catch (error) {
    logger.error('创建留言失败:', error);
    res.error('留言提交失败');
  }
});

/**
 * 回复留言（管理员权限）
 */
router.put('/:id/reply', authenticateToken, requireRole('admin'), validateId, async (req, res) => {
  try {
    const messageId = parseInt(req.params.id);
    const { reply_content } = req.body;
    
    if (!reply_content || reply_content.trim().length === 0) {
      return res.error('回复内容不能为空', 400);
    }
    
    if (reply_content.length > 1000) {
      return res.error('回复内容不能超过1000个字符', 400);
    }
    
    const result = await query(`
      UPDATE messages 
      SET reply_content = ?, reply_time = NOW(), status = 'replied'
      WHERE id = ?
    `, [reply_content.trim(), messageId]);
    
    if (result.affectedRows === 0) {
      return res.error('留言不存在', 404);
    }
    
    logger.info('留言回复成功:', { messageId, userId: req.user.id });
    
    res.success(null, '回复成功');
    
  } catch (error) {
    logger.error('回复留言失败:', error);
    res.error('回复失败');
  }
});

/**
 * 更新留言状态（管理员权限）
 */
router.put('/:id/status', authenticateToken, requireRole('admin'), validateId, async (req, res) => {
  try {
    const messageId = parseInt(req.params.id);
    const { status } = req.body;
    
    if (!['unread', 'read', 'replied'].includes(status)) {
      return res.error('状态值无效', 400);
    }
    
    const result = await query(
      'UPDATE messages SET status = ? WHERE id = ?',
      [status, messageId]
    );
    
    if (result.affectedRows === 0) {
      return res.error('留言不存在', 404);
    }
    
    logger.info('留言状态更新成功:', { messageId, status, userId: req.user.id });
    
    res.success(null, '状态更新成功');
    
  } catch (error) {
    logger.error('更新留言状态失败:', error);
    res.error('状态更新失败');
  }
});

/**
 * 删除留言
 */
router.delete('/:id', authenticateToken, validateId, async (req, res) => {
  try {
    const messageId = parseInt(req.params.id);
    
    // 检查留言是否存在
    const existingMessage = await query(
      'SELECT user_id FROM messages WHERE id = ?',
      [messageId]
    );
    
    if (existingMessage.length === 0) {
      return res.error('留言不存在', 404);
    }
    
    // 检查权限：只能删除自己的留言或管理员可以删除所有留言
    if (req.user.role !== 'admin' && existingMessage[0].user_id !== req.user.id) {
      return res.error('权限不足', 403);
    }
    
    await query('DELETE FROM messages WHERE id = ?', [messageId]);
    
    logger.info('留言删除成功:', { messageId, userId: req.user.id });
    
    res.success(null, '留言删除成功');
    
  } catch (error) {
    logger.error('删除留言失败:', error);
    res.error('删除留言失败');
  }
});

/**
 * 获取我的留言列表
 */
router.get('/my/list', authenticateToken, validatePagination, async (req, res) => {
  try {
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 10;
    const offset = (page - 1) * limit;
    const contentType = req.query.content_type || '';
    const status = req.query.status || '';
    
    // 构建查询条件
    let whereConditions = ['user_id = ?'];
    let queryParams = [req.user.id];
    
    if (contentType) {
      whereConditions.push('content_type = ?');
      queryParams.push(contentType);
    }
    
    if (status) {
      whereConditions.push('status = ?');
      queryParams.push(status);
    }
    
    const whereClause = `WHERE ${whereConditions.join(' AND ')}`;
    
    // 获取总数
    const countResult = await query(`
      SELECT COUNT(*) as total FROM messages ${whereClause}
    `, queryParams);
    
    const total = countResult[0].total;
    
    // 获取留言列表
    const messages = await query(`
      SELECT * FROM messages ${whereClause}
      ORDER BY create_time DESC
      LIMIT ? OFFSET ?
    `, [...queryParams, limit, offset]);
    
    res.paginate(messages, {
      page,
      limit,
      total,
      pages: Math.ceil(total / limit)
    });
    
  } catch (error) {
    logger.error('获取我的留言列表失败:', error);
    res.error('获取我的留言列表失败');
  }
});

/**
 * 批量标记为已读（管理员权限）
 */
router.put('/batch/read', authenticateToken, requireRole('admin'), async (req, res) => {
  try {
    const { ids } = req.body;
    
    if (!Array.isArray(ids) || ids.length === 0) {
      return res.error('留言ID列表不能为空', 400);
    }
    
    const placeholders = ids.map(() => '?').join(',');
    const result = await query(`
      UPDATE messages SET status = 'read' 
      WHERE id IN (${placeholders}) AND status = 'unread'
    `, ids);
    
    logger.info('批量标记留言已读成功:', { 
      ids, 
      affectedRows: result.affectedRows, 
      userId: req.user.id 
    });
    
    res.success({
      updated: result.affectedRows
    }, `成功标记 ${result.affectedRows} 条留言为已读`);
    
  } catch (error) {
    logger.error('批量标记留言已读失败:', error);
    res.error('批量操作失败');
  }
});

/**
 * 获取留言统计信息
 */
router.get('/stats/overview', authenticateToken, async (req, res) => {
  try {
    let stats;
    
    if (req.user.role === 'admin') {
      // 管理员可以看到所有留言统计
      stats = await query(`
        SELECT 
          COUNT(*) as total_messages,
          SUM(CASE WHEN status = 'unread' THEN 1 ELSE 0 END) as unread_count,
          SUM(CASE WHEN status = 'read' THEN 1 ELSE 0 END) as read_count,
          SUM(CASE WHEN status = 'replied' THEN 1 ELSE 0 END) as replied_count,
          SUM(CASE WHEN content_type = 'message' THEN 1 ELSE 0 END) as message_count,
          SUM(CASE WHEN content_type = 'feedback' THEN 1 ELSE 0 END) as feedback_count,
          SUM(CASE WHEN content_type = 'suggestion' THEN 1 ELSE 0 END) as suggestion_count,
          SUM(CASE WHEN DATE(create_time) = CURDATE() THEN 1 ELSE 0 END) as today_count
        FROM messages
      `);
    } else {
      // 普通用户只能看到自己的留言统计
      stats = await query(`
        SELECT 
          COUNT(*) as total_messages,
          SUM(CASE WHEN status = 'unread' THEN 1 ELSE 0 END) as unread_count,
          SUM(CASE WHEN status = 'read' THEN 1 ELSE 0 END) as read_count,
          SUM(CASE WHEN status = 'replied' THEN 1 ELSE 0 END) as replied_count,
          SUM(CASE WHEN content_type = 'message' THEN 1 ELSE 0 END) as message_count,
          SUM(CASE WHEN content_type = 'feedback' THEN 1 ELSE 0 END) as feedback_count,
          SUM(CASE WHEN content_type = 'suggestion' THEN 1 ELSE 0 END) as suggestion_count
        FROM messages WHERE user_id = ?
      `, [req.user.id]);
    }
    
    res.success(stats[0]);
    
  } catch (error) {
    logger.error('获取留言统计失败:', error);
    res.error('获取留言统计失败');
  }
});

module.exports = router;
