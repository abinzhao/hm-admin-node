const express = require('express');
const { query } = require('../database/connection');
const { authenticateToken } = require('../middleware/auth');
const { validateTodoCreation, validatePagination, validateId } = require('../middleware/validation');
const logger = require('../utils/logger');

const router = express.Router();

/**
 * 获取待办事项列表
 */
router.get('/', authenticateToken, validatePagination, async (req, res) => {
  try {
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 10;
    const offset = (page - 1) * limit;
    const search = req.query.search || '';
    const status = req.query.status || '';
    const priority = req.query.priority || '';
    
    // 构建查询条件
    let whereConditions = ['user_id = ?'];
    let queryParams = [req.user.id];
    
    if (search) {
      whereConditions.push('(title LIKE ? OR description LIKE ?)');
      queryParams.push(`%${search}%`, `%${search}%`);
    }
    
    if (status) {
      whereConditions.push('status = ?');
      queryParams.push(status);
    }
    
    if (priority) {
      whereConditions.push('priority = ?');
      queryParams.push(priority);
    }
    
    const whereClause = `WHERE ${whereConditions.join(' AND ')}`;
    
    // 获取总数
    const countResult = await query(`
      SELECT COUNT(*) as total FROM todos ${whereClause}
    `, queryParams);
    
    const total = countResult[0].total;
    
    // 获取待办事项列表
    const todos = await query(`
      SELECT * FROM todos ${whereClause}
      ORDER BY 
        CASE priority 
          WHEN 'urgent' THEN 1 
          WHEN 'high' THEN 2 
          WHEN 'medium' THEN 3 
          WHEN 'low' THEN 4 
        END,
        due_date ASC,
        create_time DESC
      LIMIT ? OFFSET ?
    `, [...queryParams, limit, offset]);
    
    res.paginate(todos, {
      page,
      limit,
      total,
      pages: Math.ceil(total / limit)
    });
    
  } catch (error) {
    logger.error('获取待办事项列表失败:', error);
    res.error('获取待办事项列表失败');
  }
});

/**
 * 获取待办事项详情
 */
router.get('/:id', authenticateToken, validateId, async (req, res) => {
  try {
    const todoId = parseInt(req.params.id);
    
    const todos = await query(
      'SELECT * FROM todos WHERE id = ? AND user_id = ?',
      [todoId, req.user.id]
    );
    
    if (todos.length === 0) {
      return res.error('待办事项不存在', 404);
    }
    
    res.success(todos[0]);
    
  } catch (error) {
    logger.error('获取待办事项详情失败:', error);
    res.error('获取待办事项详情失败');
  }
});

/**
 * 创建待办事项
 */
router.post('/', authenticateToken, validateTodoCreation, async (req, res) => {
  try {
    const { title, description, status, priority, due_date } = req.body;
    
    const result = await query(`
      INSERT INTO todos (user_id, title, description, status, priority, due_date)
      VALUES (?, ?, ?, ?, ?, ?)
    `, [
      req.user.id,
      title,
      description,
      status || 'pending',
      priority || 'medium',
      due_date
    ]);
    
    logger.info('待办事项创建成功:', { todoId: result.insertId, userId: req.user.id });
    
    res.success({
      id: result.insertId,
      title,
      status: status || 'pending'
    }, '待办事项创建成功');
    
  } catch (error) {
    logger.error('创建待办事项失败:', error);
    res.error('创建待办事项失败');
  }
});

/**
 * 更新待办事项
 */
router.put('/:id', authenticateToken, validateId, async (req, res) => {
  try {
    const todoId = parseInt(req.params.id);
    const { title, description, status, priority, due_date } = req.body;
    
    // 检查待办事项是否存在且属于当前用户
    const existingTodo = await query(
      'SELECT * FROM todos WHERE id = ? AND user_id = ?',
      [todoId, req.user.id]
    );
    
    if (existingTodo.length === 0) {
      return res.error('待办事项不存在', 404);
    }
    
    const updateFields = [];
    const updateValues = [];
    
    if (title !== undefined) {
      updateFields.push('title = ?');
      updateValues.push(title);
    }
    
    if (description !== undefined) {
      updateFields.push('description = ?');
      updateValues.push(description);
    }
    
    if (status !== undefined) {
      updateFields.push('status = ?');
      updateValues.push(status);
      
      // 如果状态改为已完成，记录完成时间
      if (status === 'completed') {
        updateFields.push('completed_time = NOW()');
      } else if (existingTodo[0].status === 'completed' && status !== 'completed') {
        // 如果从已完成改为其他状态，清除完成时间
        updateFields.push('completed_time = NULL');
      }
    }
    
    if (priority !== undefined) {
      updateFields.push('priority = ?');
      updateValues.push(priority);
    }
    
    if (due_date !== undefined) {
      updateFields.push('due_date = ?');
      updateValues.push(due_date);
    }
    
    if (updateFields.length === 0) {
      return res.error('没有要更新的字段', 400);
    }
    
    updateValues.push(todoId);
    
    await query(`
      UPDATE todos SET ${updateFields.join(', ')} WHERE id = ?
    `, updateValues);
    
    logger.info('待办事项更新成功:', { todoId, userId: req.user.id });
    
    res.success(null, '待办事项更新成功');
    
  } catch (error) {
    logger.error('更新待办事项失败:', error);
    res.error('更新待办事项失败');
  }
});

/**
 * 删除待办事项
 */
router.delete('/:id', authenticateToken, validateId, async (req, res) => {
  try {
    const todoId = parseInt(req.params.id);
    
    const result = await query(
      'DELETE FROM todos WHERE id = ? AND user_id = ?',
      [todoId, req.user.id]
    );
    
    if (result.affectedRows === 0) {
      return res.error('待办事项不存在', 404);
    }
    
    logger.info('待办事项删除成功:', { todoId, userId: req.user.id });
    
    res.success(null, '待办事项删除成功');
    
  } catch (error) {
    logger.error('删除待办事项失败:', error);
    res.error('删除待办事项失败');
  }
});

/**
 * 批量更新待办事项状态
 */
router.put('/batch/status', authenticateToken, async (req, res) => {
  try {
    const { ids, status } = req.body;
    
    if (!Array.isArray(ids) || ids.length === 0) {
      return res.error('待办事项ID列表不能为空', 400);
    }
    
    if (!['pending', 'processing', 'completed', 'cancelled'].includes(status)) {
      return res.error('状态值无效', 400);
    }
    
    const placeholders = ids.map(() => '?').join(',');
    const queryParams = [...ids, status, req.user.id];
    
    let updateSql = `
      UPDATE todos 
      SET status = ?${status === 'completed' ? ', completed_time = NOW()' : ''}
      WHERE id IN (${placeholders}) AND user_id = ?
    `;
    
    const result = await query(updateSql, queryParams);
    
    logger.info('批量更新待办事项状态成功:', { 
      ids, 
      status, 
      affectedRows: result.affectedRows, 
      userId: req.user.id 
    });
    
    res.success({
      updated: result.affectedRows
    }, `成功更新 ${result.affectedRows} 个待办事项`);
    
  } catch (error) {
    logger.error('批量更新待办事项状态失败:', error);
    res.error('批量更新失败');
  }
});

/**
 * 获取待办事项统计信息
 */
router.get('/stats/overview', authenticateToken, async (req, res) => {
  try {
    const stats = await query(`
      SELECT 
        COUNT(*) as total_todos,
        SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending_count,
        SUM(CASE WHEN status = 'processing' THEN 1 ELSE 0 END) as processing_count,
        SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed_count,
        SUM(CASE WHEN status = 'cancelled' THEN 1 ELSE 0 END) as cancelled_count,
        SUM(CASE WHEN priority = 'urgent' THEN 1 ELSE 0 END) as urgent_count,
        SUM(CASE WHEN priority = 'high' THEN 1 ELSE 0 END) as high_count,
        SUM(CASE WHEN due_date < CURDATE() AND status NOT IN ('completed', 'cancelled') THEN 1 ELSE 0 END) as overdue_count
      FROM todos WHERE user_id = ?
    `, [req.user.id]);
    
    res.success(stats[0]);
    
  } catch (error) {
    logger.error('获取待办事项统计失败:', error);
    res.error('获取待办事项统计失败');
  }
});

module.exports = router;
