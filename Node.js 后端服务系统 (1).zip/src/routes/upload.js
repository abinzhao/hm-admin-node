const express = require('express');
const path = require('path');
const fs = require('fs');
const { authenticateToken } = require('../middleware/auth');
const logger = require('../utils/logger');

const router = express.Router();

// 确保上传目录存在
const uploadDir = path.join(process.cwd(), 'uploads');
if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir, { recursive: true });
}

// 创建子目录
const subDirs = ['images', 'documents', 'apps', 'avatars'];
subDirs.forEach(dir => {
  const subDir = path.join(uploadDir, dir);
  if (!fs.existsSync(subDir)) {
    fs.mkdirSync(subDir, { recursive: true });
  }
});

/**
 * 文件上传
 */
router.post('/', authenticateToken, async (req, res) => {
  try {
    if (!req.files || Object.keys(req.files).length === 0) {
      return res.error('没有文件被上传', 400);
    }
    
    const file = req.files.file;
    const fileType = req.body.type || 'images'; // images, documents, apps, avatars
    
    // 验证文件类型
    const allowedTypes = {
      images: ['.jpg', '.jpeg', '.png', '.gif', '.webp'],
      documents: ['.pdf', '.doc', '.docx', '.txt', '.md'],
      apps: ['.hap', '.apk', '.zip'],
      avatars: ['.jpg', '.jpeg', '.png', '.gif', '.webp']
    };
    
    if (!allowedTypes[fileType]) {
      return res.error('不支持的文件类型分类', 400);
    }
    
    const fileExt = path.extname(file.name).toLowerCase();
    if (!allowedTypes[fileType].includes(fileExt)) {
      return res.error(`${fileType}类型不支持${fileExt}格式的文件`, 400);
    }
    
    // 生成唯一文件名
    const timestamp = Date.now();
    const randomStr = Math.random().toString(36).substr(2, 9);
    const fileName = `${timestamp}_${randomStr}${fileExt}`;
    const filePath = path.join(uploadDir, fileType, fileName);
    
    // 移动文件
    await file.mv(filePath);
    
    // 生成访问URL
    const fileUrl = `/uploads/${fileType}/${fileName}`;
    
    logger.info('文件上传成功:', {
      originalName: file.name,
      fileName,
      fileType,
      size: file.size,
      userId: req.user.id
    });
    
    res.success({
      fileName,
      originalName: file.name,
      fileType,
      size: file.size,
      url: fileUrl,
      fullUrl: `${req.protocol}://${req.get('host')}${fileUrl}`
    }, '文件上传成功');
    
  } catch (error) {
    logger.error('文件上传失败:', error);
    res.error('文件上传失败');
  }
});

/**
 * 批量文件上传
 */
router.post('/batch', authenticateToken, async (req, res) => {
  try {
    if (!req.files || Object.keys(req.files).length === 0) {
      return res.error('没有文件被上传', 400);
    }
    
    const files = Array.isArray(req.files.files) ? req.files.files : [req.files.files];
    const fileType = req.body.type || 'images';
    
    // 验证文件类型
    const allowedTypes = {
      images: ['.jpg', '.jpeg', '.png', '.gif', '.webp'],
      documents: ['.pdf', '.doc', '.docx', '.txt', '.md'],
      apps: ['.hap', '.apk', '.zip'],
      avatars: ['.jpg', '.jpeg', '.png', '.gif', '.webp']
    };
    
    if (!allowedTypes[fileType]) {
      return res.error('不支持的文件类型分类', 400);
    }
    
    const uploadResults = [];
    const errors = [];
    
    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      
      try {
        const fileExt = path.extname(file.name).toLowerCase();
        if (!allowedTypes[fileType].includes(fileExt)) {
          errors.push(`文件 ${file.name}: ${fileType}类型不支持${fileExt}格式`);
          continue;
        }
        
        // 生成唯一文件名
        const timestamp = Date.now();
        const randomStr = Math.random().toString(36).substr(2, 9);
        const fileName = `${timestamp}_${i}_${randomStr}${fileExt}`;
        const filePath = path.join(uploadDir, fileType, fileName);
        
        // 移动文件
        await file.mv(filePath);
        
        // 生成访问URL
        const fileUrl = `/uploads/${fileType}/${fileName}`;
        
        uploadResults.push({
          fileName,
          originalName: file.name,
          fileType,
          size: file.size,
          url: fileUrl,
          fullUrl: `${req.protocol}://${req.get('host')}${fileUrl}`
        });
        
      } catch (error) {
        errors.push(`文件 ${file.name}: ${error.message}`);
      }
    }
    
    logger.info('批量文件上传完成:', {
      totalFiles: files.length,
      successCount: uploadResults.length,
      errorCount: errors.length,
      userId: req.user.id
    });
    
    res.success({
      files: uploadResults,
      errors,
      summary: {
        total: files.length,
        success: uploadResults.length,
        failed: errors.length
      }
    }, `批量上传完成，成功${uploadResults.length}个，失败${errors.length}个`);
    
  } catch (error) {
    logger.error('批量文件上传失败:', error);
    res.error('批量文件上传失败');
  }
});

/**
 * 删除文件
 */
router.delete('/:type/:fileName', authenticateToken, async (req, res) => {
  try {
    const { type, fileName } = req.params;
    
    // 验证文件类型
    const allowedTypes = ['images', 'documents', 'apps', 'avatars'];
    if (!allowedTypes.includes(type)) {
      return res.error('不支持的文件类型', 400);
    }
    
    // 验证文件名（防止路径遍历攻击）
    if (fileName.includes('..') || fileName.includes('/') || fileName.includes('\\')) {
      return res.error('无效的文件名', 400);
    }
    
    const filePath = path.join(uploadDir, type, fileName);
    
    // 检查文件是否存在
    if (!fs.existsSync(filePath)) {
      return res.error('文件不存在', 404);
    }
    
    // 删除文件
    fs.unlinkSync(filePath);
    
    logger.info('文件删除成功:', {
      fileName,
      type,
      userId: req.user.id
    });
    
    res.success(null, '文件删除成功');
    
  } catch (error) {
    logger.error('文件删除失败:', error);
    res.error('文件删除失败');
  }
});

/**
 * 获取文件列表
 */
router.get('/:type', authenticateToken, async (req, res) => {
  try {
    const { type } = req.params;
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 20;
    
    // 验证文件类型
    const allowedTypes = ['images', 'documents', 'apps', 'avatars'];
    if (!allowedTypes.includes(type)) {
      return res.error('不支持的文件类型', 400);
    }
    
    const typeDir = path.join(uploadDir, type);
    
    if (!fs.existsSync(typeDir)) {
      return res.success({
        files: [],
        pagination: {
          page,
          limit,
          total: 0,
          pages: 0
        }
      });
    }
    
    // 读取文件列表
    const files = fs.readdirSync(typeDir)
      .filter(file => {
        const filePath = path.join(typeDir, file);
        return fs.statSync(filePath).isFile();
      })
      .map(file => {
        const filePath = path.join(typeDir, file);
        const stats = fs.statSync(filePath);
        return {
          fileName: file,
          size: stats.size,
          createTime: stats.birthtime,
          modifyTime: stats.mtime,
          url: `/uploads/${type}/${file}`,
          fullUrl: `${req.protocol}://${req.get('host')}/uploads/${type}/${file}`
        };
      })
      .sort((a, b) => new Date(b.createTime) - new Date(a.createTime));
    
    // 分页
    const total = files.length;
    const pages = Math.ceil(total / limit);
    const offset = (page - 1) * limit;
    const paginatedFiles = files.slice(offset, offset + limit);
    
    res.success({
      files: paginatedFiles,
      pagination: {
        page,
        limit,
        total,
        pages
      }
    });
    
  } catch (error) {
    logger.error('获取文件列表失败:', error);
    res.error('获取文件列表失败');
  }
});

/**
 * 获取文件信息
 */
router.get('/:type/:fileName/info', async (req, res) => {
  try {
    const { type, fileName } = req.params;
    
    // 验证文件类型
    const allowedTypes = ['images', 'documents', 'apps', 'avatars'];
    if (!allowedTypes.includes(type)) {
      return res.error('不支持的文件类型', 400);
    }
    
    // 验证文件名
    if (fileName.includes('..') || fileName.includes('/') || fileName.includes('\\')) {
      return res.error('无效的文件名', 400);
    }
    
    const filePath = path.join(uploadDir, type, fileName);
    
    if (!fs.existsSync(filePath)) {
      return res.error('文件不存在', 404);
    }
    
    const stats = fs.statSync(filePath);
    const fileExt = path.extname(fileName).toLowerCase();
    
    res.success({
      fileName,
      type,
      size: stats.size,
      extension: fileExt,
      createTime: stats.birthtime,
      modifyTime: stats.mtime,
      url: `/uploads/${type}/${fileName}`,
      fullUrl: `${req.protocol}://${req.get('host')}/uploads/${type}/${fileName}`
    });
    
  } catch (error) {
    logger.error('获取文件信息失败:', error);
    res.error('获取文件信息失败');
  }
});

module.exports = router;
