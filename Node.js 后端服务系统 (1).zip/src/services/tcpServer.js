const net = require('net');
const { spawn } = require('child_process');
const logger = require('../utils/logger');

class TCPServer {
  constructor() {
    this.server = null;
    this.clients = new Map();
    this.commandQueue = [];
    this.isProcessing = false;
    this.maxConcurrentCommands = 3;
    this.activeCommands = 0;
  }
  
  start(port) {
    this.server = net.createServer((socket) => {
      this.handleConnection(socket);
    });
    
    this.server.listen(port, () => {
      logger.info(`TCP服务器启动成功，端口: ${port}`);
    });
    
    this.server.on('error', (error) => {
      logger.error('TCP服务器错误:', error);
    });
    
    return this.server;
  }
  
  handleConnection(socket) {
    const clientId = `${socket.remoteAddress}:${socket.remotePort}`;
    logger.info(`TCP客户端连接: ${clientId}`);
    
    // 存储客户端连接
    this.clients.set(clientId, {
      socket,
      connected: true,
      lastActivity: Date.now()
    });
    
    // 发送欢迎消息
    this.sendMessage(socket, {
      type: 'welcome',
      message: 'TCP调试服务器连接成功',
      clientId
    });
    
    // 处理客户端消息
    socket.on('data', (data) => {
      try {
        const message = JSON.parse(data.toString());
        this.handleMessage(clientId, message);
      } catch (error) {
        logger.error('解析TCP消息失败:', error);
        this.sendMessage(socket, {
          type: 'error',
          message: '消息格式错误'
        });
      }
    });
    
    // 处理连接关闭
    socket.on('close', () => {
      logger.info(`TCP客户端断开连接: ${clientId}`);
      this.clients.delete(clientId);
    });
    
    // 处理连接错误
    socket.on('error', (error) => {
      logger.error(`TCP客户端错误 ${clientId}:`, error);
      this.clients.delete(clientId);
    });
    
    // 设置超时
    socket.setTimeout(300000); // 5分钟超时
    socket.on('timeout', () => {
      logger.info(`TCP客户端超时: ${clientId}`);
      socket.end();
    });
  }
  
  handleMessage(clientId, message) {
    const client = this.clients.get(clientId);
    if (!client) return;
    
    client.lastActivity = Date.now();
    
    logger.info(`收到TCP消息 ${clientId}:`, message);
    
    switch (message.type) {
      case 'ping':
        this.sendMessage(client.socket, {
          type: 'pong',
          timestamp: Date.now()
        });
        break;
        
      case 'adb_command':
      case 'hdc_command':
        this.queueCommand(clientId, message);
        break;
        
      case 'get_devices':
        this.getDevices(clientId, message.commandType || 'adb');
        break;
        
      case 'cancel_command':
        this.cancelCommand(clientId, message.commandId);
        break;
        
      default:
        this.sendMessage(client.socket, {
          type: 'error',
          message: `未知的消息类型: ${message.type}`
        });
    }
  }
  
  queueCommand(clientId, message) {
    const commandId = `${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    
    const command = {
      id: commandId,
      clientId,
      type: message.type,
      command: message.command,
      args: message.args || [],
      timeout: message.timeout || 30000,
      timestamp: Date.now()
    };
    
    this.commandQueue.push(command);
    
    // 通知客户端命令已加入队列
    const client = this.clients.get(clientId);
    if (client) {
      this.sendMessage(client.socket, {
        type: 'command_queued',
        commandId,
        queuePosition: this.commandQueue.length
      });
    }
    
    // 处理队列
    this.processQueue();
  }
  
  async processQueue() {
    if (this.isProcessing || this.activeCommands >= this.maxConcurrentCommands) {
      return;
    }
    
    if (this.commandQueue.length === 0) {
      return;
    }
    
    this.isProcessing = true;
    const command = this.commandQueue.shift();
    this.activeCommands++;
    
    try {
      await this.executeCommand(command);
    } catch (error) {
      logger.error('执行命令失败:', error);
    } finally {
      this.activeCommands--;
      this.isProcessing = false;
      
      // 继续处理队列
      if (this.commandQueue.length > 0) {
        setTimeout(() => this.processQueue(), 100);
      }
    }
  }
  
  async executeCommand(command) {
    const client = this.clients.get(command.clientId);
    if (!client) {
      logger.warn(`客户端 ${command.clientId} 已断开连接，跳过命令执行`);
      return;
    }
    
    // 通知开始执行
    this.sendMessage(client.socket, {
      type: 'command_started',
      commandId: command.id
    });
    
    const commandType = command.type === 'adb_command' ? 'adb' : 'hdc';
    const fullCommand = [command.command, ...command.args];
    
    logger.info(`执行${commandType}命令:`, fullCommand);
    
    try {
      const child = spawn(commandType, fullCommand, {
        timeout: command.timeout
      });
      
      let stdout = '';
      let stderr = '';
      
      child.stdout.on('data', (data) => {
        const output = data.toString();
        stdout += output;
        
        // 实时发送输出
        this.sendMessage(client.socket, {
          type: 'command_output',
          commandId: command.id,
          output,
          stream: 'stdout'
        });
      });
      
      child.stderr.on('data', (data) => {
        const output = data.toString();
        stderr += output;
        
        // 实时发送错误输出
        this.sendMessage(client.socket, {
          type: 'command_output',
          commandId: command.id,
          output,
          stream: 'stderr'
        });
      });
      
      child.on('close', (code) => {
        // 发送命令完成消息
        this.sendMessage(client.socket, {
          type: 'command_completed',
          commandId: command.id,
          exitCode: code,
          stdout,
          stderr,
          duration: Date.now() - command.timestamp
        });
        
        logger.info(`${commandType}命令执行完成:`, {
          commandId: command.id,
          exitCode: code,
          duration: Date.now() - command.timestamp
        });
      });
      
      child.on('error', (error) => {
        this.sendMessage(client.socket, {
          type: 'command_error',
          commandId: command.id,
          error: error.message
        });
        
        logger.error(`${commandType}命令执行错误:`, error);
      });
      
    } catch (error) {
      this.sendMessage(client.socket, {
        type: 'command_error',
        commandId: command.id,
        error: error.message
      });
      
      logger.error('命令执行异常:', error);
    }
  }
  
  async getDevices(clientId, commandType) {
    const client = this.clients.get(clientId);
    if (!client) return;
    
    try {
      const child = spawn(commandType, ['devices'], { timeout: 10000 });
      
      let output = '';
      
      child.stdout.on('data', (data) => {
        output += data.toString();
      });
      
      child.on('close', (code) => {
        if (code === 0) {
          // 解析设备列表
          const devices = this.parseDeviceList(output, commandType);
          
          this.sendMessage(client.socket, {
            type: 'devices_list',
            commandType,
            devices,
            rawOutput: output
          });
        } else {
          this.sendMessage(client.socket, {
            type: 'error',
            message: `获取设备列表失败，退出码: ${code}`
          });
        }
      });
      
      child.on('error', (error) => {
        this.sendMessage(client.socket, {
          type: 'error',
          message: `获取设备列表错误: ${error.message}`
        });
      });
      
    } catch (error) {
      this.sendMessage(client.socket, {
        type: 'error',
        message: `获取设备列表异常: ${error.message}`
      });
    }
  }
  
  parseDeviceList(output, commandType) {
    const devices = [];
    const lines = output.split('\n');
    
    for (const line of lines) {
      const trimmed = line.trim();
      if (!trimmed || trimmed.includes('List of devices')) continue;
      
      const parts = trimmed.split(/\s+/);
      if (parts.length >= 2) {
        devices.push({
          id: parts[0],
          status: parts[1],
          type: commandType
        });
      }
    }
    
    return devices;
  }
  
  cancelCommand(clientId, commandId) {
    // 从队列中移除命令
    const index = this.commandQueue.findIndex(cmd => 
      cmd.id === commandId && cmd.clientId === clientId
    );
    
    if (index !== -1) {
      this.commandQueue.splice(index, 1);
      
      const client = this.clients.get(clientId);
      if (client) {
        this.sendMessage(client.socket, {
          type: 'command_cancelled',
          commandId
        });
      }
      
      logger.info(`命令已取消: ${commandId}`);
    }
  }
  
  sendMessage(socket, message) {
    if (socket && !socket.destroyed) {
      try {
        socket.write(JSON.stringify(message) + '\n');
      } catch (error) {
        logger.error('发送TCP消息失败:', error);
      }
    }
  }
  
  broadcast(message) {
    for (const [clientId, client] of this.clients) {
      if (client.connected) {
        this.sendMessage(client.socket, message);
      }
    }
  }
  
  getStatus() {
    return {
      isRunning: this.server && this.server.listening,
      clientCount: this.clients.size,
      queueLength: this.commandQueue.length,
      activeCommands: this.activeCommands,
      clients: Array.from(this.clients.keys())
    };
  }
  
  close(callback) {
    if (this.server) {
      // 关闭所有客户端连接
      for (const [clientId, client] of this.clients) {
        if (client.socket && !client.socket.destroyed) {
          client.socket.end();
        }
      }
      
      this.clients.clear();
      this.commandQueue = [];
      
      this.server.close(callback);
      logger.info('TCP服务器已关闭');
    } else if (callback) {
      callback();
    }
  }
}

module.exports = new TCPServer();
