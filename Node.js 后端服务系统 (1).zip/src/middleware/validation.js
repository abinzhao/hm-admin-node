const { body, param, query, validationResult } = require('express-validator');

/**
 * 验证结果处理中间件
 */
function handleValidationErrors(req, res, next) {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    const errorMessages = errors.array().map(error => error.msg);
    return res.error(errorMessages.join(', '), 400);
  }
  next();
}

/**
 * 用户注册验证规则
 */
const validateUserRegistration = [
  body('username')
    .isLength({ min: 3, max: 50 })
    .withMessage('用户名长度必须在3-50个字符之间')
    .matches(/^[a-zA-Z0-9_-]+$/)
    .withMessage('用户名只能包含字母、数字、下划线和连字符'),
  
  body('password')
    .isLength({ min: 6, max: 128 })
    .withMessage('密码长度必须在6-128个字符之间'),
  
  body('email')
    .optional()
    .isEmail()
    .withMessage('邮箱格式不正确'),
  
  body('phone')
    .optional()
    .matches(/^1[3-9]\d{9}$/)
    .withMessage('手机号格式不正确'),
  
  handleValidationErrors
];

/**
 * 用户登录验证规则
 */
const validateUserLogin = [
  body('username')
    .notEmpty()
    .withMessage('用户名不能为空'),
  
  body('password')
    .notEmpty()
    .withMessage('密码不能为空'),
  
  handleValidationErrors
];

/**
 * 内容创建验证规则
 */
const validateContentCreation = [
  body('title')
    .isLength({ min: 1, max: 255 })
    .withMessage('标题长度必须在1-255个字符之间'),
  
  body('content_type')
    .isIn(['article', 'question', 'snippet'])
    .withMessage('内容类型必须是article、question或snippet'),
  
  body('content')
    .notEmpty()
    .withMessage('内容不能为空'),
  
  handleValidationErrors
];

/**
 * 应用创建验证规则
 */
const validateAppCreation = [
  body('package_name')
    .notEmpty()
    .withMessage('包名不能为空'),
  
  body('app_name')
    .isLength({ min: 1, max: 100 })
    .withMessage('应用名称长度必须在1-100个字符之间'),
  
  body('app_version')
    .matches(/^\d+\.\d+\.\d+$/)
    .withMessage('版本号格式不正确，应为x.y.z格式'),
  
  handleValidationErrors
];

/**
 * 待办事项创建验证规则
 */
const validateTodoCreation = [
  body('title')
    .isLength({ min: 1, max: 255 })
    .withMessage('标题长度必须在1-255个字符之间'),
  
  body('status')
    .optional()
    .isIn(['pending', 'processing', 'completed', 'cancelled'])
    .withMessage('状态必须是pending、processing、completed或cancelled'),
  
  body('priority')
    .optional()
    .isIn(['low', 'medium', 'high', 'urgent'])
    .withMessage('优先级必须是low、medium、high或urgent'),
  
  body('due_date')
    .optional()
    .isISO8601()
    .withMessage('截止日期格式不正确'),
  
  handleValidationErrors
];

/**
 * 分页参数验证规则
 */
const validatePagination = [
  query('page')
    .optional()
    .isInt({ min: 1 })
    .withMessage('页码必须是大于0的整数'),
  
  query('limit')
    .optional()
    .isInt({ min: 1, max: 100 })
    .withMessage('每页数量必须是1-100之间的整数'),
  
  handleValidationErrors
];

/**
 * ID参数验证规则
 */
const validateId = [
  param('id')
    .isInt({ min: 1 })
    .withMessage('ID必须是大于0的整数'),
  
  handleValidationErrors
];

module.exports = {
  handleValidationErrors,
  validateUserRegistration,
  validateUserLogin,
  validateContentCreation,
  validateAppCreation,
  validateTodoCreation,
  validatePagination,
  validateId
};
