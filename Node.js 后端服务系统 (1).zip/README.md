# Node.js 后端服务系统

一个功能完整的 Node.js 后端服务系统，提供用户管理、内容管理、应用管理、待办事项、留言系统、系统通知等功能，同时集成了TCP调试服务。

## 功能特性

### 🔐 用户认证与授权
- JWT Token 认证
- 密码加密存储（bcrypt）
- 角色权限控制（admin/user）
- 登录状态管理
- 会话超时处理

### 📝 内容管理系统
- 支持文章、问题、代码片段三种内容类型
- 内容分类和标签管理
- 全文搜索功能
- 浏览量和点赞统计
- 内容状态管理（草稿/发布/归档）

### 📱 应用包管理
- 应用信息管理
- 文件上传和下载
- 应用截图展示
- 下载量统计
- 应用分类管理

### ✅ 待办事项系统
- 任务创建和管理
- 优先级设置（低/中/高/紧急）
- 状态跟踪（待处理/进行中/已完成/已取消）
- 截止日期提醒
- 批量操作支持

### 💬 留言系统
- 用户留言提交
- 管理员回复功能
- 留言状态管理
- 留言分类（留言/反馈/建议）

### 📢 系统通知
- 系统公告发布
- 通知分类管理
- 通知状态控制
- 最新通知展示

### 🔧 TCP调试服务
- TCP服务器创建
- 客户端连接管理
- ADB/HDC命令执行
- 命令队列管理
- 并发控制

### 📊 数据统计与监控
- 首页数据大屏
- 用户活跃度统计
- 内容趋势分析
- 系统健康监控
- 管理员仪表板

## 技术栈

- **核心框架**: Node.js + Express
- **数据库**: MySQL
- **身份认证**: JWT
- **密码加密**: bcryptjs
- **文件上传**: express-fileupload
- **日志系统**: Winston
- **缓存**: node-cache
- **进程管理**: PM2
- **安全防护**: Helmet + CORS
- **请求限制**: express-rate-limit
- **数据验证**: express-validator

## 项目结构

```
src/
├── app.js                 # 应用入口文件
├── database/
│   ├── connection.js      # 数据库连接和表初始化
│   └── migrate.js         # 数据库迁移脚本
├── middleware/
│   ├── auth.js           # 认证中间件
│   ├── errorHandler.js   # 错误处理中间件
│   ├── responseFormatter.js # 响应格式化中间件
│   └── validation.js     # 数据验证中间件
├── routes/
│   ├── auth.js           # 认证路由
│   ├── users.js          # 用户管理路由
│   ├── contents.js       # 内容管理路由
│   ├── apps.js           # 应用管理路由
│   ├── todos.js          # 待办事项路由
│   ├── messages.js       # 留言管理路由
│   ├── notifications.js  # 系统通知路由
│   ├── dashboard.js      # 仪表板路由
│   └── upload.js         # 文件上传路由
├── services/
│   └── tcpServer.js      # TCP调试服务
└── utils/
    ├── logger.js         # 日志工具
    ├── portChecker.js    # 端口检查工具
    └── cache.js          # 缓存管理工具
```

## 安装和运行

### 环境要求
- Node.js >= 14.0.0
- MySQL >= 5.7
- npm >= 6.0.0

### 安装依赖
```bash
npm install
```

### 环境配置
复制 `.env` 文件并配置相关参数：
```bash
# 服务器配置
PORT=3000
NODE_ENV=development

# 数据库配置
DB_HOST=localhost
DB_PORT=3306
DB_USER=root
DB_PASSWORD=your_password
DB_NAME=nodejs_system

# JWT配置
JWT_SECRET=your-super-secret-jwt-key-here
JWT_EXPIRES_IN=24h

# TCP服务配置
TCP_PORT=8888
```

### 数据库初始化
```bash
npm run migrate
```

### 启动服务

#### 开发模式
```bash
npm run dev
```

#### 生产模式
```bash
npm start
```

#### 使用PM2管理
```bash
# 启动
pm2 start ecosystem.config.js

# 重启
pm2 restart nodejs-backend-system

# 停止
pm2 stop nodejs-backend-system

# 查看日志
pm2 logs nodejs-backend-system
```

## API 文档

### 认证接口

#### 用户注册
**POST** `/api/auth/register`

**请求示例：**
```json
{
  "username": "testuser",
  "password": "123456",
  "nickname": "测试用户",
  "email": "test@example.com",
  "phone": "13800138000"
}
```

**返回示例：**
```json
{
  "code": 200,
  "message": "注册成功",
  "data": {
    "id": 2,
    "userId": "user_1703123456789_abc123def",
    "username": "testuser",
    "nickname": "测试用户"
  },
  "timestamp": "2025-01-15T10:30:45.123Z"
}
```

#### 用户登录
**POST** `/api/auth/login`

**请求示例：**
```json
{
  "username": "admin",
  "password": "admin123"
}
```

**返回示例：**
```json
{
  "code": 200,
  "message": "登录成功",
  "data": {
    "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
    "user": {
      "id": 1,
      "userId": "user_001",
      "username": "admin",
      "nickname": "系统管理员",
      "role": "admin"
    }
  },
  "timestamp": "2025-01-15T10:30:45.123Z"
}
```

#### 获取当前用户信息
**GET** `/api/auth/me`

**请求头：**
```
Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
```

**返回示例：**
```json
{
  "code": 200,
  "message": "操作成功",
  "data": {
    "id": 1,
    "user_id": "user_001",
    "username": "admin",
    "nickname": "系统管理员",
    "role": "admin",
    "phone": "13800138000",
    "email": "admin@163.com",
    "tags": ["社区贡献者", "技术专家", "管理员"],
    "description": "这是一个测试用户",
    "avatar": "https://q9.itc.cn/q_70/images03/20241013/d770472d4906402c866b9c71a0c9927c.jpeg",
    "create_time": "2025-01-15T10:30:45.000Z",
    "last_login_time": "2025-01-15T10:30:45.000Z"
  },
  "timestamp": "2025-01-15T10:30:45.123Z"
}
```

#### 更新用户信息
**PUT** `/api/auth/profile`

**请求示例：**
```json
{
  "nickname": "新昵称",
  "email": "newemail@example.com",
  "phone": "13900139000",
  "description": "更新后的描述",
  "avatar": "https://example.com/new-avatar.jpg",
  "tags": ["新标签1", "新标签2"]
}
```

**返回示例：**
```json
{
  "code": 200,
  "message": "更新成功",
  "data": null,
  "timestamp": "2025-01-15T10:30:45.123Z"
}
```

#### 修改密码
**PUT** `/api/auth/password`

**请求示例：**
```json
{
  "oldPassword": "oldpassword123",
  "newPassword": "newpassword456"
}
```

**返回示例：**
```json
{
  "code": 200,
  "message": "密码修改成功",
  "data": null,
  "timestamp": "2025-01-15T10:30:45.123Z"
}
```

#### 刷新Token
**POST** `/api/auth/refresh`

**返回示例：**
```json
{
  "code": 200,
  "message": "Token刷新成功",
  "data": {
    "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
  },
  "timestamp": "2025-01-15T10:30:45.123Z"
}
```

### 用户管理接口

#### 获取用户列表（管理员）
**GET** `/api/users?page=1&limit=10&search=admin&role=admin&status=active`

**返回示例：**
```json
{
  "code": 200,
  "message": "获取成功",
  "data": [
    {
      "id": 1,
      "user_id": "user_001",
      "username": "admin",
      "nickname": "系统管理员",
      "role": "admin",
      "phone": "13800138000",
      "email": "admin@163.com",
      "tags": ["社区贡献者", "技术专家", "管理员"],
      "description": "这是一个测试用户",
      "avatar": "https://q9.itc.cn/q_70/images03/20241013/d770472d4906402c866b9c71a0c9927c.jpeg",
      "status": "active",
      "create_time": "2025-01-15T10:30:45.000Z",
      "last_login_time": "2025-01-15T10:30:45.000Z"
    }
  ],
  "pagination": {
    "page": 1,
    "limit": 10,
    "total": 1,
    "pages": 1
  },
  "timestamp": "2025-01-15T10:30:45.123Z"
}
```

#### 获取用户详情
**GET** `/api/users/1`

**返回示例：**
```json
{
  "code": 200,
  "message": "操作成功",
  "data": {
    "id": 1,
    "user_id": "user_001",
    "username": "admin",
    "nickname": "系统管理员",
    "role": "admin",
    "phone": "13800138000",
    "email": "admin@163.com",
    "tags": ["社区贡献者", "技术专家", "管理员"],
    "description": "这是一个测试用户",
    "avatar": "https://q9.itc.cn/q_70/images03/20241013/d770472d4906402c866b9c71a0c9927c.jpeg",
    "status": "active",
    "create_time": "2025-01-15T10:30:45.000Z",
    "last_login_time": "2025-01-15T10:30:45.000Z"
  },
  "timestamp": "2025-01-15T10:30:45.123Z"
}
```

#### 更新用户状态（管理员）
**PUT** `/api/users/2/status`

**请求示例：**
```json
{
  "status": "inactive"
}
```

**返回示例：**
```json
{
  "code": 200,
  "message": "状态更新成功",
  "data": null,
  "timestamp": "2025-01-15T10:30:45.123Z"
}
```

#### 更新用户角色（管理员）
**PUT** `/api/users/2/role`

**请求示例：**
```json
{
  "role": "admin"
}
```

**返回示例：**
```json
{
  "code": 200,
  "message": "角色更新成功",
  "data": null,
  "timestamp": "2025-01-15T10:30:45.123Z"
}
```

#### 删除用户（管理员）
**DELETE** `/api/users/2`

**返回示例：**
```json
{
  "code": 200,
  "message": "用户删除成功",
  "data": null,
  "timestamp": "2025-01-15T10:30:45.123Z"
}
```

### 内容管理接口

#### 获取内容列表
**GET** `/api/contents?page=1&limit=10&search=文章&content_type=article&user_id=1&tags=前端`

**返回示例：**
```json
{
  "code": 200,
  "message": "获取成功",
  "data": [
    {
      "id": 1,
      "user_id": 1,
      "title": "文章1文章1文章1文章1文章1文章1文章1文章1文章1文章1",
      "description": "内容1内容1内容1内容1内容1内容1内容1",
      "content_type": "article",
      "tags": ["前端", "ArkUI"],
      "cover_image": [{"url": "https://q9.itc.cn/q_70/images03/20241013/d770472d4906402c866b9c71a0c9927c.jpeg"}],
      "content": "这是文章内容这是文章内容这是文章内容这是文章内容这是文章内容这是文章内容",
      "status": "published",
      "view_count": 100,
      "like_count": 10,
      "create_time": "2025-01-15T10:30:45.000Z",
      "update_time": "2025-01-15T10:30:45.000Z",
      "username": "admin",
      "nickname": "系统管理员",
      "avatar": "https://q9.itc.cn/q_70/images03/20241013/d770472d4906402c866b9c71a0c9927c.jpeg"
    }
  ],
  "pagination": {
    "page": 1,
    "limit": 10,
    "total": 1,
    "pages": 1
  },
  "timestamp": "2025-01-15T10:30:45.123Z"
}
```

#### 获取内容详情
**GET** `/api/contents/1`

**返回示例：**
```json
{
  "code": 200,
  "message": "操作成功",
  "data": {
    "id": 1,
    "user_id": 1,
    "title": "文章1文章1文章1文章1文章1文章1文章1文章1文章1文章1",
    "description": "内容1内容1内容1内容1内容1内容1内容1",
    "content_type": "article",
    "tags": ["前端", "ArkUI"],
    "cover_image": [{"url": "https://q9.itc.cn/q_70/images03/20241013/d770472d4906402c866b9c71a0c9927c.jpeg"}],
    "content": "这是文章内容这是文章内容这是文章内容这是文章内容这是文章内容这是文章内容",
    "status": "published",
    "view_count": 101,
    "like_count": 10,
    "create_time": "2025-01-15T10:30:45.000Z",
    "update_time": "2025-01-15T10:30:45.000Z",
    "username": "admin",
    "nickname": "系统管理员",
    "avatar": "https://q9.itc.cn/q_70/images03/20241013/d770472d4906402c866b9c71a0c9927c.jpeg"
  },
  "timestamp": "2025-01-15T10:30:45.123Z"
}
```

#### 创建内容
**POST** `/api/contents`

**请求示例：**
```json
{
  "title": "新文章标题",
  "description": "文章描述",
  "content_type": "article",
  "tags": ["前端", "React"],
  "cover_image": [{"url": "https://example.com/cover.jpg"}],
  "content": "这是文章的详细内容...",
  "status": "published"
}
```

**返回示例：**
```json
{
  "code": 200,
  "message": "内容创建成功",
  "data": {
    "id": 2,
    "title": "新文章标题",
    "content_type": "article"
  },
  "timestamp": "2025-01-15T10:30:45.123Z"
}
```

#### 更新内容
**PUT** `/api/contents/1`

**请求示例：**
```json
{
  "title": "更新后的标题",
  "description": "更新后的描述",
  "tags": ["前端", "Vue"],
  "status": "published"
}
```

**返回示例：**
```json
{
  "code": 200,
  "message": "内容更新成功",
  "data": null,
  "timestamp": "2025-01-15T10:30:45.123Z"
}
```

#### 删除内容
**DELETE** `/api/contents/1`

**返回示例：**
```json
{
  "code": 200,
  "message": "内容删除成功",
  "data": null,
  "timestamp": "2025-01-15T10:30:45.123Z"
}
```

#### 获取我的内容列表
**GET** `/api/contents/my/list?page=1&limit=10&search=文章&content_type=article&status=published`

**返回示例：**
```json
{
  "code": 200,
  "message": "获取成功",
  "data": [
    {
      "id": 1,
      "user_id": 1,
      "title": "我的文章标题",
      "description": "文章描述",
      "content_type": "article",
      "tags": ["前端", "ArkUI"],
      "cover_image": [{"url": "https://q9.itc.cn/q_70/images03/20241013/d770472d4906402c866b9c71a0c9927c.jpeg"}],
      "content": "文章内容...",
      "status": "published",
      "view_count": 100,
      "like_count": 10,
      "create_time": "2025-01-15T10:30:45.000Z",
      "update_time": "2025-01-15T10:30:45.000Z"
    }
  ],
  "pagination": {
    "page": 1,
    "limit": 10,
    "total": 1,
    "pages": 1
  },
  "timestamp": "2025-01-15T10:30:45.123Z"
}
```

### 应用管理接口

#### 获取应用列表
**GET** `/api/apps?page=1&limit=10&search=微信&app_type=社交&user_id=1`

**返回示例：**
```json
{
  "code": 200,
  "message": "获取成功",
  "data": [
    {
      "id": 1,
      "user_id": 1,
      "package_name": "package.hmApp.weChat.weChat.weChat",
      "app_name": "微信",
      "description": "这是一个微信应用的包这是一个微信应用的包这是一个微信应用的包这是一个微信应用的包这是一个微信应用的包",
      "app_logo": "https://q9.itc.cn/q_70/images03/20241013/d770472d4906402c866b9c71a0c9927c.jpeg",
      "app_dev_type": "原始应用",
      "update_info": "修复了一些bug，优化了性能",
      "app_version": "1.0.0",
      "app_size": "150MB",
      "downloads": 10000,
      "app_url": "https://example.com/wechat.hap",
      "app_type": "社交",
      "app_screenshot": [
        "https://q9.itc.cn/q_70/images03/20241013/d770472d4906402c866b9c71a0c9927c.jpeg",
        "https://q9.itc.cn/q_70/images03/20241013/d770472d4906402c866b9c71a0c9927c.jpeg"
      ],
      "status": "active",
      "create_time": "2025-01-15T10:30:45.000Z",
      "update_time": "2025-01-15T10:30:45.000Z",
      "username": "admin",
      "nickname": "系统管理员",
      "avatar": "https://q9.itc.cn/q_70/images03/20241013/d770472d4906402c866b9c71a0c9927c.jpeg"
    }
  ],
  "pagination": {
    "page": 1,
    "limit": 10,
    "total": 1,
    "pages": 1
  },
  "timestamp": "2025-01-15T10:30:45.123Z"
}
```

#### 获取应用详情
**GET** `/api/apps/1`

**返回示例：**
```json
{
  "code": 200,
  "message": "操作成功",
  "data": {
    "id": 1,
    "user_id": 1,
    "package_name": "package.hmApp.weChat.weChat.weChat",
    "app_name": "微信",
    "description": "这是一个微信应用的包这是一个微信应用的包这是一个微信应用的包这是一个微信应用的包这是一个微信应用的包",
    "app_logo": "https://q9.itc.cn/q_70/images03/20241013/d770472d4906402c866b9c71a0c9927c.jpeg",
    "app_dev_type": "原始应用",
    "update_info": "修复了一些bug，优化了性能",
    "app_version": "1.0.0",
    "app_size": "150MB",
    "downloads": 10000,
    "app_url": "https://example.com/wechat.hap",
    "app_type": "社交",
    "app_screenshot": [
      "https://q9.itc.cn/q_70/images03/20241013/d770472d4906402c866b9c71a0c9927c.jpeg",
      "https://q9.itc.cn/q_70/images03/20241013/d770472d4906402c866b9c71a0c9927c.jpeg"
    ],
    "status": "active",
    "create_time": "2025-01-15T10:30:45.000Z",
    "update_time": "2025-01-15T10:30:45.000Z",
    "username": "admin",
    "nickname": "系统管理员",
    "avatar": "https://q9.itc.cn/q_70/images03/20241013/d770472d4906402c866b9c71a0c9927c.jpeg"
  },
  "timestamp": "2025-01-15T10:30:45.123Z"
}
```

#### 创建应用
**POST** `/api/apps`

**请求示例：**
```json
{
  "package_name": "com.example.myapp",
  "app_name": "我的应用",
  "description": "这是一个测试应用",
  "app_logo": "https://example.com/logo.png",
  "app_dev_type": "原创应用",
  "update_info": "首次发布",
  "app_version": "1.0.0",
  "app_size": "50MB",
  "app_url": "https://example.com/myapp.hap",
  "app_type": "工具",
  "app_screenshot": [
    "https://example.com/screenshot1.jpg",
    "https://example.com/screenshot2.jpg"
  ]
}
```

**返回示例：**
```json
{
  "code": 200,
  "message": "应用创建成功",
  "data": {
    "id": 2,
    "package_name": "com.example.myapp",
    "app_name": "我的应用"
  },
  "timestamp": "2025-01-15T10:30:45.123Z"
}
```

#### 更新应用
**PUT** `/api/apps/1`

**请求示例：**
```json
{
  "app_name": "更新后的应用名",
  "app_version": "1.1.0",
  "update_info": "修复了一些问题，新增了功能"
}
```

**返回示例：**
```json
{
  "code": 200,
  "message": "应用更新成功",
  "data": null,
  "timestamp": "2025-01-15T10:30:45.123Z"
}
```

#### 删除应用
**DELETE** `/api/apps/1`

**返回示例：**
```json
{
  "code": 200,
  "message": "应用删除成功",
  "data": null,
  "timestamp": "2025-01-15T10:30:45.123Z"
}
```

#### 增加下载量
**POST** `/api/apps/1/download`

**返回示例：**
```json
{
  "code": 200,
  "message": "下载量更新成功",
  "data": null,
  "timestamp": "2025-01-15T10:30:45.123Z"
}
```

### 待办事项接口

#### 获取待办事项列表
**GET** `/api/todos?page=1&limit=10&search=项目&status=pending&priority=high`

**返回示例：**
```json
{
  "code": 200,
  "message": "获取成功",
  "data": [
    {
      "id": 1,
      "user_id": 1,
      "title": "完成项目设计",
      "description": "完成React待办事项应用的设计稿",
      "status": "pending",
      "priority": "high",
      "due_date": "2025-06-01",
      "completed_time": null,
      "create_time": "2025-01-15T10:30:45.000Z",
      "update_time": "2025-01-15T10:30:45.000Z"
    }
  ],
  "pagination": {
    "page": 1,
    "limit": 10,
    "total": 1,
    "pages": 1
  },
  "timestamp": "2025-01-15T10:30:45.123Z"
}
```

#### 获取待办事项详情
**GET** `/api/todos/1`

**返回示例：**
```json
{
  "code": 200,
  "message": "操作成功",
  "data": {
    "id": 1,
    "user_id": 1,
    "title": "完成项目设计",
    "description": "完成React待办事项应用的设计稿",
    "status": "pending",
    "priority": "high",
    "due_date": "2025-06-01",
    "completed_time": null,
    "create_time": "2025-01-15T10:30:45.000Z",
    "update_time": "2025-01-15T10:30:45.000Z"
  },
  "timestamp": "2025-01-15T10:30:45.123Z"
}
```

#### 创建待办事项
**POST** `/api/todos`

**请求示例：**
```json
{
  "title": "新的待办事项",
  "description": "这是一个新的待办事项描述",
  "status": "pending",
  "priority": "medium",
  "due_date": "2025-06-15"
}
```

**返回示例：**
```json
{
  "code": 200,
  "message": "待办事项创建成功",
  "data": {
    "id": 3,
    "title": "新的待办事项",
    "status": "pending"
  },
  "timestamp": "2025-01-15T10:30:45.123Z"
}
```

#### 更新待办事项
**PUT** `/api/todos/1`

**请求示例：**
```json
{
  "title": "更新后的标题",
  "status": "completed",
  "priority": "high"
}
```

**返回示例：**
```json
{
  "code": 200,
  "message": "待办事项更新成功",
  "data": null,
  "timestamp": "2025-01-15T10:30:45.123Z"
}
```

#### 删除待办事项
**DELETE** `/api/todos/1`

**返回示例：**
```json
{
  "code": 200,
  "message": "待办事项删除成功",
  "data": null,
  "timestamp": "2025-01-15T10:30:45.123Z"
}
```

#### 批量更新状态
**PUT** `/api/todos/batch/status`

**请求示例：**
```json
{
  "ids": [1, 2, 3],
  "status": "completed"
}
```

**返回示例：**
```json
{
  "code": 200,
  "message": "成功更新 3 个待办事项",
  "data": {
    "updated": 3
  },
  "timestamp": "2025-01-15T10:30:45.123Z"
}
```

### 留言管理接口

#### 获取留言列表（管理员）
**GET** `/api/messages?page=1&limit=10&search=牛逼&content_type=message&status=unread`

**返回示例：**
```json
{
  "code": 200,
  "message": "获取成功",
  "data": [
    {
      "id": 1,
      "user_id": 1,
      "content": "太牛逼了",
      "content_type": "message",
      "status": "unread",
      "reply_content": null,
      "reply_time": null,
      "create_time": "2025-01-15T10:30:45.000Z",
      "username": "admin",
      "nickname": "系统管理员",
      "avatar": "https://q9.itc.cn/q_70/images03/20241013/d770472d4906402c866b9c71a0c9927c.jpeg"
    }
  ],
  "pagination": {
    "page": 1,
    "limit": 10,
    "total": 1,
    "pages": 1
  },
  "timestamp": "2025-01-15T10:30:45.123Z"
}
```

#### 获取留言详情
**GET** `/api/messages/1`

**返回示例：**
```json
{
  "code": 200,
  "message": "操作成功",
  "data": {
    "id": 1,
    "user_id": 1,
    "content": "太牛逼了",
    "content_type": "message",
    "status": "unread",
    "reply_content": null,
    "reply_time": null,
    "create_time": "2025-01-15T10:30:45.000Z",
    "username": "admin",
    "nickname": "系统管理员",
    "avatar": "https://q9.itc.cn/q_70/images03/20241013/d770472d4906402c866b9c71a0c9927c.jpeg"
  },
  "timestamp": "2025-01-15T10:30:45.123Z"
}
```

#### 创建留言
**POST** `/api/messages`

**请求示例：**
```json
{
  "content": "这是一条新的留言",
  "content_type": "feedback"
}
```

**返回示例：**
```json
{
  "code": 200,
  "message": "留言提交成功",
  "data": {
    "id": 2,
    "content": "这是一条新的留言",
    "content_type": "feedback"
  },
  "timestamp": "2025-01-15T10:30:45.123Z"
}
```

#### 回复留言（管理员）
**PUT** `/api/messages/1/reply`

**请求示例：**
```json
{
  "reply_content": "感谢您的反馈，我们会继续努力！"
}
```

**返回示例：**
```json
{
  "code": 200,
  "message": "回复成功",
  "data": null,
  "timestamp": "2025-01-15T10:30:45.123Z"
}
```

#### 更新留言状态（管理员）
**PUT** `/api/messages/1/status`

**请求示例：**
```json
{
  "status": "read"
}
```

**返回示例：**
```json
{
  "code": 200,
  "message": "状态更新成功",
  "data": null,
  "timestamp": "2025-01-15T10:30:45.123Z"
}
```

#### 删除留言
**DELETE** `/api/messages/1`

**返回示例：**
```json
{
  "code": 200,
  "message": "留言删除成功",
  "data": null,
  "timestamp": "2025-01-15T10:30:45.123Z"
}
```

### 系统通知接口

#### 获取通知列表
**GET** `/api/notifications?page=1&limit=10&search=系统&type=system`

**返回示例：**
```json
{
  "code": 200,
  "message": "获取成功",
  "data": [
    {
      "id": 1,
      "title": "系统维护通知",
      "content": "计划于2025-06-01 00:00至03:00进行系统升级,\n请提前做好备份,避免数据丢失,感谢您的理解与支持。",
      "publisher": "系统管理员",
      "type": "maintenance",
      "status": "active",
      "create_time": "2025-01-15T10:30:45.000Z",
      "update_time": "2025-01-15T10:30:45.000Z"
    }
  ],
  "pagination": {
    "page": 1,
    "limit": 10,
    "total": 1,
    "pages": 1
  },
  "timestamp": "2025-01-15T10:30:45.123Z"
}
```

#### 获取通知详情
**GET** `/api/notifications/1`

**返回示例：**
```json
{
  "code": 200,
  "message": "操作成功",
  "data": {
    "id": 1,
    "title": "系统维护通知",
    "content": "计划于2025-06-01 00:00至03:00进行系统升级,\n请提前做好备份,避免数据丢失,感谢您的理解与支持。",
    "publisher": "系统管理员",
    "type": "maintenance",
    "status": "active",
    "create_time": "2025-01-15T10:30:45.000Z",
    "update_time": "2025-01-15T10:30:45.000Z"
  },
  "timestamp": "2025-01-15T10:30:45.123Z"
}
```

#### 创建通知（管理员）
**POST** `/api/notifications`

**请求示例：**
```json
{
  "title": "新功能发布",
  "content": "我们发布了新的功能，包括：\n1. 优化了用户界面\n2. 提升了系统性能\n3. 修复了已知问题",
  "type": "feature",
  "publisher": "产品团队"
}
```

**返回示例：**
```json
{
  "code": 200,
  "message": "通知创建成功",
  "data": {
    "id": 3,
    "title": "新功能发布",
    "type": "feature"
  },
  "timestamp": "2025-01-15T10:30:45.123Z"
}
```

#### 更新通知（管理员）
**PUT** `/api/notifications/1`

**请求示例：**
```json
{
  "title": "更新后的通知标题",
  "content": "更新后的通知内容",
  "status": "active"
}
```

**返回示例：**
```json
{
  "code": 200,
  "message": "通知更新成功",
  "data": null,
  "timestamp": "2025-01-15T10:30:45.123Z"
}
```

#### 删除通知（管理员）
**DELETE** `/api/notifications/1`

**返回示例：**
```json
{
  "code": 200,
  "message": "通知删除成功",
  "data": null,
  "timestamp": "2025-01-15T10:30:45.123Z"
}
```

### 仪表板接口

#### 获取首页统计数据
**GET** `/api/dashboard/stats`

**返回示例：**
```json
{
  "code": 200,
  "message": "操作成功",
  "data": {
    "articleCount": 15,
    "snippetCount": 8,
    "packageCount": 12,
    "unreadMessages": 3,
    "systemInfo": {
      "version": "v5.1.3",
      "status": "运行正常",
      "lastUpdate": "2025-05-28",
      "uptime": 86400,
      "nodeVersion": "v16.20.0",
      "platform": "linux",
      "memory": {
        "used": 128,
        "total": 256
      }
    },
    "userStats": {
      "myContents": 5,
      "myApps": 2,
      "pendingTodos": 3,
      "myMessages": 1
    }
  },
  "timestamp": "2025-01-15T10:30:45.123Z"
}
```

#### 获取内容趋势数据
**GET** `/api/dashboard/trends/content?days=7`

**返回示例：**
```json
{
  "code": 200,
  "message": "操作成功",
  "data": [
    {
      "date": "2025-01-09",
      "total": 5,
      "articles": 3,
      "questions": 1,
      "snippets": 1
    },
    {
      "date": "2025-01-10",
      "total": 8,
      "articles": 5,
      "questions": 2,
      "snippets": 1
    }
  ],
  "timestamp": "2025-01-15T10:30:45.123Z"
}
```

#### 获取用户活跃度数据
**GET** `/api/dashboard/trends/users?days=7`

**返回示例：**
```json
{
  "code": 200,
  "message": "操作成功",
  "data": {
    "newUsers": [
      {
        "date": "2025-01-09",
        "new_users": 2
      },
      {
        "date": "2025-01-10",
        "new_users": 3
      }
    ],
    "activeUsers": [
      {
        "date": "2025-01-09",
        "active_users": 15
      },
      {
        "date": "2025-01-10",
        "active_users": 18
      }
    ]
  },
  "timestamp": "2025-01-15T10:30:45.123Z"
}
```

#### 获取热门内容
**GET** `/api/dashboard/popular/content?limit=5&type=article`

**返回示例：**
```json
{
  "code": 200,
  "message": "操作成功",
  "data": [
    {
      "id": 1,
      "title": "热门文章标题",
      "content_type": "article",
      "view_count": 1500,
      "like_count": 120,
      "create_time": "2025-01-15T10:30:45.000Z",
      "username": "admin",
      "nickname": "系统管理员",
      "avatar": "https://q9.itc.cn/q_70/images03/20241013/d770472d4906402c866b9c71a0c9927c.jpeg"
    }
  ],
  "timestamp": "2025-01-15T10:30:45.123Z"
}
```

#### 获取热门应用
**GET** `/api/dashboard/popular/apps?limit=5`

**返回示例：**
```json
{
  "code": 200,
  "message": "操作成功",
  "data": [
    {
      "id": 1,
      "app_name": "微信",
      "package_name": "package.hmApp.weChat.weChat.weChat",
      "app_logo": "https://q9.itc.cn/q_70/images03/20241013/d770472d4906402c866b9c71a0c9927c.jpeg",
      "downloads": 10000,
      "create_time": "2025-01-15T10:30:45.000Z",
      "username": "admin",
      "nickname": "系统管理员"
    }
  ],
  "timestamp": "2025-01-15T10:30:45.123Z"
}
```

#### 获取系统健康状态
**GET** `/api/dashboard/health`

**返回示例：**
```json
{
  "code": 200,
  "message": "操作成功",
  "data": {
    "status": "healthy",
    "timestamp": "2025-01-15T10:30:45.123Z",
    "uptime": 86400,
    "database": {
      "status": "healthy",
      "responseTime": 1703123456789
    },
    "system": {
      "memory": {
        "used": 128,
        "total": 256,
        "usage": 50
      },
      "cpu": {
        "user": 1000000,
        "system": 500000
      },
      "nodeVersion": "v16.20.0",
      "platform": "linux"
    }
  },
  "timestamp": "2025-01-15T10:30:45.123Z"
}
```

### 文件上传接口

#### 文件上传
**POST** `/api/upload`

**请求示例：**
```
Content-Type: multipart/form-data

file: [文件数据]
type: images
```

**返回示例：**
```json
{
  "code": 200,
  "message": "文件上传成功",
  "data": {
    "fileName": "1703123456789_abc123def.jpg",
    "originalName": "avatar.jpg",
    "fileType": "images",
    "size": 102400,
    "url": "/uploads/images/1703123456789_abc123def.jpg",
    "fullUrl": "http://localhost:3000/uploads/images/1703123456789_abc123def.jpg"
  },
  "timestamp": "2025-01-15T10:30:45.123Z"
}
```

#### 批量文件上传
**POST** `/api/upload/batch`

**请求示例：**
```
Content-Type: multipart/form-data

files: [文件数据1, 文件数据2, ...]
type: images
```

**返回示例：**
```json
{
  "code": 200,
  "message": "批量上传完成，成功2个，失败0个",
  "data": {
    "files": [
      {
        "fileName": "1703123456789_0_abc123def.jpg",
        "originalName": "image1.jpg",
        "fileType": "images",
        "size": 102400,
        "url": "/uploads/images/1703123456789_0_abc123def.jpg",
        "fullUrl": "http://localhost:3000/uploads/images/1703123456789_0_abc123def.jpg"
      },
      {
        "fileName": "1703123456789_1_def456ghi.jpg",
        "originalName": "image2.jpg",
        "fileType": "images",
        "size": 204800,
        "url": "/uploads/images/1703123456789_1_def456ghi.jpg",
        "fullUrl": "http://localhost:3000/uploads/images/1703123456789_1_def456ghi.jpg"
      }
    ],
    "errors": [],
    "summary": {
      "total": 2,
      "success": 2,
      "failed": 0
    }
  },
  "timestamp": "2025-01-15T10:30:45.123Z"
}
```

#### 删除文件
**DELETE** `/api/upload/images/1703123456789_abc123def.jpg`

**返回示例：**
```json
{
  "code": 200,
  "message": "文件删除成功",
  "data": null,
  "timestamp": "2025-01-15T10:30:45.123Z"
}
```

#### 获取文件列表
**GET** `/api/upload/images?page=1&limit=20`

**返回示例：**
```json
{
  "code": 200,
  "message": "操作成功",
  "data": {
    "files": [
      {
        "fileName": "1703123456789_abc123def.jpg",
        "size": 102400,
        "createTime": "2025-01-15T10:30:45.000Z",
        "modifyTime": "2025-01-15T10:30:45.000Z",
        "url": "/uploads/images/1703123456789_abc123def.jpg",
        "fullUrl": "http://localhost:3000/uploads/images/1703123456789_abc123def.jpg"
      }
    ],
    "pagination": {
      "page": 1,
      "limit": 20,
      "total": 1,
      "pages": 1
    }
  },
  "timestamp": "2025-01-15T10:30:45.123Z"
}
```

#### 获取文件信息
**GET** `/api/upload/images/1703123456789_abc123def.jpg/info`

**返回示例：**
```json
{
  "code": 200,
  "message": "操作成功",
  "data": {
    "fileName": "1703123456789_abc123def.jpg",
    "type": "images",
    "size": 102400,
    "extension": ".jpg",
    "createTime": "2025-01-15T10:30:45.000Z",
    "modifyTime": "2025-01-15T10:30:45.000Z",
    "url": "/uploads/images/1703123456789_abc123def.jpg",
    "fullUrl": "http://localhost:3000/uploads/images/1703123456789_abc123def.jpg"
  },
  "timestamp": "2025-01-15T10:30:45.123Z"
}
```

## TCP调试服务

TCP服务默认运行在8888端口，支持以下功能：

### 连接管理
- 客户端连接/断开监控
- 连接超时处理
- 心跳检测

### 命令执行
- ADB命令执行
- HDC命令执行
- 命令队列管理
- 并发控制
- 实时输出流

### 设备管理
- 设备列表获取
- 设备状态监控

### 消息格式
```json
{
  "type": "adb_command",
  "command": "shell",
  "args": ["ls", "/"],
  "timeout": 30000
}
```

## 安全特性

### 认证与授权
- JWT Token认证
- 角色权限控制
- 会话管理

### 数据安全
- 密码加密存储
- SQL注入防护
- XSS防护
- 数据验证

### 请求安全
- 请求频率限制
- CORS配置
- 安全头设置
- 文件上传限制

## 性能优化

### 数据库优化
- 连接池管理
- 索引优化
- 查询优化

### 缓存策略
- 内存缓存
- 分层缓存
- 缓存装饰器

### 并发控制
- 集群模式
- 负载均衡
- 资源限制

## 监控与日志

### 日志系统
- 分级日志记录
- 文件日志轮转
- 请求日志追踪

### 系统监控
- 健康检查
- 性能监控
- 错误追踪

### 统计分析
- 用户行为统计
- 内容趋势分析
- 系统使用情况

## 部署指南

### Docker部署
```dockerfile
FROM node:16-alpine
WORKDIR /app
COPY package*.json ./
RUN npm install --production
COPY . .
EXPOSE 3000 8888
CMD ["npm", "start"]
```

### Nginx配置
```nginx
server {
    listen 80;
    server_name your-domain.com;
    
    location / {
        proxy_pass http://localhost:3000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    }
    
    location /uploads/ {
        alias /path/to/uploads/;
        expires 1y;
        add_header Cache-Control "public, immutable";
    }
}
```

## 开发指南

### 代码规范
- 使用ESLint进行代码检查
- 遵循RESTful API设计规范
- 统一错误处理机制
- 完善的注释文档

### 测试
```bash
npm test
```

### 贡献指南
1. Fork项目
2. 创建功能分支
3. 提交更改
4. 推送到分支
5. 创建Pull Request

## 许可证

MIT License

## 联系方式

如有问题或建议，请通过以下方式联系：
- 邮箱: your-email@example.com
- 项目地址: https://github.com/your-repo/nodejs-backend-system

## 更新日志

### v1.0.0
- 初始版本发布
- 完整的用户认证系统
- 内容管理功能
- 应用管理功能
- 待办事项系统
- 留言系统
- 系统通知
- TCP调试服务
- 文件上传功能
- 数据统计与监控
