import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import { useAuth } from './contexts/AuthContext';
import { useTheme } from './contexts/ThemeContext';
import Layout from './components/Layout';
import Login from './pages/Auth/Login';
import Register from './pages/Auth/Register';
import Dashboard from './pages/Dashboard';
import ContentList from './pages/Content/ContentList';
import ContentDetail from './pages/Content/ContentDetail';
import ContentEdit from './pages/Content/ContentEdit';
import NotificationList from './pages/Notification/NotificationList';
import NotificationDetail from './pages/Notification/NotificationDetail';
import NotificationEdit from './pages/Notification/NotificationEdit';
import TodoList from './pages/Todo/TodoList';
import TodoDetail from './pages/Todo/TodoDetail';
import TodoEdit from './pages/Todo/TodoEdit';
import Profile from './pages/Profile/Profile';
import UserCenter from './pages/User/UserCenter';
import UserDetail from './pages/User/UserDetail';
import UserEdit from './pages/User/UserEdit';
import './styles/App.scss';

function App() {
  const { user, loading } = useAuth();
  const { theme } = useTheme();

  if (loading) {
    return <div className="loading">系统加载中...</div>;
  }

  return (
    <div className={`app ${theme}`}>
      <Routes>
        <Route path="/login" element={!user ? <Login /> : <Navigate to="/dashboard" />} />
        <Route path="/register" element={!user ? <Register /> : <Navigate to="/dashboard" />} />
        <Route path="/" element={user ? <Layout /> : <Navigate to="/login" />}>
          <Route index element={<Navigate to="/dashboard" />} />
          <Route path="dashboard" element={<Dashboard />} />
          <Route path="content">
            <Route index element={<ContentList />} />
            <Route path=":type" element={<ContentList />} />
            <Route path=":type/:id" element={<ContentDetail />} />
            <Route path=":type/:id/edit" element={<ContentEdit />} />
            <Route path=":type/create" element={<ContentEdit />} />
          </Route>
          <Route path="notifications">
            <Route index element={<NotificationList />} />
            <Route path=":id" element={<NotificationDetail />} />
            <Route path=":id/edit" element={<NotificationEdit />} />
            <Route path="create" element={<NotificationEdit />} />
          </Route>
          <Route path="todos">
            <Route index element={<TodoList />} />
            <Route path=":id" element={<TodoDetail />} />
            <Route path=":id/edit" element={<TodoEdit />} />
            <Route path="create" element={<TodoEdit />} />
          </Route>
          <Route path="profile" element={<Profile />} />
          <Route path="users">
            <Route index element={<UserCenter />} />
            <Route path=":id" element={<UserDetail />} />
            <Route path=":id/edit" element={<UserEdit />} />
            <Route path="create" element={<UserEdit />} />
          </Route>
        </Route>
      </Routes>
    </div>
  );
}

export default App;
