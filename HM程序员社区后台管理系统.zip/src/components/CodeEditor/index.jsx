import React from 'react';
import Editor from '@monaco-editor/react';
import { useTheme } from '../../contexts/ThemeContext';
import './index.scss';

const CodeEditor = ({ 
  value, 
  onChange, 
  language = 'javascript', 
  height = 400,
  options = {}
}) => {
  const { isDark } = useTheme();

  const defaultOptions = {
    minimap: { enabled: false },
    fontSize: 14,
    lineNumbers: 'on',
    roundedSelection: false,
    scrollBeyondLastLine: false,
    automaticLayout: true,
    tabSize: 2,
    wordWrap: 'on',
    ...options
  };

  return (
    <div className="code-editor">
      <Editor
        height={height}
        language={language}
        value={value}
        onChange={onChange}
        theme={isDark ? 'vs-dark' : 'light'}
        options={defaultOptions}
      />
    </div>
  );
};

export default CodeEditor;
