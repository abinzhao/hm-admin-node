import React, { useState } from 'react';
import { Outlet, useNavigate, useLocation } from 'react-router-dom';
import {
  Layout as AntLayout,
  Menu,
  Avatar,
  Dropdown,
  Switch,
  Badge,
  Button,
  Drawer
} from 'antd';
import {
  DashboardOutlined,
  FileTextOutlined,
  BellOutlined,
  CheckSquareOutlined,
  UserOutlined,
  TeamOutlined,
  SettingOutlined,
  LogoutOutlined,
  SunOutlined,
  MoonOutlined,
  MenuOutlined
} from '@ant-design/icons';
import { useAuth } from '../../contexts/AuthContext';
import { useTheme } from '../../contexts/ThemeContext';
import './index.scss';

const { Header, Sider, Content } = AntLayout;

const Layout = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { user, logout, isAdmin } = useAuth();
  const { theme, toggleTheme, isDark } = useTheme();
  const [collapsed, setCollapsed] = useState(false);
  const [mobileMenuVisible, setMobileMenuVisible] = useState(false);

  const menuItems = [
    {
      key: '/dashboard',
      icon: <DashboardOutlined />,
      label: '概览首页'
    },
    {
      key: '/content',
      icon: <FileTextOutlined />,
      label: '内容管理',
      children: [
        { key: '/content/articles', label: '文章管理' },
        { key: '/content/questions', label: '问答管理' },
        { key: '/content/snippets', label: '代码片段' },
        { key: '/content/software', label: '软件管理' }
      ]
    },
    {
      key: '/notifications',
      icon: <BellOutlined />,
      label: '系统通知'
    },
    {
      key: '/todos',
      icon: <CheckSquareOutlined />,
      label: '待办事项'
    }
  ];

  if (isAdmin) {
    menuItems.push({
      key: '/users',
      icon: <TeamOutlined />,
      label: '用户管理'
    });
  }

  const userMenuItems = [
    {
      key: 'profile',
      icon: <UserOutlined />,
      label: '个人中心',
      onClick: () => navigate('/profile')
    },
    {
      key: 'settings',
      icon: <SettingOutlined />,
      label: '系统设置'
    },
    {
      type: 'divider'
    },
    {
      key: 'logout',
      icon: <LogoutOutlined />,
      label: '退出登录',
      onClick: logout
    }
  ];

  const handleMenuClick = ({ key }) => {
    navigate(key);
    setMobileMenuVisible(false);
  };

  const siderContent = (
    <>
      <div className="logo">
        <div className="logo-icon">HM</div>
        {!collapsed && <span className="logo-text">程序员社区</span>}
      </div>
      <Menu
        theme="light"
        mode="inline"
        selectedKeys={[location.pathname]}
        items={menuItems}
        onClick={handleMenuClick}
        className="sidebar-menu"
      />
    </>
  );

  return (
    <AntLayout className="layout">
      {/* 桌面端侧边栏 */}
      <Sider
        trigger={null}
        collapsible
        collapsed={collapsed}
        className="desktop-sider"
        width={240}
        collapsedWidth={80}
      >
        {siderContent}
      </Sider>

      {/* 移动端抽屉菜单 */}
      <Drawer
        title="菜单"
        placement="left"
        onClose={() => setMobileMenuVisible(false)}
        open={mobileMenuVisible}
        className="mobile-drawer"
        width={240}
      >
        {siderContent}
      </Drawer>

      <AntLayout>
        <Header className={`header ${collapsed ? 'collapsed' : ''}`}>
          <div className="header-left">
            <Button
              type="text"
              icon={<MenuOutlined />}
              onClick={() => setCollapsed(!collapsed)}
              className="desktop-trigger"
            />
            <Button
              type="text"
              icon={<MenuOutlined />}
              onClick={() => setMobileMenuVisible(true)}
              className="mobile-trigger"
            />
          </div>

          <div className="header-right">
            <div className="theme-switch">
              <SunOutlined />
              <Switch
                checked={isDark}
                onChange={toggleTheme}
                size="small"
              />
              <MoonOutlined />
            </div>

            <Badge count={5} size="small">
              <Button
                type="text"
                icon={<BellOutlined />}
                onClick={() => navigate('/notifications')}
              />
            </Badge>

            <Dropdown
              menu={{ items: userMenuItems }}
              placement="bottomRight"
              trigger={['click']}
            >
              <div className="user-info">
                <Avatar src={user?.avatar} size="small">
                  {user?.name?.[0]}
                </Avatar>
                <span className="username">{user?.name}</span>
              </div>
            </Dropdown>
          </div>
        </Header>

        <Content className={`content ${collapsed ? 'collapsed' : ''}`}>
          <div className="content-wrapper">
            <Outlet />
          </div>
        </Content>
      </AntLayout>
    </AntLayout>
  );
};

export default Layout;
