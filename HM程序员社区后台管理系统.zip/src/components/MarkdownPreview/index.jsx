import React from 'react';
import MarkdownPreview from '@uiw/react-markdown-preview';
import '@uiw/react-markdown-preview/markdown.css';
import { useTheme } from '../../contexts/ThemeContext';
import './index.scss';

const MarkdownRenderer = ({ content, className = '' }) => {
  const { isDark } = useTheme();

  if (!content) {
    return <div className="markdown-empty">暂无内容</div>;
  }

  return (
    <div className={`markdown-preview ${className}`}>
      <MarkdownPreview
        source={content}
        data-color-mode={isDark ? 'dark' : 'light'}
        wrapperElement={{
          'data-color-mode': isDark ? 'dark' : 'light'
        }}
      />
    </div>
  );
};

export default MarkdownRenderer;
