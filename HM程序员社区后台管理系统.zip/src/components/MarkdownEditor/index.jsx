import React from 'react';
import MDEditor from '@uiw/react-md-editor';
import '@uiw/react-md-editor/markdown-editor.css';
import '@uiw/react-markdown-preview/markdown.css';
import './index.scss';

const MarkdownEditor = ({ value, onChange, height = 400, placeholder = '请输入内容...' }) => {
  return (
    <div className="markdown-editor">
      <MDEditor
        value={value}
        onChange={onChange}
        height={height}
        preview="edit"
        hideToolbar={false}
        visibleDragBar={false}
        data-color-mode="auto"
        placeholder={placeholder}
      />
    </div>
  );
};

export default MarkdownEditor;
