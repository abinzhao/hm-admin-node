import React from 'react';
import './index.scss';

const Loading = ({ 
  size = 'default', 
  text = '加载中...', 
  fullscreen = false,
  type = 'spinner' 
}) => {
  if (fullscreen) {
    return (
      <div className="page-loading">
        <div className="loading-logo">HM</div>
        <div className="loading-dots">
          <div className="dot"></div>
          <div className="dot"></div>
          <div className="dot"></div>
        </div>
        <div className="loading-text">{text}</div>
      </div>
    );
  }

  return (
    <div className={`loading ${size}`}>
      {type === 'spinner' && <div className="loading-spinner"></div>}
      {type === 'dots' && (
        <div className="loading-dots">
          <div className="dot"></div>
          <div className="dot"></div>
          <div className="dot"></div>
        </div>
      )}
      {text && <div className="loading-text">{text}</div>}
    </div>
  );
};

export default Loading;
