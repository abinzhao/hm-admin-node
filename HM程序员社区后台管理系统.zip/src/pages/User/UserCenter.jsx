import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Card,
  Table,
  Button,
  Input,
  Select,
  Space,
  Tag,
  Avatar,
  Popconfirm,
  message,
  Badge,
  Tooltip
} from 'antd';
import {
  PlusOutlined,
  SearchOutlined,
  EditOutlined,
  DeleteOutlined,
  EyeOutlined,
  UserOutlined,
  CrownOutlined,
  LockOutlined,
  UnlockOutlined
} from '@ant-design/icons';
import { useAuth } from '../../contexts/AuthContext';
import './UserCenter.scss';

const { Search } = Input;
const { Option } = Select;

const UserCenter = () => {
  const navigate = useNavigate();
  const { user, isAdmin } = useAuth();
  const [loading, setLoading] = useState(false);
  const [searchText, setSearchText] = useState('');
  const [roleFilter, setRoleFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState('all');
  const [data, setData] = useState([]);

  const mockData = [
    {
      id: 1,
      username: 'admin',
      name: '系统管理员',
      email: 'admin@hm.com',
      role: 'admin',
      status: 'active',
      avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=40&h=40&fit=crop&crop=face',
      lastLogin: '2024-01-16 14:30:00',
      createdAt: '2024-01-01 10:00:00',
      articlesCount: 25,
      questionsCount: 12,
      likesCount: 156
    },
    {
      id: 2,
      username: 'zhangsan',
      name: '张三',
      email: 'zhangsan@hm.com',
      role: 'user',
      status: 'active',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=40&h=40&fit=crop&crop=face',
      lastLogin: '2024-01-16 10:15:00',
      createdAt: '2024-01-05 14:20:00',
      articlesCount: 8,
      questionsCount: 15,
      likesCount: 89
    },
    {
      id: 3,
      username: 'lisi',
      name: '李四',
      email: 'lisi@hm.com',
      role: 'user',
      status: 'inactive',
      avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=40&h=40&fit=crop&crop=face',
      lastLogin: '2024-01-10 16:45:00',
      createdAt: '2024-01-03 09:30:00',
      articlesCount: 3,
      questionsCount: 7,
      likesCount: 23
    },
    {
      id: 4,
      username: 'wangwu',
      name: '王五',
      email: 'wangwu@hm.com',
      role: 'user',
      status: 'banned',
      avatar: 'https://images.unsplash.com/photo-1519244703995-f4e0f30006d5?w=40&h=40&fit=crop&crop=face',
      lastLogin: '2024-01-08 11:20:00',
      createdAt: '2024-01-02 16:10:00',
      articlesCount: 1,
      questionsCount: 2,
      likesCount: 5
    }
  ];

  useEffect(() => {
    if (!isAdmin) {
      message.error('您没有权限访问此页面');
      navigate('/dashboard');
      return;
    }

    setLoading(true);
    setTimeout(() => {
      setData(mockData);
      setLoading(false);
    }, 500);
  }, [isAdmin, navigate]);

  const getRoleTag = (role) => {
    const roleMap = {
      admin: { color: 'red', text: '管理员', icon: <CrownOutlined /> },
      user: { color: 'blue', text: '普通用户', icon: <UserOutlined /> }
    };
    const roleInfo = roleMap[role] || { color: 'default', text: role, icon: <UserOutlined /> };
    return (
      <Tag color={roleInfo.color} icon={roleInfo.icon}>
        {roleInfo.text}
      </Tag>
    );
  };

  const getStatusTag = (status) => {
    const statusMap = {
      active: { color: 'green', text: '正常' },
      inactive: { color: 'orange', text: '未激活' },
      banned: { color: 'red', text: '已封禁' }
    };
    const statusInfo = statusMap[status] || { color: 'default', text: status };
    return <Tag color={statusInfo.color}>{statusInfo.text}</Tag>;
  };

  const handleDelete = (id, username) => {
    if (username === 'admin') {
      message.error('不能删除管理员账户');
      return;
    }
    setData(data.filter(item => item.id !== id));
    message.success('用户删除成功');
  };

  const handleToggleStatus = (id, currentStatus) => {
    const newStatus = currentStatus === 'banned' ? 'active' : 'banned';
    setData(data.map(item => 
      item.id === id 
        ? { ...item, status: newStatus }
        : item
    ));
    message.success(newStatus === 'banned' ? '用户已封禁' : '用户已解封');
  };

  const columns = [
    {
      title: '用户信息',
      dataIndex: 'name',
      key: 'name',
      render: (text, record) => (
        <div className="user-cell">
          <div className="user-header">
            <Avatar src={record.avatar} size="large">
              {record.name?.[0]}
            </Avatar>
            <div className="user-info">
              <div className="user-name">{text}</div>
              <div className="user-username">@{record.username}</div>
              <div className="user-email">{record.email}</div>
            </div>
          </div>
          <div className="user-stats">
            <span>文章: {record.articlesCount}</span>
            <span>问答: {record.questionsCount}</span>
            <span>获赞: {record.likesCount}</span>
          </div>
        </div>
      )
    },
    {
      title: '角色',
      dataIndex: 'role',
      key: 'role',
      width: 120,
      render: getRoleTag
    },
    {
      title: '状态',
      dataIndex: 'status',
      key: 'status',
      width: 100,
      render: getStatusTag
    },
    {
      title: '最后登录',
      dataIndex: 'lastLogin',
      key: 'lastLogin',
      width: 150,
      render: (time) => (
        <div className="time-cell">
          <div>{time.split(' ')[0]}</div>
          <div className="time-detail">{time.split(' ')[1]}</div>
        </div>
      )
    },
    {
      title: '注册时间',
      dataIndex: 'createdAt',
      key: 'createdAt',
      width: 150,
      render: (time) => (
        <div className="time-cell">
          <div>{time.split(' ')[0]}</div>
          <div className="time-detail">{time.split(' ')[1]}</div>
        </div>
      )
    },
    {
      title: '操作',
      key: 'actions',
      width: 200,
      render: (_, record) => (
        <Space>
          <Tooltip title="查看详情">
            <Button
              type="text"
              icon={<EyeOutlined />}
              onClick={() => navigate(`/users/${record.id}`)}
            />
          </Tooltip>
          <Tooltip title="编辑用户">
            <Button
              type="text"
              icon={<EditOutlined />}
              onClick={() => navigate(`/users/${record.id}/edit`)}
            />
          </Tooltip>
          <Tooltip title={record.status === 'banned' ? '解封用户' : '封禁用户'}>
            <Button
              type="text"
              icon={record.status === 'banned' ? <UnlockOutlined /> : <LockOutlined />}
              onClick={() => handleToggleStatus(record.id, record.status)}
              style={{ color: record.status === 'banned' ? '#52c41a' : '#ff4d4f' }}
            />
          </Tooltip>
          {record.username !== 'admin' && (
            <Popconfirm
              title="确定要删除该用户吗？"
              description="删除后将无法恢复，请谨慎操作"
              onConfirm={() => handleDelete(record.id, record.username)}
            >
              <Tooltip title="删除用户">
                <Button type="text" danger icon={<DeleteOutlined />} />
              </Tooltip>
            </Popconfirm>
          )}
        </Space>
      )
    }
  ];

  const filteredData = data.filter(item => {
    const matchSearch = item.name.toLowerCase().includes(searchText.toLowerCase()) ||
                       item.username.toLowerCase().includes(searchText.toLowerCase()) ||
                       item.email.toLowerCase().includes(searchText.toLowerCase());
    const matchRole = roleFilter === 'all' || item.role === roleFilter;
    const matchStatus = statusFilter === 'all' || item.status === statusFilter;
    
    return matchSearch && matchRole && matchStatus;
  });

  if (!isAdmin) {
    return null;
  }

  return (
    <div className="user-center">
      <Card className="user-header">
        <div className="header-top">
          <h2>用户管理</h2>
          <Button
            type="primary"
            icon={<PlusOutlined />}
            onClick={() => navigate('/users/create')}
          >
            新建用户
          </Button>
        </div>

        <div className="filters">
          <Search
            placeholder="搜索用户名、姓名或邮箱"
            value={searchText}
            onChange={(e) => setSearchText(e.target.value)}
            style={{ width: 300 }}
          />
          <Select
            value={roleFilter}
            onChange={setRoleFilter}
            style={{ width: 120 }}
          >
            <Option value="all">全部角色</Option>
            <Option value="admin">管理员</Option>
            <Option value="user">普通用户</Option>
          </Select>
          <Select
            value={statusFilter}
            onChange={setStatusFilter}
            style={{ width: 120 }}
          >
            <Option value="all">全部状态</Option>
            <Option value="active">正常</Option>
            <Option value="inactive">未激活</Option>
            <Option value="banned">已封禁</Option>
          </Select>
        </div>

        <div className="stats-summary">
          <div className="stat-item">
            <Badge count={data.length} showZero color="blue" />
            <span>总用户数</span>
          </div>
          <div className="stat-item">
            <Badge count={data.filter(u => u.status === 'active').length} showZero color="green" />
            <span>活跃用户</span>
          </div>
          <div className="stat-item">
            <Badge count={data.filter(u => u.role === 'admin').length} showZero color="red" />
            <span>管理员</span>
          </div>
        </div>
      </Card>

      <Card className="user-table">
        <Table
          columns={columns}
          dataSource={filteredData}
          loading={loading}
          rowKey="id"
          pagination={{
            total: filteredData.length,
            pageSize: 10,
            showSizeChanger: true,
            showQuickJumper: true,
            showTotal: (total) => `共 ${total} 个用户`
          }}
        />
      </Card>
    </div>
  );
};

export default UserCenter;
