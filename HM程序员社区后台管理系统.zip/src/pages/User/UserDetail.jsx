import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import {
  Card,
  Button,
  Avatar,
  Tag,
  Space,
  Divider,
  Row,
  Col,
  Statistic,
  Timeline,
  List,
  Tabs,
  message
} from 'antd';
import {
  ArrowLeftOutlined,
  EditOutlined,
  UserOutlined,
  MailOutlined,
  PhoneOutlined,
  EnvironmentOutlined,
  CalendarOutlined,
  CrownOutlined,
  LockOutlined,
  UnlockOutlined
} from '@ant-design/icons';
import { useAuth } from '../../contexts/AuthContext';
import './UserDetail.scss';

const UserDetail = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user: currentUser, isAdmin } = useAuth();
  const [loading, setLoading] = useState(false);
  const [userDetail, setUserDetail] = useState(null);

  const mockUser = {
    id: 2,
    username: 'zhangsan',
    name: '张三',
    email: 'zhangsan@hm.com',
    phone: '138****8888',
    role: 'user',
    status: 'active',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop&crop=face',
    bio: '热爱编程的前端开发工程师，专注于React和Vue技术栈，喜欢分享技术心得。',
    location: '北京市朝阳区',
    website: 'https://zhangsan.dev',
    lastLogin: '2024-01-16 10:15:00',
    createdAt: '2024-01-05 14:20:00',
    articlesCount: 8,
    questionsCount: 15,
    snippetsCount: 12,
    likesCount: 89,
    viewsCount: 2340,
    commentsCount: 156
  };

  const mockActivities = [
    {
      id: 1,
      type: 'article',
      title: '发布了文章《Vue 3 Composition API 实践》',
      time: '2024-01-16 09:30:00',
      status: 'published'
    },
    {
      id: 2,
      type: 'question',
      title: '回答了问题《React Hooks 最佳实践》',
      time: '2024-01-15 16:20:00',
      status: 'answered'
    },
    {
      id: 3,
      type: 'snippet',
      title: '分享了代码片段《深拷贝函数实现》',
      time: '2024-01-14 11:45:00',
      status: 'published'
    },
    {
      id: 4,
      type: 'login',
      title: '用户登录',
      time: '2024-01-14 08:30:00',
      status: 'success'
    }
  ];

  const mockContents = [
    {
      id: 1,
      type: 'article',
      title: 'Vue 3 Composition API 实践指南',
      views: 456,
      likes: 23,
      comments: 8,
      createdAt: '2024-01-16'
    },
    {
      id: 2,
      type: 'question',
      title: 'React Hooks 在项目中的应用问题',
      views: 234,
      likes: 12,
      comments: 15,
      createdAt: '2024-01-15'
    },
    {
      id: 3,
      type: 'snippet',
      title: '深拷贝函数的多种实现方式',
      views: 189,
      likes: 18,
      comments: 5,
      createdAt: '2024-01-14'
    }
  ];

  useEffect(() => {
    if (!isAdmin && currentUser?.id !== parseInt(id)) {
      message.error('您没有权限查看此用户信息');
      navigate('/dashboard');
      return;
    }

    setLoading(true);
    setTimeout(() => {
      setUserDetail(mockUser);
      setLoading(false);
    }, 500);
  }, [id, isAdmin, currentUser, navigate]);

  const getRoleTag = (role) => {
    const roleMap = {
      admin: { color: 'red', text: '管理员', icon: <CrownOutlined /> },
      user: { color: 'blue', text: '普通用户', icon: <UserOutlined /> }
    };
    const roleInfo = roleMap[role] || { color: 'default', text: role, icon: <UserOutlined /> };
    return (
      <Tag color={roleInfo.color} icon={roleInfo.icon} style={{ fontSize: '14px', padding: '4px 12px' }}>
        {roleInfo.text}
      </Tag>
    );
  };

  const getStatusTag = (status) => {
    const statusMap = {
      active: { color: 'green', text: '正常' },
      inactive: { color: 'orange', text: '未激活' },
      banned: { color: 'red', text: '已封禁' }
    };
    const statusInfo = statusMap[status] || { color: 'default', text: status };
    return (
      <Tag color={statusInfo.color} style={{ fontSize: '14px', padding: '4px 12px' }}>
        {statusInfo.text}
      </Tag>
    );
  };

  const getActivityIcon = (type) => {
    const icons = {
      article: '📝',
      question: '❓',
      snippet: '💻',
      login: '🔐'
    };
    return icons[type] || '📄';
  };

  const getContentTypeTag = (type) => {
    const typeMap = {
      article: { color: 'blue', text: '文章' },
      question: { color: 'green', text: '问答' },
      snippet: { color: 'orange', text: '代码' }
    };
    const typeInfo = typeMap[type] || { color: 'default', text: type };
    return <Tag color={typeInfo.color}>{typeInfo.text}</Tag>;
  };

  const handleToggleStatus = () => {
    const newStatus = userDetail.status === 'banned' ? 'active' : 'banned';
    setUserDetail({
      ...userDetail,
      status: newStatus
    });
    message.success(newStatus === 'banned' ? '用户已封禁' : '用户已解封');
  };

  if (loading || !userDetail) {
    return <div className="loading">加载中...</div>;
  }

  const tabItems = [
    {
      key: 'activities',
      label: '活动记录',
      children: (
        <Timeline>
          {mockActivities.map((activity) => (
            <Timeline.Item
              key={activity.id}
              dot={<span className="activity-icon">{getActivityIcon(activity.type)}</span>}
            >
              <div className="timeline-content">
                <div className="timeline-title">{activity.title}</div>
                <div className="timeline-time">{activity.time}</div>
              </div>
            </Timeline.Item>
          ))}
        </Timeline>
      )
    },
    {
      key: 'contents',
      label: '发布内容',
      children: (
        <List
          dataSource={mockContents}
          renderItem={(item) => (
            <List.Item>
              <div className="content-item">
                <div className="content-header">
                  {getContentTypeTag(item.type)}
                  <span className="content-title">{item.title}</span>
                </div>
                <div className="content-stats">
                  <span>👁 {item.views}</span>
                  <span>👍 {item.likes}</span>
                  <span>💬 {item.comments}</span>
                  <span>📅 {item.createdAt}</span>
                </div>
              </div>
            </List.Item>
          )}
        />
      )
    }
  ];

  return (
    <div className="user-detail">
      <Card className="detail-header">
        <div className="header-actions">
          <Button
            icon={<ArrowLeftOutlined />}
            onClick={() => navigate(-1)}
          >
            返回
          </Button>
          <Space>
            {isAdmin && userDetail.username !== 'admin' && (
              <Button
                icon={userDetail.status === 'banned' ? <UnlockOutlined /> : <LockOutlined />}
                onClick={handleToggleStatus}
                style={{ color: userDetail.status === 'banned' ? '#52c41a' : '#ff4d4f' }}
              >
                {userDetail.status === 'banned' ? '解封用户' : '封禁用户'}
              </Button>
            )}
            {(isAdmin || currentUser?.id === userDetail.id) && (
              <Button
                type="primary"
                icon={<EditOutlined />}
                onClick={() => navigate(`/users/${id}/edit`)}
              >
                编辑
              </Button>
            )}
          </Space>
        </div>

        <div className="user-profile">
          <div className="profile-main">
            <Avatar src={userDetail.avatar} size={120}>
              {userDetail.name?.[0]}
            </Avatar>
            <div className="profile-info">
              <h1>{userDetail.name}</h1>
              <div className="profile-meta">
                <span>@{userDetail.username}</span>
                <div className="profile-tags">
                  {getRoleTag(userDetail.role)}
                  {getStatusTag(userDetail.status)}
                </div>
              </div>
              {userDetail.bio && (
                <p className="profile-bio">{userDetail.bio}</p>
              )}
            </div>
          </div>

          <div className="profile-details">
            <div className="detail-item">
              <MailOutlined />
              <span>{userDetail.email}</span>
            </div>
            {userDetail.phone && (
              <div className="detail-item">
                <PhoneOutlined />
                <span>{userDetail.phone}</span>
              </div>
            )}
            {userDetail.location && (
              <div className="detail-item">
                <EnvironmentOutlined />
                <span>{userDetail.location}</span>
              </div>
            )}
            <div className="detail-item">
              <CalendarOutlined />
              <span>注册于 {userDetail.createdAt}</span>
            </div>
            <div className="detail-item">
              <CalendarOutlined />
              <span>最后登录 {userDetail.lastLogin}</span>
            </div>
          </div>
        </div>
      </Card>

      <Row gutter={[24, 24]}>
        <Col xs={24} lg={8}>
          <Card title="数据统计" className="stats-card">
            <Row gutter={[16, 16]}>
              <Col span={12}>
                <Statistic title="文章" value={userDetail.articlesCount} />
              </Col>
              <Col span={12}>
                <Statistic title="问答" value={userDetail.questionsCount} />
              </Col>
              <Col span={12}>
                <Statistic title="代码片段" value={userDetail.snippetsCount} />
              </Col>
              <Col span={12}>
                <Statistic title="获赞" value={userDetail.likesCount} />
              </Col>
              <Col span={12}>
                <Statistic title="浏览量" value={userDetail.viewsCount} />
              </Col>
              <Col span={12}>
                <Statistic title="评论" value={userDetail.commentsCount} />
              </Col>
            </Row>
          </Card>
        </Col>

        <Col xs={24} lg={16}>
          <Card className="activity-card">
            <Tabs items={tabItems} />
          </Card>
        </Col>
      </Row>
    </div>
  );
};

export default UserDetail;
