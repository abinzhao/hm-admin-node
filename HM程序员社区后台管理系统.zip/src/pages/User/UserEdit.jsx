import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import {
  Card,
  Form,
  Input,
  Button,
  Select,
  Space,
  message,
  Avatar,
  Upload,
  Switch,
  Row,
  Col
} from 'antd';
import {
  ArrowLeftOutlined,
  SaveOutlined,
  UserOutlined,
  MailOutlined,
  PhoneOutlined,
  UploadOutlined
} from '@ant-design/icons';
import { useAuth } from '../../contexts/AuthContext';
import './UserEdit.scss';

const { TextArea } = Input;
const { Option } = Select;

const UserEdit = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user: currentUser, isAdmin } = useAuth();
  const [form] = Form.useForm();
  const [loading, setLoading] = useState(false);
  const [avatarUrl, setAvatarUrl] = useState('');

  const isEdit = !!id;
  const isCreating = !isEdit;
  const pageTitle = isEdit ? '编辑用户' : '创建用户';

  useEffect(() => {
    if (isEdit && !isAdmin && currentUser?.id !== parseInt(id)) {
      message.error('您没有权限编辑此用户信息');
      navigate('/dashboard');
      return;
    }

    if (isCreating && !isAdmin) {
      message.error('您没有权限创建用户');
      navigate('/dashboard');
      return;
    }

    if (isEdit) {
      setLoading(true);
      setTimeout(() => {
        const mockData = {
          username: 'zhangsan',
          name: '张三',
          email: 'zhangsan@hm.com',
          phone: '138****8888',
          role: 'user',
          status: 'active',
          bio: '热爱编程的前端开发工程师，专注于React和Vue技术栈。',
          location: '北京市朝阳区',
          website: 'https://zhangsan.dev'
        };
        
        form.setFieldsValue(mockData);
        setAvatarUrl('https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop&crop=face');
        setLoading(false);
      }, 500);
    }
  }, [id, form, isEdit, isAdmin, currentUser, navigate, isCreating]);

  const handleSubmit = async (values) => {
    setLoading(true);
    try {
      const submitData = {
        ...values,
        avatar: avatarUrl
      };
      
      console.log('提交数据:', submitData);
      
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      message.success(isEdit ? '用户信息更新成功！' : '用户创建成功！');
      navigate(isAdmin ? '/users' : '/profile');
    } catch (error) {
      message.error('操作失败，请重试');
    } finally {
      setLoading(false);
    }
  };

  const handleAvatarChange = (info) => {
    if (info.file.status === 'done') {
      setAvatarUrl(info.file.response?.url || '');
      message.success('头像上传成功！');
    } else if (info.file.status === 'error') {
      message.error('头像上传失败！');
    }
  };

  return (
    <div className="user-edit">
      <Card className="edit-header">
        <div className="header-actions">
          <Button
            icon={<ArrowLeftOutlined />}
            onClick={() => navigate(-1)}
          >
            返回
          </Button>
          <div className="header-title">
            <UserOutlined />
            <h2>{pageTitle}</h2>
          </div>
          <div></div>
        </div>
      </Card>

      <Card className="edit-form">
        <Form
          form={form}
          layout="vertical"
          onFinish={handleSubmit}
          initialValues={{
            role: 'user',
            status: 'active'
          }}
        >
          <div className="avatar-section">
            <Avatar src={avatarUrl} size={100} icon={<UserOutlined />} />
            <Upload
              showUploadList={false}
              beforeUpload={() => false}
              onChange={handleAvatarChange}
            >
              <Button icon={<UploadOutlined />}>更换头像</Button>
            </Upload>
          </div>

          <Row gutter={[24, 0]}>
            <Col xs={24} md={12}>
              <Form.Item
                name="username"
                label="用户名"
                rules={[
                  { required: true, message: '请输入用户名' },
                  { min: 3, message: '用户名至少3个字符' },
                  { pattern: /^[a-zA-Z0-9_]+$/, message: '用户名只能包含字母、数字和下划线' }
                ]}
              >
                <Input
                  prefix={<UserOutlined />}
                  placeholder="请输入用户名"
                  disabled={isEdit}
                />
              </Form.Item>
            </Col>
            <Col xs={24} md={12}>
              <Form.Item
                name="name"
                label="姓名"
                rules={[
                  { required: true, message: '请输入姓名' },
                  { min: 2, message: '姓名至少2个字符' }
                ]}
              >
                <Input
                  prefix={<UserOutlined />}
                  placeholder="请输入姓名"
                />
              </Form.Item>
            </Col>
          </Row>

          <Row gutter={[24, 0]}>
            <Col xs={24} md={12}>
              <Form.Item
                name="email"
                label="邮箱"
                rules={[
                  { required: true, message: '请输入邮箱' },
                  { type: 'email', message: '请输入有效的邮箱地址' }
                ]}
              >
                <Input
                  prefix={<MailOutlined />}
                  placeholder="请输入邮箱"
                />
              </Form.Item>
            </Col>
            <Col xs={24} md={12}>
              <Form.Item
                name="phone"
                label="手机号"
                rules={[
                  { pattern: /^1[3-9]\d{9}$/, message: '请输入有效的手机号' }
                ]}
              >
                <Input
                  prefix={<PhoneOutlined />}
                  placeholder="请输入手机号"
                />
              </Form.Item>
            </Col>
          </Row>

          {isCreating && (
            <Row gutter={[24, 0]}>
              <Col xs={24} md={12}>
                <Form.Item
                  name="password"
                  label="密码"
                  rules={[
                    { required: true, message: '请输入密码' },
                    { min: 6, message: '密码至少6个字符' }
                  ]}
                >
                  <Input.Password placeholder="请输入密码" />
                </Form.Item>
              </Col>
              <Col xs={24} md={12}>
                <Form.Item
                  name="confirmPassword"
                  label="确认密码"
                  dependencies={['password']}
                  rules={[
                    { required: true, message: '请确认密码' },
                    ({ getFieldValue }) => ({
                      validator(_, value) {
                        if (!value || getFieldValue('password') === value) {
                          return Promise.resolve();
                        }
                        return Promise.reject(new Error('两次输入的密码不一致'));
                      },
                    }),
                  ]}
                >
                  <Input.Password placeholder="请确认密码" />
                </Form.Item>
              </Col>
            </Row>
          )}

          {isAdmin && (
            <Row gutter={[24, 0]}>
              <Col xs={24} md={12}>
                <Form.Item
                  name="role"
                  label="用户角色"
                  rules={[{ required: true, message: '请选择用户角色' }]}
                >
                  <Select placeholder="请选择用户角色">
                    <Option value="user">👤 普通用户</Option>
                    <Option value="admin">👑 管理员</Option>
                  </Select>
                </Form.Item>
              </Col>
              <Col xs={24} md={12}>
                <Form.Item
                  name="status"
                  label="账户状态"
                  rules={[{ required: true, message: '请选择账户状态' }]}
                >
                  <Select placeholder="请选择账户状态">
                    <Option value="active">✅ 正常</Option>
                    <Option value="inactive">⏳ 未激活</Option>
                    <Option value="banned">🚫 已封禁</Option>
                  </Select>
                </Form.Item>
              </Col>
            </Row>
          )}

          <Row gutter={[24, 0]}>
            <Col xs={24} md={12}>
              <Form.Item
                name="location"
                label="所在地"
              >
                <Input placeholder="请输入所在地" />
              </Form.Item>
            </Col>
            <Col xs={24} md={12}>
              <Form.Item
                name="website"
                label="个人网站"
                rules={[
                  { type: 'url', message: '请输入有效的网址' }
                ]}
              >
                <Input placeholder="请输入个人网站" />
              </Form.Item>
            </Col>
          </Row>

          <Form.Item
            name="bio"
            label="个人简介"
          >
            <TextArea
              rows={4}
              placeholder="介绍一下自己吧..."
              maxLength={200}
              showCount
            />
          </Form.Item>

          <Form.Item>
            <Space size="large">
              <Button
                type="primary"
                htmlType="submit"
                loading={loading}
                icon={<SaveOutlined />}
                size="large"
              >
                {isEdit ? '更新用户' : '创建用户'}
              </Button>
              <Button
                size="large"
                onClick={() => navigate(-1)}
              >
                取消
              </Button>
            </Space>
          </Form.Item>
        </Form>
      </Card>
    </div>
  );
};

export default UserEdit;
