import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import {
  Card,
  Form,
  Input,
  Button,
  Select,
  Space,
  message,
  Switch,
  DatePicker,
  Radio,
  Divider
} from 'antd';
import {
  ArrowLeftOutlined,
  SaveOutlined,
  EyeOutlined,
  BellOutlined
} from '@ant-design/icons';
import { useAuth } from '../../contexts/AuthContext';
import dayjs from 'dayjs';
import './NotificationEdit.scss';

const { TextArea } = Input;
const { Option } = Select;

const NotificationEdit = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const [form] = Form.useForm();
  const [loading, setLoading] = useState(false);
  const [isPublished, setIsPublished] = useState(false);
  const [isScheduled, setIsScheduled] = useState(false);

  const isEdit = !!id;
  const pageTitle = isEdit ? '编辑通知' : '发布通知';

  useEffect(() => {
    if (isEdit) {
      setLoading(true);
      setTimeout(() => {
        const mockData = {
          title: '系统维护通知',
          content: '系统将于今晚22:00-24:00进行维护升级...',
          type: 'system',
          priority: 'high',
          targetUsers: 'all',
          status: 'published',
          publishAt: dayjs('2024-01-15 10:30:00')
        };
        
        form.setFieldsValue(mockData);
        setIsPublished(mockData.status === 'published');
        setLoading(false);
      }, 500);
    }
  }, [id, form, isEdit]);

  const handleSubmit = async (values) => {
    setLoading(true);
    try {
      const submitData = {
        ...values,
        status: isPublished ? 'published' : (isScheduled ? 'scheduled' : 'draft'),
        author: user?.name,
        publishAt: isScheduled ? values.publishAt?.format('YYYY-MM-DD HH:mm:ss') : null
      };
      
      console.log('提交数据:', submitData);
      
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      message.success(isEdit ? '更新成功！' : '创建成功！');
      navigate('/notifications');
    } catch (error) {
      message.error('操作失败，请重试');
    } finally {
      setLoading(false);
    }
  };

  const handlePreview = () => {
    const values = form.getFieldsValue();
    console.log('预览内容:', values);
    message.info('预览功能开发中...');
  };

  return (
    <div className="notification-edit">
      <Card className="edit-header">
        <div className="header-actions">
          <Button
            icon={<ArrowLeftOutlined />}
            onClick={() => navigate(-1)}
          >
            返回
          </Button>
          <div className="header-title">
            <BellOutlined />
            <h2>{pageTitle}</h2>
          </div>
          <Space>
            <Button
              icon={<EyeOutlined />}
              onClick={handlePreview}
            >
              预览
            </Button>
            <div className="publish-switch">
              <span>立即发布：</span>
              <Switch
                checked={isPublished}
                onChange={(checked) => {
                  setIsPublished(checked);
                  if (checked) setIsScheduled(false);
                }}
                checkedChildren="是"
                unCheckedChildren="否"
              />
            </div>
          </Space>
        </div>
      </Card>

      <Card className="edit-form">
        <Form
          form={form}
          layout="vertical"
          onFinish={handleSubmit}
          initialValues={{
            type: 'announcement',
            priority: 'medium',
            targetUsers: 'all'
          }}
        >
          <Form.Item
            name="title"
            label="通知标题"
            rules={[
              { required: true, message: '请输入通知标题' },
              { min: 5, message: '标题至少5个字符' },
              { max: 100, message: '标题不能超过100个字符' }
            ]}
          >
            <Input
              placeholder="请输入通知标题"
              size="large"
            />
          </Form.Item>

          <Form.Item
            name="content"
            label="通知内容"
            rules={[
              { required: true, message: '请输入通知内容' },
              { min: 10, message: '内容至少10个字符' }
            ]}
          >
            <TextArea
              rows={15}
              placeholder="请输入通知内容，支持Markdown格式"
            />
          </Form.Item>

          <div className="form-row">
            <Form.Item
              name="type"
              label="通知类型"
              rules={[{ required: true, message: '请选择通知类型' }]}
            >
              <Select placeholder="请选择通知类型">
                <Option value="system">🔧 系统通知</Option>
                <Option value="announcement">📢 公告</Option>
                <Option value="activity">🎉 活动</Option>
                <Option value="update">🆕 更新</Option>
              </Select>
            </Form.Item>

            <Form.Item
              name="priority"
              label="优先级"
              rules={[{ required: true, message: '请选择优先级' }]}
            >
              <Select placeholder="请选择优先级">
                <Option value="high">高优先级</Option>
                <Option value="medium">中优先级</Option>
                <Option value="low">低优先级</Option>
              </Select>
            </Form.Item>
          </div>

          <Form.Item
            name="targetUsers"
            label="目标用户"
            rules={[{ required: true, message: '请选择目标用户' }]}
          >
            <Radio.Group>
              <Radio value="all">全部用户</Radio>
              <Radio value="admin">仅管理员</Radio>
              <Radio value="user">普通用户</Radio>
              <Radio value="custom">指定用户</Radio>
            </Radio.Group>
          </Form.Item>

          <Divider>发布设置</Divider>

          <div className="publish-settings">
            <div className="setting-item">
              <span>定时发布：</span>
              <Switch
                checked={isScheduled}
                onChange={(checked) => {
                  setIsScheduled(checked);
                  if (checked) setIsPublished(false);
                }}
                checkedChildren="是"
                unCheckedChildren="否"
              />
            </div>

            {isScheduled && (
              <Form.Item
                name="publishAt"
                label="发布时间"
                rules={[{ required: true, message: '请选择发布时间' }]}
              >
                <DatePicker
                  showTime
                  format="YYYY-MM-DD HH:mm:ss"
                  placeholder="请选择发布时间"
                  style={{ width: '100%' }}
                />
              </Form.Item>
            )}
          </div>

          <Form.Item>
            <Space size="large">
              <Button
                type="primary"
                htmlType="submit"
                loading={loading}
                icon={<SaveOutlined />}
                size="large"
              >
                {isEdit ? '更新通知' : '发布通知'}
              </Button>
              <Button
                size="large"
                onClick={() => navigate(-1)}
              >
                取消
              </Button>
            </Space>
          </Form.Item>
        </Form>
      </Card>
    </div>
  );
};

export default NotificationEdit;
