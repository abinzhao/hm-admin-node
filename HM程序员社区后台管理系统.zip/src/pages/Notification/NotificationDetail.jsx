import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import {
  Card,
  Button,
  Avatar,
  Tag,
  Space,
  Divider,
  Statistic,
  Row,
  Col,
  Timeline,
  message
} from 'antd';
import {
  ArrowLeftOutlined,
  EditOutlined,
  EyeOutlined,
  BellOutlined,
  UserOutlined,
  ClockCircleOutlined,
  CheckCircleOutlined
} from '@ant-design/icons';
import { useAuth } from '../../contexts/AuthContext';
import MarkdownRenderer from '../../components/MarkdownPreview';
import './NotificationDetail.scss';

const NotificationDetail = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user, isAdmin } = useAuth();
  const [loading, setLoading] = useState(false);
  const [notification, setNotification] = useState(null);

  const mockNotification = {
    id: 1,
    title: '系统维护通知',
    content: `
# 系统维护通知

亲爱的用户们，

为了提供更好的服务体验，我们将于今晚进行系统维护升级。

## 维护时间
**2024年1月15日 22:00 - 24:00**

## 维护内容
1. 服务器性能优化
2. 数据库升级
3. 安全补丁更新
4. 新功能部署

## 影响范围
- 网站可能无法正常访问
- 移动端应用可能出现异常
- 数据同步可能延迟

## 注意事项
- 请在维护开始前保存好您的工作
- 维护期间请勿进行重要操作
- 如有紧急问题，请联系客服

感谢您的理解与支持！

**HM程序员社区技术团队**
    `,
    type: 'system',
    priority: 'high',
    status: 'published',
    author: '系统管理员',
    authorAvatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=40&h=40&fit=crop&crop=face',
    readCount: 1234,
    targetUsers: 'all',
    createdAt: '2024-01-15 10:30:00',
    publishAt: '2024-01-15 10:30:00',
    updatedAt: '2024-01-15 10:30:00'
  };

  const mockTimeline = [
    {
      time: '2024-01-15 10:30:00',
      action: '通知发布',
      user: '系统管理员',
      status: 'success'
    },
    {
      time: '2024-01-15 10:25:00',
      action: '内容审核通过',
      user: '审核员',
      status: 'success'
    },
    {
      time: '2024-01-15 10:20:00',
      action: '创建通知',
      user: '系统管理员',
      status: 'success'
    }
  ];

  useEffect(() => {
    setLoading(true);
    setTimeout(() => {
      setNotification(mockNotification);
      setLoading(false);
    }, 500);
  }, [id]);

  const getTypeTag = (type) => {
    const typeMap = {
      system: { color: 'red', text: '系统通知', icon: '🔧' },
      announcement: { color: 'blue', text: '公告', icon: '📢' },
      activity: { color: 'green', text: '活动', icon: '🎉' },
      update: { color: 'orange', text: '更新', icon: '🆕' }
    };
    const typeInfo = typeMap[type] || { color: 'default', text: type, icon: '📝' };
    return (
      <Tag color={typeInfo.color} style={{ fontSize: '14px', padding: '4px 12px' }}>
        {typeInfo.icon} {typeInfo.text}
      </Tag>
    );
  };

  const getPriorityTag = (priority) => {
    const priorityMap = {
      high: { color: 'red', text: '高优先级' },
      medium: { color: 'orange', text: '中优先级' },
      low: { color: 'green', text: '低优先级' }
    };
    const priorityInfo = priorityMap[priority] || { color: 'default', text: priority };
    return (
      <Tag color={priorityInfo.color} style={{ fontSize: '14px', padding: '4px 12px' }}>
        {priorityInfo.text}
      </Tag>
    );
  };

  const handleMarkAsRead = () => {
    message.success('已标记为已读');
  };

  if (loading || !notification) {
    return <div className="loading">加载中...</div>;
  }

  return (
    <div className="notification-detail">
      <Card className="detail-header">
        <div className="header-actions">
          <Button
            icon={<ArrowLeftOutlined />}
            onClick={() => navigate(-1)}
          >
            返回
          </Button>
          <Space>
            <Button onClick={handleMarkAsRead}>
              标记已读
            </Button>
            {isAdmin && (
              <Button
                type="primary"
                icon={<EditOutlined />}
                onClick={() => navigate(`/notifications/${id}/edit`)}
              >
                编辑
              </Button>
            )}
          </Space>
        </div>

        <div className="notification-meta">
          <div className="title-section">
            <BellOutlined className="notification-icon" />
            <h1>{notification.title}</h1>
          </div>
          
          <div className="meta-info">
            <Avatar src={notification.authorAvatar} size="large" />
            <div className="author-info">
              <div className="author-name">{notification.author}</div>
              <div className="publish-time">
                发布于 {notification.publishAt}
                {notification.updatedAt !== notification.createdAt && (
                  <span> · 更新于 {notification.updatedAt}</span>
                )}
              </div>
            </div>
            <div className="tags-section">
              {getTypeTag(notification.type)}
              {getPriorityTag(notification.priority)}
            </div>
          </div>
        </div>
      </Card>

      <Row gutter={[24, 24]}>
        <Col xs={24} lg={16}>
          <Card className="detail-content" title="通知内容">
            <MarkdownRenderer content={notification.content} />
          </Card>
        </Col>

        <Col xs={24} lg={8}>
          <Card className="detail-stats" title="统计信息">
            <Row gutter={[16, 16]}>
              <Col span={12}>
                <Statistic
                  title="阅读量"
                  value={notification.readCount}
                  prefix={<EyeOutlined />}
                />
              </Col>
              <Col span={12}>
                <Statistic
                  title="目标用户"
                  value={notification.targetUsers === 'all' ? '全部用户' : '指定用户'}
                  prefix={<UserOutlined />}
                />
              </Col>
            </Row>
          </Card>

          <Card className="detail-timeline" title="操作记录">
            <Timeline>
              {mockTimeline.map((item, index) => (
                <Timeline.Item
                  key={index}
                  dot={
                    item.status === 'success' ? (
                      <CheckCircleOutlined style={{ color: '#52c41a' }} />
                    ) : (
                      <ClockCircleOutlined style={{ color: '#1890ff' }} />
                    )
                  }
                >
                  <div className="timeline-content">
                    <div className="timeline-action">{item.action}</div>
                    <div className="timeline-meta">
                      <span>{item.user}</span>
                      <span>{item.time}</span>
                    </div>
                  </div>
                </Timeline.Item>
              ))}
            </Timeline>
          </Card>
        </Col>
      </Row>
    </div>
  );
};

export default NotificationDetail;
