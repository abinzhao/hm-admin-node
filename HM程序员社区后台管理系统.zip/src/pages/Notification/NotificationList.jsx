import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Card,
  Table,
  Button,
  Input,
  Select,
  Space,
  Tag,
  Avatar,
  Popconfirm,
  message,
  Badge
} from 'antd';
import {
  PlusOutlined,
  SearchOutlined,
  EditOutlined,
  DeleteOutlined,
  EyeOutlined,
  BellOutlined
} from '@ant-design/icons';
import { useAuth } from '../../contexts/AuthContext';
import './NotificationList.scss';

const { Search } = Input;
const { Option } = Select;

const NotificationList = () => {
  const navigate = useNavigate();
  const { user, isAdmin } = useAuth();
  const [loading, setLoading] = useState(false);
  const [searchText, setSearchText] = useState('');
  const [typeFilter, setTypeFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState('all');
  const [data, setData] = useState([]);

  const mockData = [
    {
      id: 1,
      title: '系统维护通知',
      content: '系统将于今晚22:00-24:00进行维护升级，期间可能影响正常使用...',
      type: 'system',
      priority: 'high',
      status: 'published',
      author: '系统管理员',
      authorAvatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=40&h=40&fit=crop&crop=face',
      readCount: 1234,
      createdAt: '2024-01-15 10:30:00',
      publishAt: '2024-01-15 10:30:00'
    },
    {
      id: 2,
      title: '新功能上线公告',
      content: '我们很高兴地宣布，代码片段分享功能正式上线...',
      type: 'announcement',
      priority: 'medium',
      status: 'published',
      author: '产品团队',
      authorAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=40&h=40&fit=crop&crop=face',
      readCount: 856,
      createdAt: '2024-01-14 14:20:00',
      publishAt: '2024-01-14 14:20:00'
    },
    {
      id: 3,
      title: '社区活动邀请',
      content: '本月技术分享会即将开始，欢迎大家踊跃参与...',
      type: 'activity',
      priority: 'low',
      status: 'draft',
      author: '运营团队',
      authorAvatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=40&h=40&fit=crop&crop=face',
      readCount: 0,
      createdAt: '2024-01-13 16:45:00',
      publishAt: null
    }
  ];

  useEffect(() => {
    setLoading(true);
    setTimeout(() => {
      setData(mockData);
      setLoading(false);
    }, 500);
  }, []);

  const getTypeTag = (type) => {
    const typeMap = {
      system: { color: 'red', text: '系统通知', icon: '🔧' },
      announcement: { color: 'blue', text: '公告', icon: '📢' },
      activity: { color: 'green', text: '活动', icon: '🎉' },
      update: { color: 'orange', text: '更新', icon: '🆕' }
    };
    const typeInfo = typeMap[type] || { color: 'default', text: type, icon: '📝' };
    return (
      <Tag color={typeInfo.color}>
        {typeInfo.icon} {typeInfo.text}
      </Tag>
    );
  };

  const getPriorityTag = (priority) => {
    const priorityMap = {
      high: { color: 'red', text: '高' },
      medium: { color: 'orange', text: '中' },
      low: { color: 'green', text: '低' }
    };
    const priorityInfo = priorityMap[priority] || { color: 'default', text: priority };
    return <Tag color={priorityInfo.color}>{priorityInfo.text}</Tag>;
  };

  const getStatusTag = (status) => {
    const statusMap = {
      published: { color: 'green', text: '已发布' },
      draft: { color: 'orange', text: '草稿' },
      scheduled: { color: 'blue', text: '定时发布' },
      archived: { color: 'gray', text: '已归档' }
    };
    const statusInfo = statusMap[status] || { color: 'default', text: status };
    return <Tag color={statusInfo.color}>{statusInfo.text}</Tag>;
  };

  const handleDelete = (id) => {
    setData(data.filter(item => item.id !== id));
    message.success('删除成功');
  };

  const handlePublish = (id) => {
    setData(data.map(item => 
      item.id === id 
        ? { ...item, status: 'published', publishAt: new Date().toLocaleString() }
        : item
    ));
    message.success('发布成功');
  };

  const columns = [
    {
      title: '通知信息',
      dataIndex: 'title',
      key: 'title',
      render: (text, record) => (
        <div className="notification-cell">
          <div className="notification-title">
            <BellOutlined className="notification-icon" />
            {text}
          </div>
          <div className="notification-content">{record.content}</div>
          <div className="notification-meta">
            <Avatar src={record.authorAvatar} size="small" />
            <span>{record.author}</span>
            <span>{record.createdAt}</span>
          </div>
        </div>
      )
    },
    {
      title: '类型',
      dataIndex: 'type',
      key: 'type',
      width: 120,
      render: getTypeTag
    },
    {
      title: '优先级',
      dataIndex: 'priority',
      key: 'priority',
      width: 80,
      render: getPriorityTag
    },
    {
      title: '状态',
      dataIndex: 'status',
      key: 'status',
      width: 100,
      render: getStatusTag
    },
    {
      title: '阅读量',
      dataIndex: 'readCount',
      key: 'readCount',
      width: 80,
      render: (count) => (
        <Badge count={count} showZero color="blue" />
      )
    },
    {
      title: '操作',
      key: 'actions',
      width: 180,
      render: (_, record) => (
        <Space>
          <Button
            type="text"
            icon={<EyeOutlined />}
            onClick={() => navigate(`/notifications/${record.id}`)}
          />
          <Button
            type="text"
            icon={<EditOutlined />}
            onClick={() => navigate(`/notifications/${record.id}/edit`)}
          />
          {record.status === 'draft' && isAdmin && (
            <Button
              type="text"
              onClick={() => handlePublish(record.id)}
              style={{ color: '#52c41a' }}
            >
              发布
            </Button>
          )}
          {isAdmin && (
            <Popconfirm
              title="确定要删除吗？"
              onConfirm={() => handleDelete(record.id)}
            >
              <Button type="text" danger icon={<DeleteOutlined />} />
            </Popconfirm>
          )}
        </Space>
      )
    }
  ];

  return (
    <div className="notification-list">
      <Card className="notification-header">
        <div className="header-top">
          <h2>系统通知</h2>
          {isAdmin && (
            <Button
              type="primary"
              icon={<PlusOutlined />}
              onClick={() => navigate('/notifications/create')}
            >
              发布通知
            </Button>
          )}
        </div>

        <div className="filters">
          <Search
            placeholder="搜索通知标题或内容"
            value={searchText}
            onChange={(e) => setSearchText(e.target.value)}
            style={{ width: 300 }}
          />
          <Select
            value={typeFilter}
            onChange={setTypeFilter}
            style={{ width: 120 }}
          >
            <Option value="all">全部类型</Option>
            <Option value="system">系统通知</Option>
            <Option value="announcement">公告</Option>
            <Option value="activity">活动</Option>
            <Option value="update">更新</Option>
          </Select>
          <Select
            value={statusFilter}
            onChange={setStatusFilter}
            style={{ width: 120 }}
          >
            <Option value="all">全部状态</Option>
            <Option value="published">已发布</Option>
            <Option value="draft">草稿</Option>
            <Option value="scheduled">定时发布</Option>
            <Option value="archived">已归档</Option>
          </Select>
        </div>
      </Card>

      <Card className="notification-table">
        <Table
          columns={columns}
          dataSource={data}
          loading={loading}
          rowKey="id"
          pagination={{
            total: data.length,
            pageSize: 10,
            showSizeChanger: true,
            showQuickJumper: true,
            showTotal: (total) => `共 ${total} 条通知`
          }}
        />
      </Card>
    </div>
  );
};

export default NotificationList;
