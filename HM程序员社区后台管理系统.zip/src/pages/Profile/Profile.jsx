import React, { useState } from 'react';
import {
  Card,
  Form,
  Input,
  Button,
  Avatar,
  Upload,
  message,
  Tabs,
  Switch,
  Select,
  Divider,
  Row,
  Col,
  Statistic,
  List,
  Tag,
  Progress,
  Badge,
  Space
} from 'antd';
import {
  UserOutlined,
  MailOutlined,
  PhoneOutlined,
  LockOutlined,
  UploadOutlined,
  SettingOutlined,
  BellOutlined,
  EyeOutlined,
  EditOutlined,
  TrophyOutlined,
  CalendarOutlined,
  EnvironmentOutlined,
  LinkOutlined,
  StarOutlined,
  HeartOutlined,
  MessageOutlined,
  FileTextOutlined,
  FireOutlined,
  ThunderboltOutlined,
  CrownOutlined,
  GiftOutlined
} from '@ant-design/icons';
import { useAuth } from '../../contexts/AuthContext';
import { useTheme } from '../../contexts/ThemeContext';
import './Profile.scss';

const { TextArea } = Input;
const { Option } = Select;

const Profile = () => {
  const { user, updateUser } = useAuth();
  const { theme, toggleTheme, isDark } = useTheme();
  const [form] = Form.useForm();
  const [passwordForm] = Form.useForm();
  const [loading, setLoading] = useState(false);
  const [activeTab, setActiveTab] = useState('overview');

  const [userStats] = useState({
    articles: 12,
    questions: 8,
    snippets: 15,
    likes: 156,
    views: 2340,
    comments: 89,
    followers: 45,
    following: 32,
    level: 5,
    experience: 2340,
    nextLevelExp: 3000,
    streak: 7,
    totalPoints: 8650
  });

  const [recentActivities] = useState([
    {
      id: 1,
      type: 'article',
      title: '发布了文章《React 18 新特性详解》',
      time: '2小时前',
      status: 'published',
      icon: <FileTextOutlined />,
      color: '#1890ff'
    },
    {
      id: 2,
      type: 'question',
      title: '回答了问题《如何优化React性能？》',
      time: '1天前',
      status: 'answered',
      icon: <MessageOutlined />,
      color: '#52c41a'
    },
    {
      id: 3,
      type: 'snippet',
      title: '分享了代码片段《防抖函数实现》',
      time: '2天前',
      status: 'published',
      icon: <EditOutlined />,
      color: '#fa8c16'
    }
  ]);

  const [achievements] = useState([
    { name: '新手上路', desc: '完成首次发布', icon: '🎯', unlocked: true, rarity: 'common' },
    { name: '内容创作者', desc: '发布10篇文章', icon: '✍️', unlocked: true, rarity: 'common' },
    { name: '热心助手', desc: '回答50个问题', icon: '🤝', unlocked: true, rarity: 'rare' },
    { name: '代码大师', desc: '分享100个代码片段', icon: '💻', unlocked: false, rarity: 'epic' },
    { name: '社区之星', desc: '获得1000个赞', icon: '⭐', unlocked: false, rarity: 'legendary' },
    { name: '影响力者', desc: '拥有100个粉丝', icon: '👑', unlocked: false, rarity: 'legendary' }
  ]);

  const handleProfileUpdate = async (values) => {
    setLoading(true);
    try {
      await new Promise(resolve => setTimeout(resolve, 1000));
      updateUser(values);
      message.success('个人信息更新成功！');
    } catch (error) {
      message.error('更新失败，请重试');
    } finally {
      setLoading(false);
    }
  };

  const handlePasswordChange = async (values) => {
    setLoading(true);
    try {
      await new Promise(resolve => setTimeout(resolve, 1000));
      message.success('密码修改成功！');
      passwordForm.resetFields();
    } catch (error) {
      message.error('密码修改失败，请重试');
    } finally {
      setLoading(false);
    }
  };

  const handleAvatarChange = (info) => {
    if (info.file.status === 'done') {
      message.success('头像上传成功！');
    } else if (info.file.status === 'error') {
      message.error('头像上传失败！');
    }
  };

  const getActivityIcon = (type) => {
    const icons = {
      article: <FileTextOutlined />,
      question: <MessageOutlined />,
      snippet: <EditOutlined />,
      software: <SettingOutlined />
    };
    return icons[type] || <FileTextOutlined />;
  };

  const getStatusTag = (status) => {
    const statusMap = {
      published: { color: 'green', text: '已发布' },
      answered: { color: 'blue', text: '已回答' },
      draft: { color: 'orange', text: '草稿' }
    };
    const statusInfo = statusMap[status] || { color: 'default', text: status };
    return <Tag color={statusInfo.color}>{statusInfo.text}</Tag>;
  };

  const getRarityColor = (rarity) => {
    const colors = {
      common: '#8c8c8c',
      rare: '#1890ff',
      epic: '#722ed1',
      legendary: '#fa8c16'
    };
    return colors[rarity] || '#8c8c8c';
  };

  const tabItems = [
    {
      key: 'overview',
      label: (
        <span>
          <UserOutlined />
          个人概览
        </span>
      ),
      children: (
        <div className="profile-overview">
          {/* 个人信息卡片 */}
          <div className="profile-hero">
            <div className="hero-background"></div>
            <div className="hero-content">
              <div className="avatar-section">
                <div className="avatar-container">
                  <Avatar src={user?.avatar} size={120} icon={<UserOutlined />} />
                  <div className="level-badge">
                    <CrownOutlined />
                    <span>Lv.{userStats.level}</span>
                  </div>
                </div>
                <Upload
                  showUploadList={false}
                  beforeUpload={() => false}
                  onChange={handleAvatarChange}
                >
                  <Button icon={<UploadOutlined />} size="small" type="primary" ghost>
                    更换头像
                  </Button>
                </Upload>
              </div>
              <div className="user-info">
                <h1>{user?.name}</h1>
                <p className="username">@{user?.username}</p>
                <div className="user-meta">
                  <Space size="large">
                    <span><MailOutlined /> {user?.email}</span>
                    <span><CalendarOutlined /> 加入于 2024年1月</span>
                    <span><EnvironmentOutlined /> 北京市</span>
                  </Space>
                </div>
                <p className="bio">热爱编程的前端开发工程师，专注于React和Vue技术栈，喜欢分享技术心得。</p>
                
                <div className="level-progress">
                  <div className="progress-info">
                    <span>经验值</span>
                    <span>{userStats.experience}/{userStats.nextLevelExp} EXP</span>
                  </div>
                  <Progress 
                    percent={(userStats.experience / userStats.nextLevelExp) * 100} 
                    strokeColor={{
                      '0%': '#108ee9',
                      '100%': '#87d068',
                    }}
                    strokeWidth={8}
                  />
                </div>
              </div>
            </div>
          </div>

          <Row gutter={[24, 24]} className="stats-section">
            {/* 核心数据 */}
            <Col xs={24} lg={8}>
              <Card className="stats-card primary">
                <div className="card-header">
                  <FireOutlined />
                  <span>核心数据</span>
                </div>
                <Row gutter={[16, 16]}>
                  <Col span={12}>
                    <Statistic 
                      title="文章" 
                      value={userStats.articles} 
                      prefix={<FileTextOutlined />}
                      valueStyle={{ color: '#1890ff', fontSize: '24px', fontWeight: 'bold' }}
                    />
                  </Col>
                  <Col span={12}>
                    <Statistic 
                      title="问答" 
                      value={userStats.questions}
                      prefix={<MessageOutlined />}
                      valueStyle={{ color: '#52c41a', fontSize: '24px', fontWeight: 'bold' }}
                    />
                  </Col>
                  <Col span={12}>
                    <Statistic 
                      title="代码" 
                      value={userStats.snippets}
                      prefix={<EditOutlined />}
                      valueStyle={{ color: '#fa8c16', fontSize: '24px', fontWeight: 'bold' }}
                    />
                  </Col>
                  <Col span={12}>
                    <Statistic 
                      title="获赞" 
                      value={userStats.likes}
                      prefix={<HeartOutlined />}
                      valueStyle={{ color: '#eb2f96', fontSize: '24px', fontWeight: 'bold' }}
                    />
                  </Col>
                </Row>
              </Card>
            </Col>

            {/* 社交数据 */}
            <Col xs={24} lg={8}>
              <Card className="stats-card secondary">
                <div className="card-header">
                  <ThunderboltOutlined />
                  <span>社交影响</span>
                </div>
                <Row gutter={[16, 16]}>
                  <Col span={12}>
                    <Statistic 
                      title="浏览量" 
                      value={userStats.views}
                      prefix={<EyeOutlined />}
                      valueStyle={{ color: '#722ed1', fontSize: '24px', fontWeight: 'bold' }}
                    />
                  </Col>
                  <Col span={12}>
                    <Statistic 
                      title="粉丝" 
                      value={userStats.followers}
                      prefix={<UserOutlined />}
                      valueStyle={{ color: '#13c2c2', fontSize: '24px', fontWeight: 'bold' }}
                    />
                  </Col>
                  <Col span={12}>
                    <Statistic 
                      title="关注" 
                      value={userStats.following}
                      prefix={<StarOutlined />}
                      valueStyle={{ color: '#fa541c', fontSize: '24px', fontWeight: 'bold' }}
                    />
                  </Col>
                  <Col span={12}>
                    <Statistic 
                      title="连续签到" 
                      value={userStats.streak}
                      suffix="天"
                      prefix={<CalendarOutlined />}
                      valueStyle={{ color: '#52c41a', fontSize: '24px', fontWeight: 'bold' }}
                    />
                  </Col>
                </Row>
              </Card>
            </Col>

            {/* 积分系统 */}
            <Col xs={24} lg={8}>
              <Card className="stats-card tertiary">
                <div className="card-header">
                  <GiftOutlined />
                  <span>积分系统</span>
                </div>
                <div className="points-display">
                  <div className="total-points">
                    <span className="points-number">{userStats.totalPoints.toLocaleString()}</span>
                    <span className="points-label">总积分</span>
                  </div>
                  <div className="points-breakdown">
                    <div className="point-item">
                      <span className="point-source">发布内容</span>
                      <span className="point-value">+{userStats.articles * 50}</span>
                    </div>
                    <div className="point-item">
                      <span className="point-source">获得点赞</span>
                      <span className="point-value">+{userStats.likes * 10}</span>
                    </div>
                    <div className="point-item">
                      <span className="point-source">连续签到</span>
                      <span className="point-value">+{userStats.streak * 20}</span>
                    </div>
                  </div>
                </div>
              </Card>
            </Col>
          </Row>

          {/* 成就系统 */}
          <Card className="achievements-card">
            <div className="card-header">
              <TrophyOutlined />
              <span>成就徽章</span>
              <Badge count={achievements.filter(a => a.unlocked).length} color="#52c41a" />
            </div>
            <div className="achievements-grid">
              {achievements.map((achievement, index) => (
                <div 
                  key={index} 
                  className={`achievement-item ${achievement.unlocked ? 'unlocked' : 'locked'}`}
                  style={{ borderColor: getRarityColor(achievement.rarity) }}
                >
                  <div className="achievement-icon" style={{ color: getRarityColor(achievement.rarity) }}>
                    {achievement.icon}
                  </div>
                  <div className="achievement-info">
                    <div className="achievement-name">{achievement.name}</div>
                    <div className="achievement-desc">{achievement.desc}</div>
                    <div className="achievement-rarity" style={{ color: getRarityColor(achievement.rarity) }}>
                      {achievement.rarity.toUpperCase()}
                    </div>
                  </div>
                  {achievement.unlocked && (
                    <div className="achievement-badge">
                      <Badge status="success" />
                    </div>
                  )}
                </div>
              ))}
            </div>
          </Card>

          {/* 最近活动 */}
          <Card className="activity-card">
            <div className="card-header">
              <ClockCircleOutlined />
              <span>最近活动</span>
            </div>
            <List
              dataSource={recentActivities}
              renderItem={(item) => (
                <List.Item className="activity-item">
                  <div className="activity-icon" style={{ color: item.color }}>
                    {item.icon}
                  </div>
                  <div className="activity-content">
                    <div className="activity-title">{item.title}</div>
                    <div className="activity-meta">
                      <span className="time">{item.time}</span>
                      {getStatusTag(item.status)}
                    </div>
                  </div>
                </List.Item>
              )}
            />
          </Card>
        </div>
      )
    },
    {
      key: 'edit',
      label: (
        <span>
          <EditOutlined />
          编辑资料
        </span>
      ),
      children: (
        <div className="profile-edit">
          <Card title="基本信息" className="edit-card">
            <Form
              form={form}
              layout="vertical"
              onFinish={handleProfileUpdate}
              initialValues={{
                name: user?.name,
                username: user?.username,
                email: user?.email,
                phone: user?.phone || '',
                bio: user?.bio || '',
                location: user?.location || '',
                website: user?.website || ''
              }}
            >
              <Row gutter={[24, 0]}>
                <Col xs={24} md={12}>
                  <Form.Item
                    name="name"
                    label="姓名"
                    rules={[{ required: true, message: '请输入姓名' }]}
                  >
                    <Input prefix={<UserOutlined />} placeholder="请输入姓名" />
                  </Form.Item>
                </Col>
                <Col xs={24} md={12}>
                  <Form.Item
                    name="username"
                    label="用户名"
                    rules={[{ required: true, message: '请输入用户名' }]}
                  >
                    <Input prefix={<UserOutlined />} placeholder="请输入用户名" />
                  </Form.Item>
                </Col>
              </Row>

              <Row gutter={[24, 0]}>
                <Col xs={24} md={12}>
                  <Form.Item
                    name="email"
                    label="邮箱"
                    rules={[
                      { required: true, message: '请输入邮箱' },
                      { type: 'email', message: '请输入有效的邮箱地址' }
                    ]}
                  >
                    <Input prefix={<MailOutlined />} placeholder="请输入邮箱" />
                  </Form.Item>
                </Col>
                <Col xs={24} md={12}>
                  <Form.Item
                    name="phone"
                    label="手机号"
                  >
                    <Input prefix={<PhoneOutlined />} placeholder="请输入手机号" />
                  </Form.Item>
                </Col>
              </Row>

              <Row gutter={[24, 0]}>
                <Col xs={24} md={12}>
                  <Form.Item
                    name="location"
                    label="所在地"
                  >
                    <Input prefix={<EnvironmentOutlined />} placeholder="请输入所在地" />
                  </Form.Item>
                </Col>
                <Col xs={24} md={12}>
                  <Form.Item
                    name="website"
                    label="个人网站"
                  >
                    <Input prefix={<LinkOutlined />} placeholder="请输入个人网站" />
                  </Form.Item>
                </Col>
              </Row>

              <Form.Item
                name="bio"
                label="个人简介"
              >
                <TextArea rows={4} placeholder="介绍一下自己吧..." />
              </Form.Item>

              <Form.Item>
                <Button type="primary" htmlType="submit" loading={loading} size="large">
                  保存修改
                </Button>
              </Form.Item>
            </Form>
          </Card>
        </div>
      )
    },
    {
      key: 'security',
      label: (
        <span>
          <LockOutlined />
          安全设置
        </span>
      ),
      children: (
        <div className="security-content">
          <Card title="修改密码" className="security-card">
            <Form
              form={passwordForm}
              layout="vertical"
              onFinish={handlePasswordChange}
            >
              <Form.Item
                name="currentPassword"
                label="当前密码"
                rules={[{ required: true, message: '请输入当前密码' }]}
              >
                <Input.Password placeholder="请输入当前密码" />
              </Form.Item>

              <Form.Item
                name="newPassword"
                label="新密码"
                rules={[
                  { required: true, message: '请输入新密码' },
                  { min: 6, message: '密码至少6个字符' }
                ]}
              >
                <Input.Password placeholder="请输入新密码" />
              </Form.Item>

              <Form.Item
                name="confirmPassword"
                label="确认新密码"
                dependencies={['newPassword']}
                rules={[
                  { required: true, message: '请确认新密码' },
                  ({ getFieldValue }) => ({
                    validator(_, value) {
                      if (!value || getFieldValue('newPassword') === value) {
                        return Promise.resolve();
                      }
                      return Promise.reject(new Error('两次输入的密码不一致'));
                    },
                  }),
                ]}
              >
                <Input.Password placeholder="请确认新密码" />
              </Form.Item>

              <Form.Item>
                <Button type="primary" htmlType="submit" loading={loading} size="large">
                  修改密码
                </Button>
              </Form.Item>
            </Form>
          </Card>
        </div>
      )
    },
    {
      key: 'preferences',
      label: (
        <span>
          <SettingOutlined />
          偏好设置
        </span>
      ),
      children: (
        <div className="preferences-content">
          <Card title="界面设置" className="preferences-card">
            <div className="preference-item">
              <div className="preference-label">
                <span>深色模式</span>
                <p>切换到深色主题以减少眼部疲劳</p>
              </div>
              <Switch checked={isDark} onChange={toggleTheme} />
            </div>

            <Divider />

            <div className="preference-item">
              <div className="preference-label">
                <span>语言设置</span>
                <p>选择您的首选语言</p>
              </div>
              <Select defaultValue="zh-CN" style={{ width: 120 }}>
                <Option value="zh-CN">简体中文</Option>
                <Option value="en-US">English</Option>
              </Select>
            </div>

            <Divider />

            <div className="preference-item">
              <div className="preference-label">
                <span>邮件通知</span>
                <p>接收系统通知和更新</p>
              </div>
              <Switch defaultChecked />
            </div>

            <Divider />

            <div className="preference-item">
              <div className="preference-label">
                <span>桌面通知</span>
                <p>在浏览器中显示通知</p>
              </div>
              <Switch defaultChecked />
            </div>
          </Card>
        </div>
      )
    }
  ];

  return (
    <div className="profile-page">
      <Tabs
        activeKey={activeTab}
        onChange={setActiveTab}
        items={tabItems}
        className="profile-tabs"
        size="large"
        type="card"
      />
    </div>
  );
};

export default Profile;
