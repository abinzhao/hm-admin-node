import React, { useState, useEffect } from 'react';
import { Card, Row, Col, Statistic, List, Avatar, Tag, Button, Spin } from 'antd';
import {
  UserOutlined,
  FileTextOutlined,
  BellOutlined,
  CheckSquareOutlined,
  TrophyOutlined,
  EyeOutlined,
  LikeOutlined,
  MessageOutlined,
  RiseOutlined,
  ClockCircleOutlined,
  CalendarOutlined
} from '@ant-design/icons';
import { useAuth } from '../../contexts/AuthContext';
import { useNavigate } from 'react-router-dom';
import './index.scss';

const Dashboard = () => {
  const { user, isAdmin } = useAuth();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState({
    totalUsers: 1248,
    totalContent: 856,
    totalNotifications: 23,
    totalTodos: 12,
    userGrowth: 12.5,
    contentGrowth: 8.3,
    notificationGrowth: 15.2,
    todoCompletion: 75
  });

  const [recentActivities] = useState([
    {
      id: 1,
      type: 'content',
      title: '发布了新文章《React 18 新特性详解》',
      user: '张三',
      avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=40&h=40&fit=crop&crop=face',
      time: '2小时前',
      tag: '文章'
    },
    {
      id: 2,
      type: 'question',
      title: '回答了问题《如何优化React性能？》',
      user: '李四',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=40&h=40&fit=crop&crop=face',
      time: '4小时前',
      tag: '问答'
    },
    {
      id: 3,
      type: 'code',
      title: '分享了代码片段《防抖函数实现》',
      user: '王五',
      avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=40&h=40&fit=crop&crop=face',
      time: '6小时前',
      tag: '代码'
    },
    {
      id: 4,
      type: 'software',
      title: '推荐了软件《VS Code插件合集》',
      user: '赵六',
      avatar: 'https://images.unsplash.com/photo-1519244703995-f4e0f30006d5?w=40&h=40&fit=crop&crop=face',
      time: '8小时前',
      tag: '软件'
    }
  ]);

  const [popularContent] = useState([
    {
      id: 1,
      title: 'Vue 3 Composition API 最佳实践',
      views: 2340,
      likes: 156,
      comments: 23,
      type: 'article'
    },
    {
      id: 2,
      title: '如何设计一个高性能的前端架构？',
      views: 1890,
      likes: 134,
      comments: 45,
      type: 'question'
    },
    {
      id: 3,
      title: 'JavaScript 异步编程技巧',
      views: 1567,
      likes: 98,
      comments: 12,
      type: 'article'
    }
  ]);

  useEffect(() => {
    setTimeout(() => {
      setLoading(false);
    }, 1000);
  }, []);

  const getTagColor = (tag) => {
    const colors = {
      '文章': 'blue',
      '问答': 'green',
      '代码': 'orange',
      '软件': 'purple'
    };
    return colors[tag] || 'default';
  };

  const getTimeGreeting = () => {
    const hour = new Date().getHours();
    if (hour < 6) return '夜深了';
    if (hour < 9) return '早上好';
    if (hour < 12) return '上午好';
    if (hour < 14) return '中午好';
    if (hour < 18) return '下午好';
    if (hour < 22) return '晚上好';
    return '夜深了';
  };

  const getCurrentDate = () => {
    const now = new Date();
    const options = { 
      year: 'numeric', 
      month: 'long', 
      day: 'numeric',
      weekday: 'long'
    };
    return now.toLocaleDateString('zh-CN', options);
  };

  if (loading) {
    return (
      <div className="dashboard-loading">
        <Spin size="large" />
        <p>正在加载仪表板数据...</p>
      </div>
    );
  }

  return (
    <div className="dashboard">
      {/* 欢迎区域 */}
      <div className="welcome-section">
        <div className="welcome-content">
          <div className="welcome-text">
            <h1>{getTimeGreeting()}，{user?.name}！</h1>
            <p>欢迎回到HM程序员社区后台管理系统</p>
            <div className="date-info">
              <CalendarOutlined />
              <span>{getCurrentDate()}</span>
            </div>
          </div>
          <div className="welcome-avatar">
            <Avatar src={user?.avatar} size={80}>
              {user?.name?.[0]}
            </Avatar>
          </div>
        </div>
      </div>

      {/* 统计卡片 */}
      <Row gutter={[24, 24]} className="stats-row">
        <Col xs={24} sm={12} lg={6}>
          <Card className="stat-card users">
            <div className="stat-content">
              <div className="stat-icon">
                <UserOutlined />
              </div>
              <div className="stat-info">
                <Statistic
                  title="总用户数"
                  value={stats.totalUsers}
                  suffix={
                    <span className="growth positive">
                      <RiseOutlined />
                      +{stats.userGrowth}%
                    </span>
                  }
                />
              </div>
            </div>
          </Card>
        </Col>
        <Col xs={24} sm={12} lg={6}>
          <Card className="stat-card content">
            <div className="stat-content">
              <div className="stat-icon">
                <FileTextOutlined />
              </div>
              <div className="stat-info">
                <Statistic
                  title="内容总数"
                  value={stats.totalContent}
                  suffix={
                    <span className="growth positive">
                      <RiseOutlined />
                      +{stats.contentGrowth}%
                    </span>
                  }
                />
              </div>
            </div>
          </Card>
        </Col>
        <Col xs={24} sm={12} lg={6}>
          <Card className="stat-card notifications">
            <div className="stat-content">
              <div className="stat-icon">
                <BellOutlined />
              </div>
              <div className="stat-info">
                <Statistic
                  title="系统通知"
                  value={stats.totalNotifications}
                  suffix={
                    <span className="growth positive">
                      <RiseOutlined />
                      +{stats.notificationGrowth}%
                    </span>
                  }
                />
              </div>
            </div>
          </Card>
        </Col>
        <Col xs={24} sm={12} lg={6}>
          <Card className="stat-card todos">
            <div className="stat-content">
              <div className="stat-icon">
                <CheckSquareOutlined />
              </div>
              <div className="stat-info">
                <Statistic
                  title="待办事项"
                  value={stats.totalTodos}
                  suffix={
                    <div className="progress-circle">
                      <span>{stats.todoCompletion}%</span>
                    </div>
                  }
                />
              </div>
            </div>
          </Card>
        </Col>
      </Row>

      <Row gutter={[24, 24]} className="content-row">
        {/* 最近活动 */}
        <Col xs={24} lg={12}>
          <Card
            title={
              <div className="card-title">
                <ClockCircleOutlined />
                <span>最近活动</span>
              </div>
            }
            extra={<Button type="link" onClick={() => navigate('/content')}>查看更多</Button>}
            className="activity-card"
          >
            <List
              dataSource={recentActivities}
              renderItem={(item) => (
                <List.Item className="activity-item">
                  <List.Item.Meta
                    avatar={<Avatar src={item.avatar} />}
                    title={
                      <div className="activity-title">
                        <span>{item.user}</span>
                        <Tag color={getTagColor(item.tag)} size="small">
                          {item.tag}
                        </Tag>
                      </div>
                    }
                    description={
                      <div className="activity-desc">
                        <div>{item.title}</div>
                        <span className="time">{item.time}</span>
                      </div>
                    }
                  />
                </List.Item>
              )}
            />
          </Card>
        </Col>

        {/* 热门内容 */}
        <Col xs={24} lg={12}>
          <Card
            title={
              <div className="card-title">
                <TrophyOutlined />
                <span>热门内容</span>
              </div>
            }
            extra={<Button type="link" onClick={() => navigate('/content')}>查看更多</Button>}
            className="popular-card"
          >
            <List
              dataSource={popularContent}
              renderItem={(item, index) => (
                <List.Item className="popular-item">
                  <div className="popular-rank">#{index + 1}</div>
                  <div className="popular-content">
                    <div className="popular-title">{item.title}</div>
                    <div className="popular-stats">
                      <span><EyeOutlined /> {item.views}</span>
                      <span><LikeOutlined /> {item.likes}</span>
                      <span><MessageOutlined /> {item.comments}</span>
                    </div>
                  </div>
                </List.Item>
              )}
            />
          </Card>
        </Col>
      </Row>

      {/* 快速操作 */}
      <Card title="快速操作" className="quick-actions">
        <Row gutter={[16, 16]}>
          <Col xs={12} sm={8} md={6}>
            <Button
              type="primary"
              size="large"
              icon={<FileTextOutlined />}
              onClick={() => navigate('/content/articles/create')}
              block
              className="action-btn primary"
            >
              发布文章
            </Button>
          </Col>
          <Col xs={12} sm={8} md={6}>
            <Button
              size="large"
              icon={<BellOutlined />}
              onClick={() => navigate('/notifications/create')}
              block
              className="action-btn secondary"
            >
              发送通知
            </Button>
          </Col>
          <Col xs={12} sm={8} md={6}>
            <Button
              size="large"
              icon={<CheckSquareOutlined />}
              onClick={() => navigate('/todos/create')}
              block
              className="action-btn tertiary"
            >
              添加待办
            </Button>
          </Col>
          {isAdmin && (
            <Col xs={12} sm={8} md={6}>
              <Button
                size="large"
                icon={<UserOutlined />}
                onClick={() => navigate('/users')}
                block
                className="action-btn quaternary"
              >
                用户管理
              </Button>
            </Col>
          )}
        </Row>
      </Card>
    </div>
  );
};

export default Dashboard;
