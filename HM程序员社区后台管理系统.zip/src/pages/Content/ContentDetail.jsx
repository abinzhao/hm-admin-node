import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import {
  Card,
  Button,
  Avatar,
  Tag,
  Space,
  Divider,
  List,
  Input,
  message,
  Image,
  Row,
  Col,
  Statistic,
  Timeline
} from 'antd';
import {
  ArrowLeftOutlined,
  EditOutlined,
  EyeOutlined,
  LikeOutlined,
  MessageOutlined,
  ShareAltOutlined,
  DownloadOutlined,
  AndroidOutlined,
  AppleOutlined,
  WindowsOutlined,
  CodeOutlined
} from '@ant-design/icons';
import { useAuth } from '../../contexts/AuthContext';
import CodeEditor from '../../components/CodeEditor';
import MarkdownRenderer from '../../components/MarkdownPreview';
import './ContentDetail.scss';

const { TextArea } = Input;

const ContentDetail = () => {
  const { type, id } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const [loading, setLoading] = useState(false);
  const [content, setContent] = useState(null);
  const [comments, setComments] = useState([]);
  const [newComment, setNewComment] = useState('');

  const mockContent = {
    articles: {
      id: 1,
      title: 'React 18 新特性详解',
      content: `# React 18 新特性详解

React 18 是 React 的一个重大版本更新，引入了许多令人兴奋的新特性和改进。本文将详细介绍这些新特性。

## 1. 并发特性 (Concurrent Features)

React 18 引入了并发渲染，这是 React 的一个重大改进。并发渲染允许 React 在渲染过程中暂停、恢复或放弃工作。

### 主要优势：
- 更好的用户体验
- 更流畅的动画
- 更快的响应时间

## 2. 自动批处理 (Automatic Batching)

React 18 扩展了批处理功能，现在可以自动批处理更多的更新，包括 Promise、setTimeout 和原生事件处理程序中的更新。

\`\`\`javascript
// React 18 中，这些更新会被自动批处理
setTimeout(() => {
  setCount(c => c + 1);
  setFlag(f => !f);
  // React 只会重新渲染一次
}, 1000);
\`\`\`

## 3. Suspense 改进

React 18 对 Suspense 进行了重大改进，现在支持服务端渲染。

## 4. 新的 Hooks

### useId
用于生成唯一的 ID，特别适用于可访问性属性。

\`\`\`javascript
function Checkbox() {
  const id = useId();
  return (
    <>
      <label htmlFor={id}>Do you like React?</label>
      <input id={id} type="checkbox" name="react"/>
    </>
  );
}
\`\`\`

### useDeferredValue
用于延迟更新非紧急的值。

### useTransition
用于标记非紧急的状态更新。

## 总结

React 18 带来了许多激动人心的新特性，这些特性将帮助开发者构建更好的用户体验。建议大家尽快升级到 React 18。`,
      author: '张三',
      authorAvatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=40&h=40&fit=crop&crop=face',
      status: 'published',
      views: 1234,
      likes: 56,
      comments: 12,
      tags: ['React', 'JavaScript', '前端'],
      createdAt: '2024-01-15 10:30:00',
      updatedAt: '2024-01-16 14:20:00'
    },
    snippets: {
      id: 1,
      title: 'React Hooks 防抖实现',
      content: `import { useCallback, useRef } from 'react';

function useDebounce(callback, delay) {
  const timeoutRef = useRef(null);
  
  const debouncedCallback = useCallback((...args) => {
    if (timeoutRef.current) {
      clearTimeout(timeoutRef.current);
    }
    
    timeoutRef.current = setTimeout(() => {
      callback(...args);
    }, delay);
  }, [callback, delay]);
  
  return debouncedCallback;
}

export default useDebounce;`,
      language: 'javascript',
      author: '李四',
      authorAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=40&h=40&fit=crop&crop=face',
      status: 'published',
      views: 567,
      likes: 23,
      comments: 8,
      tags: ['React', 'Hooks', 'JavaScript', '工具函数'],
      createdAt: '2024-01-14 16:45:00',
      updatedAt: '2024-01-15 09:20:00'
    },
    software: {
      id: 1,
      title: 'VS Code',
      packageName: 'com.microsoft.vscode',
      appName: 'Visual Studio Code',
      version: '1.85.0',
      category: 'development',
      content: `# Visual Studio Code

Visual Studio Code 是微软开发的一款免费、开源的现代化代码编辑器。

## 主要特性

### 🚀 强大的编辑功能
- 智能代码补全
- 语法高亮
- 代码格式化
- 多光标编辑

### 🔧 丰富的扩展生态
- 数千个扩展插件
- 主题定制
- 语言支持
- 调试工具

### 🌐 跨平台支持
- Windows
- macOS  
- Linux

### 📦 内置功能
- Git 集成
- 终端集成
- 文件管理器
- 搜索和替换

## 适用人群
- 前端开发者
- 后端开发者
- 全栈工程师
- 学生和教育工作者

## 系统要求
- 内存：1GB RAM
- 存储：200MB 可用空间
- 处理器：1.6GHz 或更快的处理器`,
      appIcon: 'https://images.unsplash.com/photo-1555066931-4365d14bab8c?w=100&h=100&fit=crop',
      screenshots: [
        'https://images.unsplash.com/photo-1555066931-4365d14bab8c?w=600&h=400&fit=crop',
        'https://images.unsplash.com/photo-1517077304055-6e89abbf09b0?w=600&h=400&fit=crop',
        'https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=600&h=400&fit=crop'
      ],
      author: '微软',
      authorAvatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=40&h=40&fit=crop&crop=face',
      status: 'published',
      views: 2340,
      likes: 189,
      comments: 45,
      downloads: 15600,
      tags: ['编辑器', '开发工具', 'Microsoft', 'IDE'],
      isIteration: true,
      iterationDetails: '修复了一些已知问题，优化了性能，新增了AI代码补全功能。',
      createdAt: '2024-01-12 11:20:00',
      updatedAt: '2024-01-16 15:30:00'
    }
  };

  const mockComments = [
    {
      id: 1,
      author: '王五',
      avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=40&h=40&fit=crop&crop=face',
      content: '写得很好！很有帮助，学到了很多。',
      datetime: '2024-01-16 09:00:00',
      likes: 3
    },
    {
      id: 2,
      author: '赵六',
      avatar: 'https://images.unsplash.com/photo-1519244703995-f4e0f30006d5?w=40&h=40&fit=crop&crop=face',
      content: '请问有没有更详细的示例代码？',
      datetime: '2024-01-16 10:15:00',
      likes: 1
    }
  ];

  useEffect(() => {
    setLoading(true);
    setTimeout(() => {
      setContent(mockContent[type]);
      setComments(mockComments);
      setLoading(false);
    }, 500);
  }, [id, type]);

  const handleAddComment = () => {
    if (!newComment.trim()) {
      message.warning('请输入评论内容');
      return;
    }

    const comment = {
      id: Date.now(),
      author: user?.name,
      avatar: user?.avatar,
      content: newComment,
      datetime: new Date().toLocaleString(),
      likes: 0
    };

    setComments([comment, ...comments]);
    setNewComment('');
    message.success('评论发布成功');
  };

  const getStatusTag = (status) => {
    const statusMap = {
      published: { color: 'green', text: '已发布' },
      draft: { color: 'orange', text: '草稿' }
    };
    const statusInfo = statusMap[status] || { color: 'default', text: status };
    return <Tag color={statusInfo.color}>{statusInfo.text}</Tag>;
  };

  const getCategoryTag = (category) => {
    const categoryMap = {
      development: { color: 'blue', text: '开发工具' },
      productivity: { color: 'green', text: '效率工具' },
      design: { color: 'purple', text: '设计工具' },
      entertainment: { color: 'orange', text: '娱乐游戏' }
    };
    const categoryInfo = categoryMap[category] || { color: 'default', text: category };
    return <Tag color={categoryInfo.color}>{categoryInfo.text}</Tag>;
  };

  const getPlatformIcon = (platform) => {
    const icons = {
      android: <AndroidOutlined style={{ color: '#3DDC84' }} />,
      ios: <AppleOutlined style={{ color: '#007AFF' }} />,
      windows: <WindowsOutlined style={{ color: '#0078D4' }} />,
      web: <CodeOutlined style={{ color: '#FF6B35' }} />
    };
    return icons[platform] || <CodeOutlined />;
  };

  const renderContent = () => {
    if (type === 'snippets') {
      return (
        <Card className="detail-content" title="代码内容">
          <div className="code-info">
            <Tag color="blue" icon={<CodeOutlined />}>
              {content.language}
            </Tag>
          </div>
          <CodeEditor
            value={content.content}
            language={content.language}
            height={400}
            options={{ readOnly: true }}
          />
        </Card>
      );
    } else if (type === 'software') {
      return (
        <>
          <Card className="software-info" title="应用信息">
            <Row gutter={[24, 24]}>
              <Col xs={24} md={8}>
                <div className="app-icon-section">
                  <Image src={content.appIcon} width={120} height={120} />
                  <div className="app-basic-info">
                    <h3>{content.appName}</h3>
                    <p>版本：{content.version}</p>
                    <p>包名：{content.packageName}</p>
                    {getCategoryTag(content.category)}
                  </div>
                </div>
              </Col>
              <Col xs={24} md={16}>
                <div className="app-stats">
                  <Row gutter={[16, 16]}>
                    <Col span={6}>
                      <Statistic title="下载量" value={content.downloads} />
                    </Col>
                    <Col span={6}>
                      <Statistic title="浏览量" value={content.views} />
                    </Col>
                    <Col span={6}>
                      <Statistic title="点赞" value={content.likes} />
                    </Col>
                    <Col span={6}>
                      <Statistic title="评论" value={content.comments} />
                    </Col>
                  </Row>
                </div>
                <div className="download-section">
                  <Button type="primary" size="large" icon={<DownloadOutlined />}>
                    立即下载
                  </Button>
                  <div className="platform-support">
                    <span>支持平台：</span>
                    {getPlatformIcon('windows')}
                    {getPlatformIcon('android')}
                    {getPlatformIcon('ios')}
                  </div>
                </div>
              </Col>
            </Row>
          </Card>

          {content.screenshots && content.screenshots.length > 0 && (
            <Card className="screenshots-section" title="应用截图">
              <div className="screenshots-grid">
                {content.screenshots.map((screenshot, index) => (
                  <Image
                    key={index}
                    src={screenshot}
                    width={200}
                    height={150}
                    style={{ objectFit: 'cover', borderRadius: '8px' }}
                  />
                ))}
              </div>
            </Card>
          )}

          {content.isIteration && (
            <Card className="iteration-info" title="版本更新">
              <Timeline>
                <Timeline.Item color="green">
                  <div className="update-item">
                    <div className="update-version">v{content.version}</div>
                    <div className="update-content">{content.iterationDetails}</div>
                    <div className="update-time">{content.updatedAt}</div>
                  </div>
                </Timeline.Item>
              </Timeline>
            </Card>
          )}

          <Card className="detail-content" title="应用详情">
            <MarkdownRenderer content={content.content} />
          </Card>
        </>
      );
    } else {
      return (
        <Card className="detail-content" title="内容详情">
          <MarkdownRenderer content={content.content} />
        </Card>
      );
    }
  };

  if (loading || !content) {
    return <div className="loading">加载中...</div>;
  }

  return (
    <div className="content-detail">
      <Card className="detail-header">
        <div className="header-actions">
          <Button
            icon={<ArrowLeftOutlined />}
            onClick={() => navigate(-1)}
          >
            返回
          </Button>
          <Space>
            <Button icon={<ShareAltOutlined />}>分享</Button>
            <Button
              type="primary"
              icon={<EditOutlined />}
              onClick={() => navigate(`/content/${type}/${id}/edit`)}
            >
              编辑
            </Button>
          </Space>
        </div>

        <div className="content-meta">
          <h1>{content.title}</h1>
          <div className="meta-info">
            <Avatar src={content.authorAvatar} />
            <div className="author-info">
              <div className="author-name">{content.author}</div>
              <div className="publish-time">
                发布于 {content.createdAt}
                {content.updatedAt !== content.createdAt && (
                  <span> · 更新于 {content.updatedAt}</span>
                )}
              </div>
            </div>
            <div className="status-tag">
              {getStatusTag(content.status)}
            </div>
          </div>

          <div className="content-stats">
            <Space size="large">
              <span><EyeOutlined /> {content.views} 阅读</span>
              <span><LikeOutlined /> {content.likes} 点赞</span>
              <span><MessageOutlined /> {content.comments} 评论</span>
              {type === 'software' && (
                <span><DownloadOutlined /> {content.downloads} 下载</span>
              )}
            </Space>
          </div>

          <div className="content-tags">
            {content.tags.map(tag => (
              <Tag key={tag} color="blue">{tag}</Tag>
            ))}
          </div>
        </div>
      </Card>

      {renderContent()}

      <Card className="detail-comments" title={`评论 (${comments.length})`}>
        <div className="comment-form">
          <TextArea
            rows={4}
            value={newComment}
            onChange={(e) => setNewComment(e.target.value)}
            placeholder="写下你的评论..."
          />
          <div className="comment-actions">
            <Button type="primary" onClick={handleAddComment}>
              发布评论
            </Button>
          </div>
        </div>

        <Divider />

        <List
          dataSource={comments}
          renderItem={(comment) => (
            <List.Item>
              <List.Item.Meta
                avatar={<Avatar src={comment.avatar} />}
                title={comment.author}
                description={
                  <div>
                    <div style={{ marginBottom: 8 }}>{comment.content}</div>
                    <div style={{ fontSize: 12, color: '#999' }}>
                      <span>{comment.datetime}</span>
                      <span style={{ marginLeft: 16 }}>
                        <LikeOutlined /> {comment.likes}
                      </span>
                    </div>
                  </div>
                }
              />
            </List.Item>
          )}
        />
      </Card>
    </div>
  );
};

export default ContentDetail;
