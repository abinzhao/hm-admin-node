import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import {
  Card,
  Form,
  Input,
  Button,
  Select,
  Tag,
  Space,
  message,
  Upload,
  Switch,
  Row,
  Col,
  Checkbox,
  InputNumber,
  Image
} from 'antd';
import {
  ArrowLeftOutlined,
  SaveOutlined,
  EyeOutlined,
  PlusOutlined,
  UploadOutlined,
  InboxOutlined
} from '@ant-design/icons';
import { useAuth } from '../../contexts/AuthContext';
import MarkdownEditor from '../../components/MarkdownEditor';
import CodeEditor from '../../components/CodeEditor';
import './ContentEdit.scss';

const { Option } = Select;
const { Dragger } = Upload;

const ContentEdit = () => {
  const { type, id } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const [form] = Form.useForm();
  const [loading, setLoading] = useState(false);
  const [tags, setTags] = useState([]);
  const [inputTag, setInputTag] = useState('');
  const [isPublished, setIsPublished] = useState(false);
  const [content, setContent] = useState('');
  const [screenshots, setScreenshots] = useState([]);
  const [appIcon, setAppIcon] = useState('');
  const [appPackage, setAppPackage] = useState(null);
  const [isIteration, setIsIteration] = useState(false);

  const contentTypes = {
    articles: { title: '文章', placeholder: '请输入文章内容...' },
    questions: { title: '问答', placeholder: '请描述你的问题...' },
    snippets: { title: '代码片段', placeholder: '请输入代码内容...' },
    software: { title: '软件', placeholder: '请输入软件描述...' }
  };

  // 编程语言选项
  const programmingLanguages = [
    { value: 'javascript', label: 'JavaScript' },
    { value: 'typescript', label: 'TypeScript' },
    { value: 'python', label: 'Python' },
    { value: 'java', label: 'Java' },
    { value: 'cpp', label: 'C++' },
    { value: 'c', label: 'C' },
    { value: 'csharp', label: 'C#' },
    { value: 'php', label: 'PHP' },
    { value: 'go', label: 'Go' },
    { value: 'rust', label: 'Rust' },
    { value: 'swift', label: 'Swift' },
    { value: 'kotlin', label: 'Kotlin' },
    { value: 'dart', label: 'Dart' },
    { value: 'ruby', label: 'Ruby' },
    { value: 'scala', label: 'Scala' },
    { value: 'html', label: 'HTML' },
    { value: 'css', label: 'CSS' },
    { value: 'scss', label: 'SCSS' },
    { value: 'sql', label: 'SQL' },
    { value: 'shell', label: 'Shell' },
    { value: 'json', label: 'JSON' },
    { value: 'xml', label: 'XML' },
    { value: 'yaml', label: 'YAML' }
  ];

  // 软件分类选项
  const softwareCategories = [
    { value: 'productivity', label: '效率工具' },
    { value: 'development', label: '开发工具' },
    { value: 'design', label: '设计工具' },
    { value: 'entertainment', label: '娱乐游戏' },
    { value: 'education', label: '教育学习' },
    { value: 'business', label: '商务办公' },
    { value: 'social', label: '社交通讯' },
    { value: 'media', label: '影音媒体' },
    { value: 'utility', label: '系统工具' },
    { value: 'security', label: '安全防护' },
    { value: 'finance', label: '金融理财' },
    { value: 'health', label: '健康医疗' }
  ];

  const isEdit = !!id;
  const pageTitle = isEdit ? `编辑${contentTypes[type]?.title}` : `创建${contentTypes[type]?.title}`;

  useEffect(() => {
    if (isEdit) {
      setLoading(true);
      setTimeout(() => {
        let mockData = {};
        
        if (type === 'snippets') {
          mockData = {
            title: 'React Hooks 防抖实现',
            content: `import { useCallback, useRef } from 'react';

function useDebounce(callback, delay) {
  const timeoutRef = useRef(null);
  
  const debouncedCallback = useCallback((...args) => {
    if (timeoutRef.current) {
      clearTimeout(timeoutRef.current);
    }
    
    timeoutRef.current = setTimeout(() => {
      callback(...args);
    }, delay);
  }, [callback, delay]);
  
  return debouncedCallback;
}

export default useDebounce;`,
            language: 'javascript',
            status: 'published',
            tags: ['React', 'Hooks', 'JavaScript', '工具函数']
          };
        } else if (type === 'software') {
          mockData = {
            title: 'VS Code',
            packageName: 'com.microsoft.vscode',
            appName: 'Visual Studio Code',
            version: '1.85.0',
            category: 'development',
            content: '强大的代码编辑器，支持多种编程语言和丰富的插件生态。',
            isIteration: true,
            iterationDetails: '修复了一些已知问题，优化了性能，新增了AI代码补全功能。',
            status: 'published',
            tags: ['编辑器', '开发工具', 'Microsoft']
          };
          setAppIcon('https://images.unsplash.com/photo-1555066931-4365d14bab8c?w=100&h=100&fit=crop');
          setScreenshots([
            'https://images.unsplash.com/photo-1555066931-4365d14bab8c?w=400&h=300&fit=crop',
            'https://images.unsplash.com/photo-1517077304055-6e89abbf09b0?w=400&h=300&fit=crop'
          ]);
          setIsIteration(true);
        } else {
          mockData = {
            title: 'React 18 新特性详解',
            content: '这是一篇关于React 18新特性的文章...',
            status: 'published',
            tags: ['React', 'JavaScript', '前端']
          };
        }
        
        form.setFieldsValue(mockData);
        setContent(mockData.content);
        setTags(mockData.tags);
        setIsPublished(mockData.status === 'published');
        setLoading(false);
      }, 500);
    }
  }, [id, form, isEdit, type]);

  const handleSubmit = async (values) => {
    setLoading(true);
    try {
      const submitData = {
        ...values,
        content,
        tags,
        status: isPublished ? 'published' : 'draft',
        type,
        author: user?.name
      };

      // 软件特有字段
      if (type === 'software') {
        submitData.appIcon = appIcon;
        submitData.screenshots = screenshots;
        submitData.appPackage = appPackage;
        submitData.isIteration = isIteration;
      }
      
      console.log('提交数据:', submitData);
      
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      message.success(isEdit ? '更新成功！' : '创建成功！');
      navigate(`/content/${type}`);
    } catch (error) {
      message.error('操作失败，请重试');
    } finally {
      setLoading(false);
    }
  };

  const handleAddTag = () => {
    if (inputTag && !tags.includes(inputTag)) {
      setTags([...tags, inputTag]);
      setInputTag('');
    }
  };

  const handleRemoveTag = (tagToRemove) => {
    setTags(tags.filter(tag => tag !== tagToRemove));
  };

  const handlePreview = () => {
    const values = form.getFieldsValue();
    console.log('预览内容:', values);
    message.info('预览功能开发中...');
  };

  const handleScreenshotUpload = (info) => {
    if (info.file.status === 'done') {
      const newScreenshot = info.file.response?.url || URL.createObjectURL(info.file.originFileObj);
      setScreenshots([...screenshots, newScreenshot]);
      message.success('截图上传成功！');
    }
  };

  const handleIconUpload = (info) => {
    if (info.file.status === 'done') {
      const iconUrl = info.file.response?.url || URL.createObjectURL(info.file.originFileObj);
      setAppIcon(iconUrl);
      message.success('图标上传成功！');
    }
  };

  const handlePackageUpload = (info) => {
    if (info.file.status === 'done') {
      setAppPackage(info.file);
      message.success('安装包上传成功！');
    }
  };

  const renderContentEditor = () => {
    if (type === 'snippets') {
      return (
        <>
          <Form.Item
            name="language"
            label="编程语言"
            rules={[{ required: true, message: '请选择编程语言' }]}
          >
            <Select placeholder="请选择编程语言" showSearch>
              {programmingLanguages.map(lang => (
                <Option key={lang.value} value={lang.value}>
                  {lang.label}
                </Option>
              ))}
            </Select>
          </Form.Item>
          <Form.Item
            label="代码内容"
            rules={[
              { required: true, message: '请输入代码内容' },
              { min: 10, message: '内容至少10个字符' }
            ]}
          >
            <CodeEditor
              value={content}
              onChange={setContent}
              language={form.getFieldValue('language') || 'javascript'}
              height={400}
            />
          </Form.Item>
        </>
      );
    } else {
      return (
        <Form.Item
          label="内容"
          rules={[
            { required: true, message: '请输入内容' },
            { min: 10, message: '内容至少10个字符' }
          ]}
        >
          <MarkdownEditor
            value={content}
            onChange={setContent}
            height={400}
            placeholder={contentTypes[type]?.placeholder}
          />
        </Form.Item>
      );
    }
  };

  const renderSoftwareFields = () => {
    if (type !== 'software') return null;

    return (
      <>
        <Row gutter={[24, 0]}>
          <Col xs={24} md={12}>
            <Form.Item
              name="packageName"
              label="包名"
              rules={[
                { required: true, message: '请输入包名' },
                { pattern: /^[a-z][a-z0-9_]*(\.[a-z][a-z0-9_]*)*$/, message: '请输入有效的包名格式' }
              ]}
            >
              <Input placeholder="com.example.app" />
            </Form.Item>
          </Col>
          <Col xs={24} md={12}>
            <Form.Item
              name="appName"
              label="应用名称"
              rules={[{ required: true, message: '请输入应用名称' }]}
            >
              <Input placeholder="请输入应用名称" />
            </Form.Item>
          </Col>
        </Row>

        <Row gutter={[24, 0]}>
          <Col xs={24} md={12}>
            <Form.Item
              name="version"
              label="版本号"
              rules={[
                { required: true, message: '请输入版本号' },
                { pattern: /^\d+\.\d+\.\d+$/, message: '请输入有效的版本号格式(如: 1.0.0)' }
              ]}
            >
              <Input placeholder="1.0.0" />
            </Form.Item>
          </Col>
          <Col xs={24} md={12}>
            <Form.Item
              name="category"
              label="分类"
              rules={[{ required: true, message: '请选择分类' }]}
            >
              <Select placeholder="请选择软件分类">
                {softwareCategories.map(cat => (
                  <Option key={cat.value} value={cat.value}>
                    {cat.label}
                  </Option>
                ))}
              </Select>
            </Form.Item>
          </Col>
        </Row>

        <Form.Item label="应用图标">
          <div className="app-icon-upload">
            {appIcon && (
              <div className="icon-preview">
                <Image src={appIcon} width={80} height={80} />
              </div>
            )}
            <Upload
              showUploadList={false}
              beforeUpload={() => false}
              onChange={handleIconUpload}
              accept="image/*"
            >
              <Button icon={<UploadOutlined />}>
                {appIcon ? '更换图标' : '上传图标'}
              </Button>
            </Upload>
          </div>
        </Form.Item>

        <Form.Item label="应用截图">
          <div className="screenshots-upload">
            <div className="screenshots-preview">
              {screenshots.map((screenshot, index) => (
                <div key={index} className="screenshot-item">
                  <Image src={screenshot} width={120} height={80} />
                  <Button
                    type="text"
                    danger
                    size="small"
                    onClick={() => setScreenshots(screenshots.filter((_, i) => i !== index))}
                  >
                    删除
                  </Button>
                </div>
              ))}
            </div>
            <Upload
              showUploadList={false}
              beforeUpload={() => false}
              onChange={handleScreenshotUpload}
              accept="image/*"
            >
              <Button icon={<PlusOutlined />}>添加截图</Button>
            </Upload>
          </div>
        </Form.Item>

        <Form.Item label="安装包">
          <Dragger
            beforeUpload={() => false}
            onChange={handlePackageUpload}
            accept=".apk,.ipa,.exe,.dmg,.deb,.rpm"
            maxCount={1}
          >
            <p className="ant-upload-drag-icon">
              <InboxOutlined />
            </p>
            <p className="ant-upload-text">点击或拖拽文件到此区域上传</p>
            <p className="ant-upload-hint">
              支持 APK、IPA、EXE、DMG、DEB、RPM 等格式
            </p>
          </Dragger>
          {appPackage && (
            <div className="package-info">
              <p>已上传：{appPackage.name}</p>
            </div>
          )}
        </Form.Item>

        <Form.Item label="版本更新">
          <div className="iteration-setting">
            <Switch
              checked={isIteration}
              onChange={setIsIteration}
              checkedChildren="是迭代版本"
              unCheckedChildren="全新版本"
            />
          </div>
        </Form.Item>

        {isIteration && (
          <Form.Item
            name="iterationDetails"
            label="更新详情"
            rules={[{ required: true, message: '请输入更新详情' }]}
          >
            <Input.TextArea
              rows={4}
              placeholder="请描述本次更新的内容..."
            />
          </Form.Item>
        )}
      </>
    );
  };

  return (
    <div className="content-edit">
      <Card className="edit-header">
        <div className="header-actions">
          <Button
            icon={<ArrowLeftOutlined />}
            onClick={() => navigate(-1)}
          >
            返回
          </Button>
          <div className="header-title">
            <h2>{pageTitle}</h2>
          </div>
          <Space>
            <Button
              icon={<EyeOutlined />}
              onClick={handlePreview}
            >
              预览
            </Button>
            <div className="publish-switch">
              <span>发布状态：</span>
              <Switch
                checked={isPublished}
                onChange={setIsPublished}
                checkedChildren="已发布"
                unCheckedChildren="草稿"
              />
            </div>
          </Space>
        </div>
      </Card>

      <Card className="edit-form">
        <Form
          form={form}
          layout="vertical"
          onFinish={handleSubmit}
          initialValues={{
            status: 'draft'
          }}
        >
          <Form.Item
            name="title"
            label="标题"
            rules={[
              { required: true, message: '请输入标题' },
              { min: 5, message: '标题至少5个字符' },
              { max: 100, message: '标题不能超过100个字符' }
            ]}
          >
            <Input
              placeholder={`请输入${contentTypes[type]?.title}标题`}
              size="large"
            />
          </Form.Item>

          {renderSoftwareFields()}

          {renderContentEditor()}

          <Form.Item label="标签">
            <div className="tags-input">
              <div className="tags-list">
                {tags.map(tag => (
                  <Tag
                    key={tag}
                    closable
                    onClose={() => handleRemoveTag(tag)}
                    color="blue"
                  >
                    {tag}
                  </Tag>
                ))}
              </div>
              <div className="add-tag">
                <Input
                  value={inputTag}
                  onChange={(e) => setInputTag(e.target.value)}
                  onPressEnter={handleAddTag}
                  placeholder="输入标签后按回车"
                  style={{ width: 200 }}
                />
                <Button
                  type="dashed"
                  icon={<PlusOutlined />}
                  onClick={handleAddTag}
                >
                  添加标签
                </Button>
              </div>
            </div>
          </Form.Item>

          <Form.Item>
            <Space size="large">
              <Button
                type="primary"
                htmlType="submit"
                loading={loading}
                icon={<SaveOutlined />}
                size="large"
              >
                {isEdit ? '更新' : '创建'}
              </Button>
              <Button
                size="large"
                onClick={() => navigate(-1)}
              >
                取消
              </Button>
            </Space>
          </Form.Item>
        </Form>
      </Card>
    </div>
  );
};

export default ContentEdit;
