import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import {
  Card,
  Table,
  Button,
  Input,
  Select,
  Space,
  Tag,
  Avatar,
  Popconfirm,
  message,
  Tabs
} from 'antd';
import {
  PlusOutlined,
  SearchOutlined,
  EditOutlined,
  DeleteOutlined,
  EyeOutlined
} from '@ant-design/icons';
import { useAuth } from '../../contexts/AuthContext';
import Loading from '../../components/Loading';
import './ContentList.scss';

const { Search } = Input;
const { Option } = Select;

const ContentList = () => {
  const { type = 'articles' } = useParams();
  const navigate = useNavigate();
  const { user, isAdmin } = useAuth();
  const [loading, setLoading] = useState(false);
  const [searchText, setSearchText] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [data, setData] = useState([]);

  const contentTypes = {
    articles: { title: '文章管理', tag: '文章' },
    questions: { title: '问答管理', tag: '问答' },
    snippets: { title: '代码片段', tag: '代码' },
    software: { title: '软件管理', tag: '软件' }
  };

  const mockData = {
    articles: [
      {
        id: 1,
        title: 'React 18 新特性详解',
        author: '张三',
        authorAvatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=40&h=40&fit=crop&crop=face',
        status: 'published',
        views: 1234,
        likes: 56,
        comments: 12,
        createdAt: '2024-01-15',
        updatedAt: '2024-01-16'
      },
      {
        id: 2,
        title: 'Vue 3 Composition API 最佳实践',
        author: '李四',
        authorAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=40&h=40&fit=crop&crop=face',
        status: 'draft',
        views: 890,
        likes: 34,
        comments: 8,
        createdAt: '2024-01-14',
        updatedAt: '2024-01-15'
      }
    ],
    questions: [
      {
        id: 1,
        title: '如何优化React性能？',
        author: '王五',
        authorAvatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=40&h=40&fit=crop&crop=face',
        status: 'answered',
        views: 567,
        likes: 23,
        comments: 15,
        createdAt: '2024-01-13',
        updatedAt: '2024-01-14'
      }
    ],
    snippets: [
      {
        id: 1,
        title: '防抖函数实现',
        author: '赵六',
        authorAvatar: 'https://images.unsplash.com/photo-1519244703995-f4e0f30006d5?w=40&h=40&fit=crop&crop=face',
        status: 'published',
        views: 345,
        likes: 18,
        comments: 5,
        createdAt: '2024-01-12',
        updatedAt: '2024-01-13'
      }
    ],
    software: [
      {
        id: 1,
        title: 'VS Code 插件推荐',
        author: '孙七',
        authorAvatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=40&h=40&fit=crop&crop=face',
        status: 'published',
        views: 789,
        likes: 45,
        comments: 20,
        createdAt: '2024-01-11',
        updatedAt: '2024-01-12'
      }
    ]
  };

  useEffect(() => {
    setLoading(true);
    setTimeout(() => {
      setData(mockData[type] || []);
      setLoading(false);
    }, 500);
  }, [type]);

  const getStatusTag = (status) => {
    const statusMap = {
      published: { color: 'green', text: '已发布' },
      draft: { color: 'orange', text: '草稿' },
      answered: { color: 'blue', text: '已回答' },
      pending: { color: 'red', text: '待审核' }
    };
    const statusInfo = statusMap[status] || { color: 'default', text: status };
    return <Tag color={statusInfo.color}>{statusInfo.text}</Tag>;
  };

  const handleDelete = (id) => {
    setData(data.filter(item => item.id !== id));
    message.success('删除成功');
  };

  const columns = [
    {
      title: '标题',
      dataIndex: 'title',
      key: 'title',
      render: (text, record) => (
        <div className="title-cell">
          <div className="title">{text}</div>
          <div className="meta">
            <Avatar src={record.authorAvatar} size="small" />
            <span>{record.author}</span>
            <span>{record.createdAt}</span>
          </div>
        </div>
      )
    },
    {
      title: '状态',
      dataIndex: 'status',
      key: 'status',
      width: 100,
      render: getStatusTag
    },
    {
      title: '数据',
      key: 'stats',
      width: 150,
      render: (_, record) => (
        <div className="stats-cell">
          <div><EyeOutlined /> {record.views}</div>
          <div>👍 {record.likes}</div>
          <div>💬 {record.comments}</div>
        </div>
      )
    },
    {
      title: '操作',
      key: 'actions',
      width: 150,
      render: (_, record) => (
        <Space>
          <Button
            type="text"
            icon={<EyeOutlined />}
            onClick={() => navigate(`/content/${type}/${record.id}`)}
          />
          <Button
            type="text"
            icon={<EditOutlined />}
            onClick={() => navigate(`/content/${type}/${record.id}/edit`)}
          />
          {(isAdmin || record.author === user?.name) && (
            <Popconfirm
              title="确定要删除吗？"
              onConfirm={() => handleDelete(record.id)}
            >
              <Button type="text" danger icon={<DeleteOutlined />} />
            </Popconfirm>
          )}
        </Space>
      )
    }
  ];

  const tabItems = [
    { key: 'articles', label: '文章' },
    { key: 'questions', label: '问答' },
    { key: 'snippets', label: '代码片段' },
    { key: 'software', label: '软件' }
  ];

  return (
    <div className="content-list">
      <Card className="content-header">
        <div className="header-top">
          <h2>{contentTypes[type]?.title}</h2>
          <Button
            type="primary"
            icon={<PlusOutlined />}
            onClick={() => navigate(`/content/${type}/create`)}
          >
            新建{contentTypes[type]?.tag}
          </Button>
        </div>

        <Tabs
          activeKey={type}
          items={tabItems}
          onChange={(key) => navigate(`/content/${key}`)}
          className="content-tabs"
        />

        <div className="filters">
          <Search
            placeholder="搜索标题或作者"
            value={searchText}
            onChange={(e) => setSearchText(e.target.value)}
            style={{ width: 300 }}
          />
          <Select
            value={statusFilter}
            onChange={setStatusFilter}
            style={{ width: 120 }}
          >
            <Option value="all">全部状态</Option>
            <Option value="published">已发布</Option>
            <Option value="draft">草稿</Option>
            <Option value="pending">待审核</Option>
          </Select>
        </div>
      </Card>

      <Card className="content-table">
        <Table
          columns={columns}
          dataSource={data}
          loading={loading ? { indicator: <Loading type="spinner" /> } : false}
          rowKey="id"
          pagination={{
            total: data.length,
            pageSize: 10,
            showSizeChanger: true,
            showQuickJumper: true,
            showTotal: (total) => `共 ${total} 条记录`
          }}
        />
      </Card>
    </div>
  );
};

export default ContentList;
