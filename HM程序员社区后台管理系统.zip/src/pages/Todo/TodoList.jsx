import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Card,
  Table,
  Button,
  Input,
  Select,
  Space,
  Tag,
  Avatar,
  Popconfirm,
  message,
  Progress,
  Checkbox
} from 'antd';
import {
  PlusOutlined,
  SearchOutlined,
  EditOutlined,
  DeleteOutlined,
  EyeOutlined,
  CheckSquareOutlined,
  ClockCircleOutlined
} from '@ant-design/icons';
import { useAuth } from '../../contexts/AuthContext';
import './TodoList.scss';

const { Search } = Input;
const { Option } = Select;

const TodoList = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [loading, setLoading] = useState(false);
  const [searchText, setSearchText] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [priorityFilter, setPriorityFilter] = useState('all');
  const [data, setData] = useState([]);

  const mockData = [
    {
      id: 1,
      title: '完成用户管理模块开发',
      description: '实现用户列表、用户详情、用户编辑等功能',
      status: 'in_progress',
      priority: 'high',
      progress: 75,
      assignee: '张三',
      assigneeAvatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=40&h=40&fit=crop&crop=face',
      dueDate: '2024-01-20',
      createdAt: '2024-01-15 10:30:00',
      updatedAt: '2024-01-16 14:20:00'
    },
    {
      id: 2,
      title: '优化系统性能',
      description: '对数据库查询进行优化，提升页面加载速度',
      status: 'pending',
      priority: 'medium',
      progress: 30,
      assignee: '李四',
      assigneeAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=40&h=40&fit=crop&crop=face',
      dueDate: '2024-01-25',
      createdAt: '2024-01-14 09:15:00',
      updatedAt: '2024-01-15 16:30:00'
    },
    {
      id: 3,
      title: '编写API文档',
      description: '为所有接口编写详细的API文档',
      status: 'completed',
      priority: 'low',
      progress: 100,
      assignee: '王五',
      assigneeAvatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=40&h=40&fit=crop&crop=face',
      dueDate: '2024-01-18',
      createdAt: '2024-01-12 14:45:00',
      updatedAt: '2024-01-18 11:20:00'
    },
    {
      id: 4,
      title: '修复登录页面样式问题',
      description: '修复移动端登录页面的样式显示问题',
      status: 'overdue',
      priority: 'high',
      progress: 0,
      assignee: '赵六',
      assigneeAvatar: 'https://images.unsplash.com/photo-1519244703995-f4e0f30006d5?w=40&h=40&fit=crop&crop=face',
      dueDate: '2024-01-10',
      createdAt: '2024-01-08 16:20:00',
      updatedAt: '2024-01-10 09:30:00'
    }
  ];

  useEffect(() => {
    setLoading(true);
    setTimeout(() => {
      setData(mockData);
      setLoading(false);
    }, 500);
  }, []);

  const getStatusTag = (status) => {
    const statusMap = {
      pending: { color: 'orange', text: '待开始', icon: <ClockCircleOutlined /> },
      in_progress: { color: 'blue', text: '进行中', icon: <ClockCircleOutlined /> },
      completed: { color: 'green', text: '已完成', icon: <CheckSquareOutlined /> },
      overdue: { color: 'red', text: '已逾期', icon: <ClockCircleOutlined /> }
    };
    const statusInfo = statusMap[status] || { color: 'default', text: status, icon: null };
    return (
      <Tag color={statusInfo.color} icon={statusInfo.icon}>
        {statusInfo.text}
      </Tag>
    );
  };

  const getPriorityTag = (priority) => {
    const priorityMap = {
      high: { color: 'red', text: '高' },
      medium: { color: 'orange', text: '中' },
      low: { color: 'green', text: '低' }
    };
    const priorityInfo = priorityMap[priority] || { color: 'default', text: priority };
    return <Tag color={priorityInfo.color}>{priorityInfo.text}</Tag>;
  };

  const handleDelete = (id) => {
    setData(data.filter(item => item.id !== id));
    message.success('删除成功');
  };

  const handleToggleStatus = (id, currentStatus) => {
    const newStatus = currentStatus === 'completed' ? 'in_progress' : 'completed';
    const newProgress = newStatus === 'completed' ? 100 : 75;
    
    setData(data.map(item => 
      item.id === id 
        ? { ...item, status: newStatus, progress: newProgress, updatedAt: new Date().toLocaleString() }
        : item
    ));
    
    message.success(newStatus === 'completed' ? '任务已完成' : '任务重新开始');
  };

  const columns = [
    {
      title: '任务信息',
      dataIndex: 'title',
      key: 'title',
      render: (text, record) => (
        <div className="todo-cell">
          <div className="todo-header">
            <Checkbox
              checked={record.status === 'completed'}
              onChange={() => handleToggleStatus(record.id, record.status)}
            />
            <div className="todo-title">{text}</div>
          </div>
          <div className="todo-description">{record.description}</div>
          <div className="todo-progress">
            <Progress percent={record.progress} size="small" />
          </div>
          <div className="todo-meta">
            <Avatar src={record.assigneeAvatar} size="small" />
            <span>{record.assignee}</span>
            <span>截止：{record.dueDate}</span>
          </div>
        </div>
      )
    },
    {
      title: '优先级',
      dataIndex: 'priority',
      key: 'priority',
      width: 80,
      render: getPriorityTag
    },
    {
      title: '状态',
      dataIndex: 'status',
      key: 'status',
      width: 100,
      render: getStatusTag
    },
    {
      title: '进度',
      dataIndex: 'progress',
      key: 'progress',
      width: 120,
      render: (progress, record) => (
        <div className="progress-cell">
          <Progress
            percent={progress}
            size="small"
            status={record.status === 'overdue' ? 'exception' : 'normal'}
          />
        </div>
      )
    },
    {
      title: '操作',
      key: 'actions',
      width: 150,
      render: (_, record) => (
        <Space>
          <Button
            type="text"
            icon={<EyeOutlined />}
            onClick={() => navigate(`/todos/${record.id}`)}
          />
          <Button
            type="text"
            icon={<EditOutlined />}
            onClick={() => navigate(`/todos/${record.id}/edit`)}
          />
          <Popconfirm
            title="确定要删除吗？"
            onConfirm={() => handleDelete(record.id)}
          >
            <Button type="text" danger icon={<DeleteOutlined />} />
          </Popconfirm>
        </Space>
      )
    }
  ];

  const filteredData = data.filter(item => {
    const matchSearch = item.title.toLowerCase().includes(searchText.toLowerCase()) ||
                       item.description.toLowerCase().includes(searchText.toLowerCase());
    const matchStatus = statusFilter === 'all' || item.status === statusFilter;
    const matchPriority = priorityFilter === 'all' || item.priority === priorityFilter;
    
    return matchSearch && matchStatus && matchPriority;
  });

  return (
    <div className="todo-list">
      <Card className="todo-header">
        <div className="header-top">
          <h2>待办事项</h2>
          <Button
            type="primary"
            icon={<PlusOutlined />}
            onClick={() => navigate('/todos/create')}
          >
            新建任务
          </Button>
        </div>

        <div className="filters">
          <Search
            placeholder="搜索任务标题或描述"
            value={searchText}
            onChange={(e) => setSearchText(e.target.value)}
            style={{ width: 300 }}
          />
          <Select
            value={statusFilter}
            onChange={setStatusFilter}
            style={{ width: 120 }}
          >
            <Option value="all">全部状态</Option>
            <Option value="pending">待开始</Option>
            <Option value="in_progress">进行中</Option>
            <Option value="completed">已完成</Option>
            <Option value="overdue">已逾期</Option>
          </Select>
          <Select
            value={priorityFilter}
            onChange={setPriorityFilter}
            style={{ width: 120 }}
          >
            <Option value="all">全部优先级</Option>
            <Option value="high">高优先级</Option>
            <Option value="medium">中优先级</Option>
            <Option value="low">低优先级</Option>
          </Select>
        </div>
      </Card>

      <Card className="todo-table">
        <Table
          columns={columns}
          dataSource={filteredData}
          loading={loading}
          rowKey="id"
          pagination={{
            total: filteredData.length,
            pageSize: 10,
            showSizeChanger: true,
            showQuickJumper: true,
            showTotal: (total) => `共 ${total} 个任务`
          }}
        />
      </Card>
    </div>
  );
};

export default TodoList;
