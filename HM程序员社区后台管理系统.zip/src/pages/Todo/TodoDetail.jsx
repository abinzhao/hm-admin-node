import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import {
  Card,
  Button,
  Avatar,
  Tag,
  Space,
  Divider,
  Progress,
  Row,
  Col,
  Timeline,
  Statistic,
  message,
  Checkbox
} from 'antd';
import {
  ArrowLeftOutlined,
  EditOutlined,
  CheckSquareOutlined,
  ClockCircleOutlined,
  UserOutlined,
  CalendarOutlined
} from '@ant-design/icons';
import { useAuth } from '../../contexts/AuthContext';
import MarkdownRenderer from '../../components/MarkdownPreview';
import './TodoDetail.scss';

const TodoDetail = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const [loading, setLoading] = useState(false);
  const [todo, setTodo] = useState(null);

  const mockTodo = {
    id: 1,
    title: '完成用户管理模块开发',
    description: `
# 用户管理模块开发任务

## 任务描述
实现完整的用户管理功能，包括用户列表、用户详情、用户编辑等核心功能。

## 具体要求
1. **用户列表页面**
   - 支持分页显示
   - 支持搜索和筛选
   - 显示用户基本信息

2. **用户详情页面**
   - 显示用户完整信息
   - 显示用户活动记录
   - 支持权限管理

3. **用户编辑功能**
   - 支持编辑用户基本信息
   - 支持角色权限设置
   - 表单验证和错误处理

## 技术要求
- 使用React + Ant Design
- 响应式设计
- 数据持久化

## 验收标准
- [ ] 用户列表功能完整
- [ ] 用户详情页面完善
- [ ] 用户编辑功能正常
- [ ] 权限控制正确
- [x] 页面响应式适配
    `,
    status: 'in_progress',
    priority: 'high',
    progress: 75,
    assignee: '张三',
    assigneeAvatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=40&h=40&fit=crop&crop=face',
    creator: '项目经理',
    creatorAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=40&h=40&fit=crop&crop=face',
    dueDate: '2024-01-20',
    createdAt: '2024-01-15 10:30:00',
    updatedAt: '2024-01-16 14:20:00',
    estimatedHours: 40,
    actualHours: 30
  };

  const mockTimeline = [
    {
      time: '2024-01-16 14:20:00',
      action: '更新进度至75%',
      user: '张三',
      status: 'success',
      description: '完成用户列表和详情页面开发'
    },
    {
      time: '2024-01-15 16:30:00',
      action: '开始开发',
      user: '张三',
      status: 'success',
      description: '开始用户管理模块开发工作'
    },
    {
      time: '2024-01-15 10:30:00',
      action: '任务创建',
      user: '项目经理',
      status: 'success',
      description: '创建用户管理模块开发任务'
    }
  ];

  useEffect(() => {
    setLoading(true);
    setTimeout(() => {
      setTodo(mockTodo);
      setLoading(false);
    }, 500);
  }, [id]);

  const getStatusTag = (status) => {
    const statusMap = {
      pending: { color: 'orange', text: '待开始', icon: <ClockCircleOutlined /> },
      in_progress: { color: 'blue', text: '进行中', icon: <ClockCircleOutlined /> },
      completed: { color: 'green', text: '已完成', icon: <CheckSquareOutlined /> },
      overdue: { color: 'red', text: '已逾期', icon: <ClockCircleOutlined /> }
    };
    const statusInfo = statusMap[status] || { color: 'default', text: status, icon: null };
    return (
      <Tag color={statusInfo.color} icon={statusInfo.icon} style={{ fontSize: '14px', padding: '4px 12px' }}>
        {statusInfo.text}
      </Tag>
    );
  };

  const getPriorityTag = (priority) => {
    const priorityMap = {
      high: { color: 'red', text: '高优先级' },
      medium: { color: 'orange', text: '中优先级' },
      low: { color: 'green', text: '低优先级' }
    };
    const priorityInfo = priorityMap[priority] || { color: 'default', text: priority };
    return (
      <Tag color={priorityInfo.color} style={{ fontSize: '14px', padding: '4px 12px' }}>
        {priorityInfo.text}
      </Tag>
    );
  };

  const handleToggleStatus = () => {
    const newStatus = todo.status === 'completed' ? 'in_progress' : 'completed';
    const newProgress = newStatus === 'completed' ? 100 : todo.progress;
    
    setTodo({
      ...todo,
      status: newStatus,
      progress: newProgress,
      updatedAt: new Date().toLocaleString()
    });
    
    message.success(newStatus === 'completed' ? '任务已完成' : '任务重新开始');
  };

  if (loading || !todo) {
    return <div className="loading">加载中...</div>;
  }

  return (
    <div className="todo-detail">
      <Card className="detail-header">
        <div className="header-actions">
          <Button
            icon={<ArrowLeftOutlined />}
            onClick={() => navigate(-1)}
          >
            返回
          </Button>
          <Space>
            <Checkbox
              checked={todo.status === 'completed'}
              onChange={handleToggleStatus}
            >
              标记完成
            </Checkbox>
            <Button
              type="primary"
              icon={<EditOutlined />}
              onClick={() => navigate(`/todos/${id}/edit`)}
            >
              编辑
            </Button>
          </Space>
        </div>

        <div className="todo-meta">
          <div className="title-section">
            <CheckSquareOutlined className="todo-icon" />
            <h1>{todo.title}</h1>
          </div>
          
          <div className="meta-info">
            <div className="assignee-info">
              <Avatar src={todo.assigneeAvatar} size="large" />
              <div className="user-info">
                <div className="user-name">负责人：{todo.assignee}</div>
                <div className="creator-name">创建者：{todo.creator}</div>
              </div>
            </div>
            <div className="tags-section">
              {getStatusTag(todo.status)}
              {getPriorityTag(todo.priority)}
            </div>
          </div>

          <div className="progress-section">
            <div className="progress-info">
              <span>任务进度</span>
              <span>{todo.progress}%</span>
            </div>
            <Progress
              percent={todo.progress}
              status={todo.status === 'overdue' ? 'exception' : 'normal'}
              strokeWidth={8}
            />
          </div>
        </div>
      </Card>

      <Row gutter={[24, 24]}>
        <Col xs={24} lg={16}>
          <Card className="detail-content" title="任务详情">
            <MarkdownRenderer content={todo.description} />
          </Card>
        </Col>

        <Col xs={24} lg={8}>
          <Card className="detail-stats" title="任务统计">
            <Row gutter={[16, 16]}>
              <Col span={12}>
                <Statistic
                  title="预估工时"
                  value={todo.estimatedHours}
                  suffix="小时"
                  prefix={<ClockCircleOutlined />}
                />
              </Col>
              <Col span={12}>
                <Statistic
                  title="实际工时"
                  value={todo.actualHours}
                  suffix="小时"
                  prefix={<ClockCircleOutlined />}
                />
              </Col>
              <Col span={12}>
                <Statistic
                  title="截止日期"
                  value={todo.dueDate}
                  prefix={<CalendarOutlined />}
                />
              </Col>
              <Col span={12}>
                <Statistic
                  title="负责人"
                  value={todo.assignee}
                  prefix={<UserOutlined />}
                />
              </Col>
            </Row>
          </Card>

          <Card className="detail-timeline" title="操作记录">
            <Timeline>
              {mockTimeline.map((item, index) => (
                <Timeline.Item
                  key={index}
                  dot={
                    item.status === 'success' ? (
                      <CheckSquareOutlined style={{ color: '#52c41a' }} />
                    ) : (
                      <ClockCircleOutlined style={{ color: '#1890ff' }} />
                    )
                  }
                >
                  <div className="timeline-content">
                    <div className="timeline-action">{item.action}</div>
                    <div className="timeline-description">{item.description}</div>
                    <div className="timeline-meta">
                      <span>{item.user}</span>
                      <span>{item.time}</span>
                    </div>
                  </div>
                </Timeline.Item>
              ))}
            </Timeline>
          </Card>
        </Col>
      </Row>
    </div>
  );
};

export default TodoDetail;
