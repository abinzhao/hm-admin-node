import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import {
  Card,
  Form,
  Input,
  Button,
  Select,
  Space,
  message,
  DatePicker,
  InputNumber,
  Slider,
  Divider
} from 'antd';
import {
  ArrowLeftOutlined,
  SaveOutlined,
  EyeOutlined,
  CheckSquareOutlined
} from '@ant-design/icons';
import { useAuth } from '../../contexts/AuthContext';
import dayjs from 'dayjs';
import './TodoEdit.scss';

const { TextArea } = Input;
const { Option } = Select;

const TodoEdit = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const [form] = Form.useForm();
  const [loading, setLoading] = useState(false);
  const [progress, setProgress] = useState(0);

  const isEdit = !!id;
  const pageTitle = isEdit ? '编辑任务' : '创建任务';

  useEffect(() => {
    if (isEdit) {
      setLoading(true);
      setTimeout(() => {
        const mockData = {
          title: '完成用户管理模块开发',
          description: '实现完整的用户管理功能，包括用户列表、用户详情、用户编辑等核心功能。',
          priority: 'high',
          status: 'in_progress',
          assignee: '张三',
          dueDate: dayjs('2024-01-20'),
          estimatedHours: 40,
          progress: 75
        };
        
        form.setFieldsValue(mockData);
        setProgress(mockData.progress);
        setLoading(false);
      }, 500);
    }
  }, [id, form, isEdit]);

  const handleSubmit = async (values) => {
    setLoading(true);
    try {
      const submitData = {
        ...values,
        progress,
        creator: user?.name,
        dueDate: values.dueDate?.format('YYYY-MM-DD'),
        updatedAt: new Date().toLocaleString()
      };
      
      console.log('提交数据:', submitData);
      
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      message.success(isEdit ? '更新成功！' : '创建成功！');
      navigate('/todos');
    } catch (error) {
      message.error('操作失败，请重试');
    } finally {
      setLoading(false);
    }
  };

  const handlePreview = () => {
    const values = form.getFieldsValue();
    console.log('预览内容:', values);
    message.info('预览功能开发中...');
  };

  const mockUsers = [
    { value: '张三', label: '张三' },
    { value: '李四', label: '李四' },
    { value: '王五', label: '王五' },
    { value: '赵六', label: '赵六' }
  ];

  return (
    <div className="todo-edit">
      <Card className="edit-header">
        <div className="header-actions">
          <Button
            icon={<ArrowLeftOutlined />}
            onClick={() => navigate(-1)}
          >
            返回
          </Button>
          <div className="header-title">
            <CheckSquareOutlined />
            <h2>{pageTitle}</h2>
          </div>
          <Space>
            <Button
              icon={<EyeOutlined />}
              onClick={handlePreview}
            >
              预览
            </Button>
          </Space>
        </div>
      </Card>

      <Card className="edit-form">
        <Form
          form={form}
          layout="vertical"
          onFinish={handleSubmit}
          initialValues={{
            priority: 'medium',
            status: 'pending',
            assignee: user?.name,
            estimatedHours: 8,
            progress: 0
          }}
        >
          <Form.Item
            name="title"
            label="任务标题"
            rules={[
              { required: true, message: '请输入任务标题' },
              { min: 5, message: '标题至少5个字符' },
              { max: 100, message: '标题不能超过100个字符' }
            ]}
          >
            <Input
              placeholder="请输入任务标题"
              size="large"
            />
          </Form.Item>

          <Form.Item
            name="description"
            label="任务描述"
            rules={[
              { required: true, message: '请输入任务描述' },
              { min: 10, message: '描述至少10个字符' }
            ]}
          >
            <TextArea
              rows={10}
              placeholder="请详细描述任务内容、要求和验收标准"
            />
          </Form.Item>

          <div className="form-row">
            <Form.Item
              name="priority"
              label="优先级"
              rules={[{ required: true, message: '请选择优先级' }]}
            >
              <Select placeholder="请选择优先级">
                <Option value="high">🔴 高优先级</Option>
                <Option value="medium">🟡 中优先级</Option>
                <Option value="low">🟢 低优先级</Option>
              </Select>
            </Form.Item>

            <Form.Item
              name="status"
              label="任务状态"
              rules={[{ required: true, message: '请选择任务状态' }]}
            >
              <Select placeholder="请选择任务状态">
                <Option value="pending">⏳ 待开始</Option>
                <Option value="in_progress">🔄 进行中</Option>
                <Option value="completed">✅ 已完成</Option>
                <Option value="overdue">⚠️ 已逾期</Option>
              </Select>
            </Form.Item>
          </div>

          <div className="form-row">
            <Form.Item
              name="assignee"
              label="负责人"
              rules={[{ required: true, message: '请选择负责人' }]}
            >
              <Select placeholder="请选择负责人">
                {mockUsers.map(user => (
                  <Option key={user.value} value={user.value}>
                    {user.label}
                  </Option>
                ))}
              </Select>
            </Form.Item>

            <Form.Item
              name="dueDate"
              label="截止日期"
              rules={[{ required: true, message: '请选择截止日期' }]}
            >
              <DatePicker
                placeholder="请选择截止日期"
                style={{ width: '100%' }}
                format="YYYY-MM-DD"
              />
            </Form.Item>
          </div>

          <Form.Item
            name="estimatedHours"
            label="预估工时（小时）"
            rules={[
              { required: true, message: '请输入预估工时' },
              { type: 'number', min: 1, max: 200, message: '工时范围1-200小时' }
            ]}
          >
            <InputNumber
              placeholder="请输入预估工时"
              style={{ width: '100%' }}
              min={1}
              max={200}
            />
          </Form.Item>

          {isEdit && (
            <>
              <Divider>进度管理</Divider>
              
              <Form.Item label={`任务进度：${progress}%`}>
                <Slider
                  value={progress}
                  onChange={setProgress}
                  marks={{
                    0: '0%',
                    25: '25%',
                    50: '50%',
                    75: '75%',
                    100: '100%'
                  }}
                  step={5}
                />
              </Form.Item>
            </>
          )}

          <Form.Item>
            <Space size="large">
              <Button
                type="primary"
                htmlType="submit"
                loading={loading}
                icon={<SaveOutlined />}
                size="large"
              >
                {isEdit ? '更新任务' : '创建任务'}
              </Button>
              <Button
                size="large"
                onClick={() => navigate(-1)}
              >
                取消
              </Button>
            </Space>
          </Form.Item>
        </Form>
      </Card>
    </div>
  );
};

export default TodoEdit;
