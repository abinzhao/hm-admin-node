const mockArticles = [
  {
    id: 1,
    title: 'React 18 新特性详解',
    content: `# React 18 新特性详解

React 18 是 React 的一个重大版本更新，引入了许多令人兴奋的新特性和改进。

## 1. 并发特性 (Concurrent Features)

React 18 引入了并发渲染，这是 React 的一个重大改进。

### 主要优势：
- 更好的用户体验
- 更流畅的动画
- 更快的响应时间

## 2. 自动批处理 (Automatic Batching)

React 18 扩展了批处理功能，现在可以自动批处理更多的更新。

\`\`\`javascript
setTimeout(() => {
  setCount(c => c + 1);
  setFlag(f => !f);
  // React 只会重新渲染一次
}, 1000);
\`\`\`

## 3. 新的 Hooks

### useId
用于生成唯一的 ID，特别适用于可访问性属性。

### useDeferredValue
用于延迟更新非紧急的值。

### useTransition
用于标记非紧急的状态更新。`,
    author: '张三',
    authorAvatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=40&h=40&fit=crop&crop=face',
    status: 'published',
    views: 1234,
    likes: 56,
    comments: 12,
    tags: ['React', 'JavaScript', '前端'],
    createdAt: '2024-01-15 10:30:00',
    updatedAt: '2024-01-16 14:20:00'
  }
];

const mockQuestions = [
  {
    id: 1,
    title: '如何优化React性能？',
    content: '我在开发React应用时遇到了性能问题，请问有什么优化方法？',
    author: '王五',
    authorAvatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=40&h=40&fit=crop&crop=face',
    status: 'answered',
    views: 567,
    likes: 23,
    comments: 15,
    tags: ['React', '性能优化'],
    createdAt: '2024-01-13 16:45:00',
    updatedAt: '2024-01-14 09:20:00'
  }
];

const mockSnippets = [
  {
    id: 1,
    title: '防抖函数实现',
    content: `function debounce(func, wait) {
  let timeout;
  return function executedFunction(...args) {
    const later = () => {
      clearTimeout(timeout);
      func(...args);
    };
    clearTimeout(timeout);
    timeout = setTimeout(later, wait);
  };
}`,
    author: '赵六',
    authorAvatar: 'https://images.unsplash.com/photo-1519244703995-f4e0f30006d5?w=40&h=40&fit=crop&crop=face',
    status: 'published',
    views: 345,
    likes: 18,
    comments: 5,
    tags: ['JavaScript', '工具函数'],
    createdAt: '2024-01-12 14:30:00',
    updatedAt: '2024-01-13 10:15:00'
  }
];

const mockSoftware = [
  {
    id: 1,
    title: 'VS Code 插件推荐',
    content: '推荐一些提高开发效率的VS Code插件',
    author: '孙七',
    authorAvatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=40&h=40&fit=crop&crop=face',
    status: 'published',
    views: 789,
    likes: 45,
    comments: 20,
    downloadUrl: 'https://marketplace.visualstudio.com/',
    tags: ['工具', 'VS Code'],
    createdAt: '2024-01-11 11:20:00',
    updatedAt: '2024-01-12 15:30:00'
  }
];

const mockData = {
  articles: mockArticles,
  questions: mockQuestions,
  snippets: mockSnippets,
  software: mockSoftware
};

export const mockContent = {
  getContentList: async (type, params) => {
    await new Promise(resolve => setTimeout(resolve, 500));
    
    const data = mockData[type] || [];
    return {
      code: 200,
      data: {
        list: data,
        total: data.length,
        page: params.page || 1,
        pageSize: params.pageSize || 10
      },
      message: '获取成功'
    };
  },

  getContentDetail: async (type, id) => {
    await new Promise(resolve => setTimeout(resolve, 500));
    
    const data = mockData[type] || [];
    const item = data.find(item => item.id === parseInt(id));
    
    if (!item) {
      throw new Error('内容不存在');
    }
    
    return {
      code: 200,
      data: item,
      message: '获取成功'
    };
  },

  createContent: async (type, data) => {
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    const newItem = {
      id: Date.now(),
      ...data,
      createdAt: new Date().toLocaleString(),
      updatedAt: new Date().toLocaleString(),
      views: 0,
      likes: 0,
      comments: 0
    };
    
    return {
      code: 200,
      data: newItem,
      message: '创建成功'
    };
  },

  updateContent: async (type, id, data) => {
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    return {
      code: 200,
      data: { ...data, id, updatedAt: new Date().toLocaleString() },
      message: '更新成功'
    };
  },

  deleteContent: async (type, id) => {
    await new Promise(resolve => setTimeout(resolve, 500));
    
    return {
      code: 200,
      data: null,
      message: '删除成功'
    };
  },

  getComments: async (type, id) => {
    await new Promise(resolve => setTimeout(resolve, 500));
    
    const mockComments = [
      {
        id: 1,
        author: '李四',
        avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=40&h=40&fit=crop&crop=face',
        content: '写得很好！很有帮助。',
        datetime: '2024-01-16 09:00:00',
        likes: 3
      }
    ];
    
    return {
      code: 200,
      data: mockComments,
      message: '获取成功'
    };
  },

  addComment: async (type, id, comment) => {
    await new Promise(resolve => setTimeout(resolve, 500));
    
    const newComment = {
      id: Date.now(),
      ...comment,
      datetime: new Date().toLocaleString(),
      likes: 0
    };
    
    return {
      code: 200,
      data: newComment,
      message: '评论成功'
    };
  }
};
