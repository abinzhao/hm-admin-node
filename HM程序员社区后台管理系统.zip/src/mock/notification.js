const mockNotifications = [
  {
    id: 1,
    title: '系统维护通知',
    content: `# 系统维护通知

亲爱的用户们，

为了提供更好的服务体验，我们将于今晚进行系统维护升级。

## 维护时间
**2024年1月15日 22:00 - 24:00**

## 维护内容
1. 服务器性能优化
2. 数据库升级
3. 安全补丁更新
4. 新功能部署

## 影响范围
- 网站可能无法正常访问
- 移动端应用可能出现异常
- 数据同步可能延迟

感谢您的理解与支持！`,
    type: 'system',
    priority: 'high',
    status: 'published',
    author: '系统管理员',
    authorAvatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=40&h=40&fit=crop&crop=face',
    readCount: 1234,
    targetUsers: 'all',
    createdAt: '2024-01-15 10:30:00',
    publishAt: '2024-01-15 10:30:00',
    updatedAt: '2024-01-15 10:30:00'
  }
];

export const mockNotification = {
  getNotificationList: async (params) => {
    await new Promise(resolve => setTimeout(resolve, 500));
    
    return {
      code: 200,
      data: {
        list: mockNotifications,
        total: mockNotifications.length,
        page: params.page || 1,
        pageSize: params.pageSize || 10
      },
      message: '获取成功'
    };
  },

  getNotificationDetail: async (id) => {
    await new Promise(resolve => setTimeout(resolve, 500));
    
    const notification = mockNotifications.find(item => item.id === parseInt(id));
    
    if (!notification) {
      throw new Error('通知不存在');
    }
    
    return {
      code: 200,
      data: notification,
      message: '获取成功'
    };
  },

  createNotification: async (data) => {
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    const newNotification = {
      id: Date.now(),
      ...data,
      readCount: 0,
      createdAt: new Date().toLocaleString(),
      updatedAt: new Date().toLocaleString()
    };
    
    return {
      code: 200,
      data: newNotification,
      message: '创建成功'
    };
  },

  updateNotification: async (id, data) => {
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    return {
      code: 200,
      data: { ...data, id, updatedAt: new Date().toLocaleString() },
      message: '更新成功'
    };
  },

  deleteNotification: async (id) => {
    await new Promise(resolve => setTimeout(resolve, 500));
    
    return {
      code: 200,
      data: null,
      message: '删除成功'
    };
  },

  publishNotification: async (id) => {
    await new Promise(resolve => setTimeout(resolve, 500));
    
    return {
      code: 200,
      data: null,
      message: '发布成功'
    };
  }
};
