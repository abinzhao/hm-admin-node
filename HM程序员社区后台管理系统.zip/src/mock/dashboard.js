export const mockDashboard = {
  getStats: async () => {
    await new Promise(resolve => setTimeout(resolve, 500));
    
    return {
      code: 200,
      data: {
        totalUsers: 1248,
        totalContent: 856,
        totalNotifications: 23,
        totalTodos: 12,
        userGrowth: 12.5,
        contentGrowth: 8.3,
        notificationGrowth: 15.2,
        todoCompletion: 75
      },
      message: '获取成功'
    };
  },

  getRecentActivities: async () => {
    await new Promise(resolve => setTimeout(resolve, 500));
    
    const activities = [
      {
        id: 1,
        type: 'content',
        title: '发布了新文章《React 18 新特性详解》',
        user: '张三',
        avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=40&h=40&fit=crop&crop=face',
        time: '2小时前',
        tag: '文章'
      },
      {
        id: 2,
        type: 'question',
        title: '回答了问题《如何优化React性能？》',
        user: '李四',
        avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=40&h=40&fit=crop&crop=face',
        time: '4小时前',
        tag: '问答'
      }
    ];
    
    return {
      code: 200,
      data: activities,
      message: '获取成功'
    };
  },

  getPopularContent: async () => {
    await new Promise(resolve => setTimeout(resolve, 500));
    
    const content = [
      {
        id: 1,
        title: 'Vue 3 Composition API 最佳实践',
        views: 2340,
        likes: 156,
        comments: 23,
        type: 'article'
      },
      {
        id: 2,
        title: '如何设计一个高性能的前端架构？',
        views: 1890,
        likes: 134,
        comments: 45,
        type: 'question'
      }
    ];
    
    return {
      code: 200,
      data: content,
      message: '获取成功'
    };
  }
};
