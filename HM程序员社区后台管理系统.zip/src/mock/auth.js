export const mockAuth = {
  login: async (credentials) => {
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    const mockUser = {
      id: 1,
      username: credentials.username,
      email: credentials.email || `${credentials.username}@hm.com`,
      role: credentials.username === 'admin' ? 'admin' : 'user',
      avatar: `https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop&crop=face`,
      name: credentials.username === 'admin' ? '系统管理员' : '普通用户',
      createdAt: new Date().toISOString(),
      token: 'mock-jwt-token'
    };
    
    return {
      code: 200,
      data: mockUser,
      message: '登录成功'
    };
  },

  register: async (userData) => {
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    const newUser = {
      id: Date.now(),
      username: userData.username,
      email: userData.email,
      role: 'user',
      avatar: `https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop&crop=face`,
      name: userData.name || userData.username,
      createdAt: new Date().toISOString(),
      token: 'mock-jwt-token'
    };
    
    return {
      code: 200,
      data: newUser,
      message: '注册成功'
    };
  },

  getUserInfo: async () => {
    await new Promise(resolve => setTimeout(resolve, 500));
    
    const savedUser = localStorage.getItem('hm-admin-user');
    if (savedUser) {
      return {
        code: 200,
        data: JSON.parse(savedUser),
        message: '获取用户信息成功'
      };
    }
    
    throw new Error('用户未登录');
  },

  updateUser: async (userData) => {
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    return {
      code: 200,
      data: userData,
      message: '更新成功'
    };
  },

  changePassword: async (passwordData) => {
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    return {
      code: 200,
      data: null,
      message: '密码修改成功'
    };
  }
};
