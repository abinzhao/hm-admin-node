const mockTodos = [
  {
    id: 1,
    title: '完成用户管理模块开发',
    description: '实现完整的用户管理功能，包括用户列表、用户详情、用户编辑等核心功能。',
    status: 'in_progress',
    priority: 'high',
    progress: 75,
    assignee: '张三',
    assigneeAvatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=40&h=40&fit=crop&crop=face',
    creator: '项目经理',
    creatorAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=40&h=40&fit=crop&crop=face',
    dueDate: '2024-01-20',
    estimatedHours: 40,
    actualHours: 30,
    createdAt: '2024-01-15 10:30:00',
    updatedAt: '2024-01-16 14:20:00'
  }
];

export const mockTodo = {
  getTodoList: async (params) => {
    await new Promise(resolve => setTimeout(resolve, 500));
    
    return {
      code: 200,
      data: {
        list: mockTodos,
        total: mockTodos.length,
        page: params.page || 1,
        pageSize: params.pageSize || 10
      },
      message: '获取成功'
    };
  },

  getTodoDetail: async (id) => {
    await new Promise(resolve => setTimeout(resolve, 500));
    
    const todo = mockTodos.find(item => item.id === parseInt(id));
    
    if (!todo) {
      throw new Error('任务不存在');
    }
    
    return {
      code: 200,
      data: todo,
      message: '获取成功'
    };
  },

  createTodo: async (data) => {
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    const newTodo = {
      id: Date.now(),
      ...data,
      progress: 0,
      actualHours: 0,
      createdAt: new Date().toLocaleString(),
      updatedAt: new Date().toLocaleString()
    };
    
    return {
      code: 200,
      data: newTodo,
      message: '创建成功'
    };
  },

  updateTodo: async (id, data) => {
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    return {
      code: 200,
      data: { ...data, id, updatedAt: new Date().toLocaleString() },
      message: '更新成功'
    };
  },

  deleteTodo: async (id) => {
    await new Promise(resolve => setTimeout(resolve, 500));
    
    return {
      code: 200,
      data: null,
      message: '删除成功'
    };
  },

  updateTodoStatus: async (id, status) => {
    await new Promise(resolve => setTimeout(resolve, 500));
    
    return {
      code: 200,
      data: { id, status, updatedAt: new Date().toLocaleString() },
      message: '状态更新成功'
    };
  }
};
