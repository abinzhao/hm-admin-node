const mockUsers = [
  {
    id: 1,
    username: 'admin',
    name: '系统管理员',
    email: 'admin@hm.com',
    phone: '138****0000',
    role: 'admin',
    status: 'active',
    avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=40&h=40&fit=crop&crop=face',
    bio: '系统管理员，负责平台的整体运营和管理。',
    location: '北京市',
    website: 'https://hm.com',
    lastLogin: '2024-01-16 14:30:00',
    createdAt: '2024-01-01 10:00:00',
    articlesCount: 25,
    questionsCount: 12,
    snippetsCount: 8,
    likesCount: 156,
    viewsCount: 5678,
    commentsCount: 89
  },
  {
    id: 2,
    username: 'zhangsan',
    name: '张三',
    email: 'zhangsan@hm.com',
    phone: '138****8888',
    role: 'user',
    status: 'active',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=40&h=40&fit=crop&crop=face',
    bio: '热爱编程的前端开发工程师，专注于React和Vue技术栈。',
    location: '北京市朝阳区',
    website: 'https://zhangsan.dev',
    lastLogin: '2024-01-16 10:15:00',
    createdAt: '2024-01-05 14:20:00',
    articlesCount: 8,
    questionsCount: 15,
    snippetsCount: 12,
    likesCount: 89,
    viewsCount: 2340,
    commentsCount: 156
  }
];

export const mockUser = {
  getUserList: async (params) => {
    await new Promise(resolve => setTimeout(resolve, 500));
    
    return {
      code: 200,
      data: {
        list: mockUsers,
        total: mockUsers.length,
        page: params.page || 1,
        pageSize: params.pageSize || 10
      },
      message: '获取成功'
    };
  },

  getUserDetail: async (id) => {
    await new Promise(resolve => setTimeout(resolve, 500));
    
    const user = mockUsers.find(item => item.id === parseInt(id));
    
    if (!user) {
      throw new Error('用户不存在');
    }
    
    return {
      code: 200,
      data: user,
      message: '获取成功'
    };
  },

  createUser: async (data) => {
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    const newUser = {
      id: Date.now(),
      ...data,
      articlesCount: 0,
      questionsCount: 0,
      snippetsCount: 0,
      likesCount: 0,
      viewsCount: 0,
      commentsCount: 0,
      lastLogin: null,
      createdAt: new Date().toLocaleString()
    };
    
    return {
      code: 200,
      data: newUser,
      message: '创建成功'
    };
  },

  updateUser: async (id, data) => {
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    return {
      code: 200,
      data: { ...data, id },
      message: '更新成功'
    };
  },

  deleteUser: async (id) => {
    await new Promise(resolve => setTimeout(resolve, 500));
    
    return {
      code: 200,
      data: null,
      message: '删除成功'
    };
  },

  updateUserStatus: async (id, status) => {
    await new Promise(resolve => setTimeout(resolve, 500));
    
    return {
      code: 200,
      data: { id, status },
      message: '状态更新成功'
    };
  }
};
