import React, { createContext, useContext, useState, useEffect } from 'react';

const AuthContext = createContext();

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // 模拟从localStorage获取用户信息
    const savedUser = localStorage.getItem('hm-admin-user');
    if (savedUser) {
      try {
        setUser(JSON.parse(savedUser));
      } catch (error) {
        console.error('Failed to parse user data:', error);
        localStorage.removeItem('hm-admin-user');
      }
    }
    setLoading(false);
  }, []);

  const login = async (credentials) => {
    // 模拟登录API调用
    const mockUser = {
      id: 1,
      username: credentials.username,
      email: credentials.email || `${credentials.username}@hm.com`,
      role: credentials.username === 'admin' ? 'admin' : 'user',
      avatar: `https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop&crop=face`,
      name: credentials.username === 'admin' ? '系统管理员' : '普通用户',
      createdAt: new Date().toISOString()
    };
    
    setUser(mockUser);
    localStorage.setItem('hm-admin-user', JSON.stringify(mockUser));
    return mockUser;
  };

  const register = async (userData) => {
    // 模拟注册API调用
    const newUser = {
      id: Date.now(),
      username: userData.username,
      email: userData.email,
      role: 'user',
      avatar: `https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop&crop=face`,
      name: userData.name || userData.username,
      createdAt: new Date().toISOString()
    };
    
    setUser(newUser);
    localStorage.setItem('hm-admin-user', JSON.stringify(newUser));
    return newUser;
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('hm-admin-user');
  };

  const updateUser = (userData) => {
    const updatedUser = { ...user, ...userData };
    setUser(updatedUser);
    localStorage.setItem('hm-admin-user', JSON.stringify(updatedUser));
  };

  const value = {
    user,
    loading,
    login,
    register,
    logout,
    updateUser,
    isAdmin: user?.role === 'admin'
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
};
