import api from './api';
import { mockTodo } from '../mock/todo';

const isDev = process.env.NODE_ENV === 'development';

export const todoService = {
  // 获取待办列表
  async getTodoList(params = {}) {
    if (isDev) {
      return mockTodo.getTodoList(params);
    }
    return api.get('/todos', { params });
  },

  // 获取待办详情
  async getTodoDetail(id) {
    if (isDev) {
      return mockTodo.getTodoDetail(id);
    }
    return api.get(`/todos/${id}`);
  },

  // 创建待办
  async createTodo(data) {
    if (isDev) {
      return mockTodo.createTodo(data);
    }
    return api.post('/todos', data);
  },

  // 更新待办
  async updateTodo(id, data) {
    if (isDev) {
      return mockTodo.updateTodo(id, data);
    }
    return api.put(`/todos/${id}`, data);
  },

  // 删除待办
  async deleteTodo(id) {
    if (isDev) {
      return mockTodo.deleteTodo(id);
    }
    return api.delete(`/todos/${id}`);
  },

  // 更新待办状态
  async updateTodoStatus(id, status) {
    if (isDev) {
      return mockTodo.updateTodoStatus(id, status);
    }
    return api.patch(`/todos/${id}/status`, { status });
  }
};
