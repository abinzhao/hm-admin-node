import api from './api';
import { mockDashboard } from '../mock/dashboard';

const isDev = process.env.NODE_ENV === 'development';

export const dashboardService = {
  // 获取统计数据
  async getStats() {
    if (isDev) {
      return mockDashboard.getStats();
    }
    return api.get('/dashboard/stats');
  },

  // 获取最近活动
  async getRecentActivities() {
    if (isDev) {
      return mockDashboard.getRecentActivities();
    }
    return api.get('/dashboard/activities');
  },

  // 获取热门内容
  async getPopularContent() {
    if (isDev) {
      return mockDashboard.getPopularContent();
    }
    return api.get('/dashboard/popular');
  }
};
