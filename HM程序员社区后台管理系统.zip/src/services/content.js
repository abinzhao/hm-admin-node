import api from './api';
import { mockContent } from '../mock/content';

const isDev = process.env.NODE_ENV === 'development';

export const contentService = {
  // 获取内容列表
  async getContentList(type, params = {}) {
    if (isDev) {
      return mockContent.getContentList(type, params);
    }
    return api.get(`/content/${type}`, { params });
  },

  // 获取内容详情
  async getContentDetail(type, id) {
    if (isDev) {
      return mockContent.getContentDetail(type, id);
    }
    return api.get(`/content/${type}/${id}`);
  },

  // 创建内容
  async createContent(type, data) {
    if (isDev) {
      return mockContent.createContent(type, data);
    }
    return api.post(`/content/${type}`, data);
  },

  // 更新内容
  async updateContent(type, id, data) {
    if (isDev) {
      return mockContent.updateContent(type, id, data);
    }
    return api.put(`/content/${type}/${id}`, data);
  },

  // 删除内容
  async deleteContent(type, id) {
    if (isDev) {
      return mockContent.deleteContent(type, id);
    }
    return api.delete(`/content/${type}/${id}`);
  },

  // 获取评论列表
  async getComments(type, id) {
    if (isDev) {
      return mockContent.getComments(type, id);
    }
    return api.get(`/content/${type}/${id}/comments`);
  },

  // 添加评论
  async addComment(type, id, comment) {
    if (isDev) {
      return mockContent.addComment(type, id, comment);
    }
    return api.post(`/content/${type}/${id}/comments`, comment);
  }
};
