import api from './api';
import { mockNotification } from '../mock/notification';

const isDev = process.env.NODE_ENV === 'development';

export const notificationService = {
  // 获取通知列表
  async getNotificationList(params = {}) {
    if (isDev) {
      return mockNotification.getNotificationList(params);
    }
    return api.get('/notifications', { params });
  },

  // 获取通知详情
  async getNotificationDetail(id) {
    if (isDev) {
      return mockNotification.getNotificationDetail(id);
    }
    return api.get(`/notifications/${id}`);
  },

  // 创建通知
  async createNotification(data) {
    if (isDev) {
      return mockNotification.createNotification(data);
    }
    return api.post('/notifications', data);
  },

  // 更新通知
  async updateNotification(id, data) {
    if (isDev) {
      return mockNotification.updateNotification(id, data);
    }
    return api.put(`/notifications/${id}`, data);
  },

  // 删除通知
  async deleteNotification(id) {
    if (isDev) {
      return mockNotification.deleteNotification(id);
    }
    return api.delete(`/notifications/${id}`);
  },

  // 发布通知
  async publishNotification(id) {
    if (isDev) {
      return mockNotification.publishNotification(id);
    }
    return api.post(`/notifications/${id}/publish`);
  }
};
