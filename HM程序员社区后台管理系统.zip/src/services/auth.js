import api from './api';
import { mockAuth } from '../mock/auth';

const isDev = process.env.NODE_ENV === 'development';

export const authService = {
  // 登录
  async login(credentials) {
    if (isDev) {
      return mockAuth.login(credentials);
    }
    return api.post('/auth/login', credentials);
  },

  // 注册
  async register(userData) {
    if (isDev) {
      return mockAuth.register(userData);
    }
    return api.post('/auth/register', userData);
  },

  // 获取用户信息
  async getUserInfo() {
    if (isDev) {
      return mockAuth.getUserInfo();
    }
    return api.get('/auth/me');
  },

  // 更新用户信息
  async updateUser(userData) {
    if (isDev) {
      return mockAuth.updateUser(userData);
    }
    return api.put('/auth/me', userData);
  },

  // 修改密码
  async changePassword(passwordData) {
    if (isDev) {
      return mockAuth.changePassword(passwordData);
    }
    return api.put('/auth/password', passwordData);
  }
};
