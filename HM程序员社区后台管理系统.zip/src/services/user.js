import api from './api';
import { mockUser } from '../mock/user';

const isDev = process.env.NODE_ENV === 'development';

export const userService = {
  // 获取用户列表
  async getUserList(params = {}) {
    if (isDev) {
      return mockUser.getUserList(params);
    }
    return api.get('/users', { params });
  },

  // 获取用户详情
  async getUserDetail(id) {
    if (isDev) {
      return mockUser.getUserDetail(id);
    }
    return api.get(`/users/${id}`);
  },

  // 创建用户
  async createUser(data) {
    if (isDev) {
      return mockUser.createUser(data);
    }
    return api.post('/users', data);
  },

  // 更新用户
  async updateUser(id, data) {
    if (isDev) {
      return mockUser.updateUser(id, data);
    }
    return api.put(`/users/${id}`, data);
  },

  // 删除用户
  async deleteUser(id) {
    if (isDev) {
      return mockUser.deleteUser(id);
    }
    return api.delete(`/users/${id}`);
  },

  // 更新用户状态
  async updateUserStatus(id, status) {
    if (isDev) {
      return mockUser.updateUserStatus(id, status);
    }
    return api.patch(`/users/${id}/status`, { status });
  }
};
